package com.example.filemaster

import java.io.File
import java.util.Properties
import java.util.UUID

data class TrashItem(
    val id: String,
    val name: String,
    val originalPath: String,
    val deletedAt: Long,
    val isDir: Boolean,
    val box: File
)

/**
 * Lixeira real: cada item vai para "<volume>/.FileMasterTrash/<id>/payload" com um "meta.properties"
 * (nome, caminho original, data). Fica no mesmo volume do item, então mover é instantâneo.
 * Itens com mais de 30 dias são apagados de vez ao abrir o app.
 */
class TrashStore(private val volumeRoots: List<File>) {

    companion object {
        const val DIR_NAME = ".FileMasterTrash"
        const val RETENTION_DAYS = 30L
    }

    private fun trashRoots() = volumeRoots.map { File(it, DIR_NAME) }

    private fun trashRootFor(file: File): File {
        val p = file.absolutePath
        val vol = volumeRoots
            .filter { p == it.absolutePath || p.startsWith(it.absolutePath + File.separator) }
            .maxByOrNull { it.absolutePath.length } ?: volumeRoots.first()
        return File(vol, DIR_NAME)
    }

    /** Retorna null se deu certo ou a mensagem de erro. */
    fun moveToTrash(file: File): String? {
        if (!file.exists()) return "Item não encontrado."
        if (volumeRoots.any { it.absolutePath == file.absolutePath }) return "Não é possível excluir a raiz do armazenamento."
        val trashRoot = trashRootFor(file)
        if (FileOps.isSameOrInside(trashRoot, file)) return "Este item já está na lixeira."
        val id = UUID.randomUUID().toString()
        val box = File(trashRoot, id)
        if (!box.mkdirs()) return "Não foi possível criar a lixeira."
        try { File(trashRoot, ".nomedia").createNewFile() } catch (_: Exception) {}
        val meta = Properties().apply {
            setProperty("name", file.name)
            setProperty("path", file.absolutePath)
            setProperty("time", System.currentTimeMillis().toString())
            setProperty("dir", file.isDirectory.toString())
        }
        try {
            File(box, "meta.properties").outputStream().use { meta.store(it, null) }
        } catch (_: Exception) {
            box.deleteRecursively()
            return "Não foi possível gravar os dados da lixeira."
        }
        val payload = File(box, "payload")
        if (!FileOps.moveExact(file, payload)) {
            // Se a cópia chegou a existir, deixa na lixeira (restaurável) em vez de arriscar perder dados.
            if (!payload.exists()) box.deleteRecursively()
            return "Não foi possível mover \"${file.name}\"."
        }
        return null
    }

    fun list(): List<TrashItem> {
        val out = mutableListOf<TrashItem>()
        for (root in trashRoots()) {
            val boxes = root.listFiles() ?: continue
            for (box in boxes) {
                if (!box.isDirectory) continue
                val metaFile = File(box, "meta.properties")
                if (!metaFile.exists() || !File(box, "payload").exists()) continue
                try {
                    val p = Properties()
                    metaFile.inputStream().use { p.load(it) }
                    out.add(
                        TrashItem(
                            id = box.name,
                            name = p.getProperty("name") ?: "item",
                            originalPath = p.getProperty("path") ?: "",
                            deletedAt = p.getProperty("time")?.toLongOrNull() ?: 0L,
                            isDir = p.getProperty("dir") == "true",
                            box = box
                        )
                    )
                } catch (_: Exception) {
                    // entrada corrompida: ignora
                }
            }
        }
        return out.sortedByDescending { it.deletedAt }
    }

    /** Retorna null se deu certo ou a mensagem de erro. Se o nome já existir, restaura como "nome (1)". */
    fun restore(item: TrashItem): String? {
        val payload = File(item.box, "payload")
        if (!payload.exists()) return "Item não encontrado na lixeira."
        val parent = File(item.originalPath).parentFile ?: return "Pasta original inválida."
        if (!parent.exists() && !parent.mkdirs()) return "Não foi possível recriar a pasta original."
        val dest = FileOps.uniqueFile(parent, item.name)
        if (!FileOps.moveExact(payload, dest)) return "Não foi possível restaurar."
        item.box.deleteRecursively()
        return null
    }

    fun deleteForever(item: TrashItem): Boolean = item.box.deleteRecursively()

    /** Retorna quantos itens NÃO puderam ser apagados. */
    fun emptyAll(): Int = list().count { !deleteForever(it) }

    fun purgeExpired(): Int {
        val limit = System.currentTimeMillis() - RETENTION_DAYS * 24L * 60L * 60L * 1000L
        return list().filter { it.deletedAt < limit }.count { deleteForever(it) }
    }
}
