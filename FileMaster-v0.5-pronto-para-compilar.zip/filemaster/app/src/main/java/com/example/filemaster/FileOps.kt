package com.example.filemaster

import android.content.Context
import android.os.Environment
import android.os.StatFs
import java.io.File
import java.nio.file.Files

data class Volume(val label: String, val root: File, val removable: Boolean)

object Storage {
    /** Armazenamento interno + cartões SD/USB que o sistema expõe. */
    fun volumes(context: Context): List<Volume> {
        val list = mutableListOf(Volume("Armazenamento interno", Environment.getExternalStorageDirectory(), false))
        for (d in context.getExternalFilesDirs(null).drop(1)) {
            if (d == null) continue
            val p = d.absolutePath
            val idx = p.indexOf("/Android/data")
            if (idx > 0) {
                val removable = try { Environment.isExternalStorageRemovable(d) } catch (_: Exception) { true }
                list.add(Volume(if (removable) "Cartão SD" else "Armazenamento externo", File(p.substring(0, idx)), removable))
            }
        }
        return list
    }

    /** (total, livre, usado) em bytes. */
    fun usage(root: File): Triple<Long, Long, Long> = try {
        val fs = StatFs(root.path)
        val total = fs.totalBytes
        val free = fs.availableBytes
        Triple(total, free, total - free)
    } catch (_: Exception) {
        Triple(0L, 0L, 0L)
    }
}

fun formatSize(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val units = listOf("KB", "MB", "GB", "TB")
    var value = bytes.toDouble()
    var index = -1
    do { value /= 1024.0; index++ } while (value >= 1024 && index < units.lastIndex)
    return String.format(java.util.Locale.getDefault(), "%.1f %s", value, units[index])
}

object FileOps {

    data class BatchResult(val ok: Int, val failed: Int)

    /** "nome.ext" -> "nome (1).ext" -> "nome (2).ext" ... até achar um nome livre. */
    fun uniqueFile(dir: File, wanted: String): File {
        var f = File(dir, wanted)
        if (!f.exists()) return f
        val dot = wanted.lastIndexOf('.')
        val base = if (dot > 0) wanted.substring(0, dot) else wanted
        val ext = if (dot > 0) wanted.substring(dot) else ""
        var n = 1
        while (true) {
            f = File(dir, "$base ($n)$ext")
            if (!f.exists()) return f
            n++
        }
    }

    /** true se [target] é [ancestor] ou está dentro dela. Na dúvida, true (bloqueia). */
    fun isSameOrInside(ancestor: File, target: File): Boolean = try {
        val a = ancestor.canonicalPath
        val t = target.canonicalPath
        t == a || t.startsWith(a + File.separator)
    } catch (_: Exception) {
        true
    }

    private fun isSymlink(f: File): Boolean = try { Files.isSymbolicLink(f.toPath()) } catch (_: Exception) { false }

    private fun copyInto(src: File, dest: File): Boolean {
        if (isSymlink(src)) return false
        if (src.isDirectory) {
            if (!dest.mkdirs()) return false
            val children = src.listFiles() ?: return false
            for (c in children) {
                if (isSymlink(c)) continue
                if (!copyInto(c, File(dest, c.name))) return false
            }
            return true
        }
        return try {
            src.copyTo(dest, overwrite = false)
            dest.setLastModified(src.lastModified())
            true
        } catch (_: Exception) {
            false
        }
    }

    /** Copia [src] para dentro de [destDir] (nome com sufixo se já existir). */
    fun copy(src: File, destDir: File): File? {
        if (src.isDirectory && isSameOrInside(src, destDir)) return null
        val dest = uniqueFile(destDir, src.name)
        if (copyInto(src, dest)) return dest
        dest.deleteRecursively()
        return null
    }

    /** Move para o caminho exato [dest]. Mesmo volume = renomear (instantâneo); senão copia e apaga a origem. */
    fun moveExact(src: File, dest: File): Boolean {
        val destParent = dest.parentFile ?: return false
        if (src.isDirectory && isSameOrInside(src, destParent)) return false
        if (src.renameTo(dest)) return true
        if (!copyInto(src, dest)) {
            dest.deleteRecursively()
            return false
        }
        // Se não der para apagar a origem, mantém a cópia: nunca perde dados.
        return src.deleteRecursively()
    }

    fun move(src: File, destDir: File): File? {
        val dest = uniqueFile(destDir, src.name)
        return if (moveExact(src, dest)) dest else null
    }

    /** Apaga de vez (sem lixeira). */
    fun deleteForever(file: File): Boolean = file.deleteRecursively()

    private fun validName(n: String) = n.isNotEmpty() && !n.contains('/') && !n.contains('\u0000') && n != "." && n != ".."

    /** Retorna null se deu certo ou a mensagem de erro. */
    fun rename(file: File, newName: String): String? {
        val n = newName.trim()
        if (!validName(n)) return "Nome inválido."
        val parent = file.parentFile ?: return "Não foi possível renomear."
        val dest = File(parent, n)
        if (dest.exists()) return "Já existe um item com esse nome."
        return if (file.renameTo(dest)) null else "Não foi possível renomear."
    }

    fun createFolder(parent: File, name: String): String? {
        val n = name.trim()
        if (!validName(n)) return "Nome inválido."
        val dest = File(parent, n)
        if (dest.exists()) return "Já existe um item com esse nome."
        return if (dest.mkdir()) null else "Não foi possível criar a pasta."
    }

    fun pasteAll(files: List<File>, destDir: File, isMove: Boolean): BatchResult {
        var ok = 0
        var failed = 0
        for (f in files) {
            val done = if (isMove) {
                if (f.parentFile?.absolutePath == destDir.absolutePath) true else move(f, destDir) != null
            } else {
                copy(f, destDir) != null
            }
            if (done) ok++ else failed++
        }
        return BatchResult(ok, failed)
    }
}
