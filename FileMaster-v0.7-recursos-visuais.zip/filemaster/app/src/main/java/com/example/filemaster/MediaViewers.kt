package com.example.filemaster

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.ThumbnailUtils
import android.provider.MediaStore
import android.webkit.WebView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.graphics.drawable.toBitmap
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.LinkedHashMap

/** Cache LRU limitado a 24 MiB; itens fora de tela não mantêm bitmaps próprios na composição. */
private object ThumbnailCache {
    private const val MAX_BYTES = 24 * 1024 * 1024
    private val cache = object : LinkedHashMap<String, Bitmap>(32, .75f, true) {
        var bytes = 0
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Bitmap>?): Boolean {
            if (bytes > MAX_BYTES && eldest != null) { bytes -= eldest.value.byteCount; return true }
            return false
        }
    }
    @Synchronized fun get(key: String) = cache[key]
    @Synchronized fun put(key: String, bitmap: Bitmap) { cache.put(key, bitmap)?.let { cache.bytes -= it.byteCount }; cache.bytes += bitmap.byteCount; while (cache.bytes > MAX_BYTES && cache.isNotEmpty()) { val first = cache.entries.iterator().next(); cache.bytes -= first.value.byteCount; cache.remove(first.key) } }
}

private fun loadThumbnail(file: File, video: Boolean): Bitmap? {
    val key = "${file.absolutePath}:${file.lastModified()}:${file.length()}:$video"
    ThumbnailCache.get(key)?.let { return it }
    val bitmap = try {
        if (video) ThumbnailUtils.createVideoThumbnail(file, android.util.Size(256, 256), null)
        else {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) null else {
                var sample = 1
                while (bounds.outWidth / sample > 384 || bounds.outHeight / sample > 384) sample *= 2
                BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.RGB_565 })
            }
        }
    } catch (_: Exception) { null }
    if (bitmap != null) ThumbnailCache.put(key, bitmap)
    return bitmap
}

@Composable
internal fun FileThumbnail(file: File, video: Boolean, modifier: Modifier = Modifier) {
    // Só é iniciado enquanto este item da LazyColumn está composto/próximo da tela.
    val bitmap by produceState<Bitmap?>(initialValue = null, key1 = file.absolutePath, key2 = file.lastModified()) {
        value = withContext(Dispatchers.IO) { loadThumbnail(file, video) }
    }
    Box(modifier.background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
        if (bitmap != null) Image(bitmap!!.asImageBitmap(), contentDescription = file.name, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text(if (video) "▶" else "▧", color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (video) Text("▶", modifier = Modifier.align(Alignment.BottomEnd).padding(4.dp).background(Color.Black.copy(alpha=.65f)), color = Color.White)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun MediaViewer(file: File, onBack: () -> Unit) {
    val ext = file.extension.lowercase()
    val isImage = ext in setOf("jpg","jpeg","png","gif","webp","bmp","heic","heif")
    val isVideo = ext in setOf("mp4","mkv","avi","mov","webm","3gp","flv","wmv","m4v","ts")
    val isAudio = ext in setOf("mp3","wav","flac","ogg","m4a","aac","opus","wma","amr","mid")
    val isPdf = ext == "pdf"
    val isHtml = ext == "html" || ext == "htm"
    val context = LocalContext.current
    BackHandler(onBack = onBack)
    Scaffold(topBar = { TopAppBar(title = { Text(file.name, maxLines=1, overflow=TextOverflow.Ellipsis) }, navigationIcon = { IconButton(onClick=onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription="Voltar") } }) }) { padding ->
        when {
            isImage -> {
                var scale by remember(file.absolutePath) { mutableFloatStateOf(1f) }
                var panX by remember(file.absolutePath) { mutableFloatStateOf(0f) }
                var panY by remember(file.absolutePath) { mutableFloatStateOf(0f) }
                val state = rememberTransformableState { zoom, pan, _ -> scale = (scale * zoom).coerceIn(1f, 5f); panX += pan.x; panY += pan.y }
                val bitmap by produceState<Bitmap?>(null, file.absolutePath) {
                    value = withContext(Dispatchers.IO) {
                        try {
                            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                            BitmapFactory.decodeFile(file.absolutePath, bounds)
                            var sample = 1
                            while (bounds.outWidth / sample > 2048 || bounds.outHeight / sample > 2048) sample *= 2
                            BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.RGB_565 })
                        } catch (_: Exception) { null }
                    }
                }
                Box(Modifier.fillMaxSize().padding(padding).background(Color.Black), contentAlignment=Alignment.Center) {
                    if (bitmap != null) Image(bitmap!!.asImageBitmap(), contentDescription=file.name, modifier=Modifier.fillMaxSize().graphicsLayer { scaleX=scale; scaleY=scale; translationX=panX; translationY=panY }.transformable(state), contentScale=ContentScale.Fit)
                    else CircularProgressIndicator()
                }
            }
            isVideo || isAudio -> {
                val player = remember(file.absolutePath) { ExoPlayer.Builder(context).build().apply { setMediaItem(MediaItem.fromUri(android.net.Uri.fromFile(file))); prepare() } }
                DisposableEffect(player) { onDispose { player.release() } }
                Column(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement=Arrangement.Center, horizontalAlignment=Alignment.CenterHorizontally) {
                    if (isVideo) AndroidView(factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true } }, modifier=Modifier.fillMaxWidth().weight(1f))
                    else {
                        Icon(Icons.Default.PlayArrow, contentDescription=null, modifier=Modifier.size(96.dp), tint=MaterialTheme.colorScheme.primary)
                        Text(file.name, style=MaterialTheme.typography.titleMedium, maxLines=2, overflow=TextOverflow.Ellipsis)
                        Spacer(Modifier.height(20.dp))
                        var playing by remember { mutableStateOf(false) }
                        Button(onClick = { if (player.isPlaying) { player.pause(); playing=false } else { player.play(); playing=true } }) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription=null); Spacer(Modifier.width(8.dp)); Text(if (playing) "Pausar" else "Reproduzir") }
                    }
                }
            }
            isPdf -> PdfReader(file, Modifier.padding(padding).fillMaxSize())
            isHtml -> {
                var html by remember(file.absolutePath) { mutableStateOf<String?>(null) }
                LaunchedEffect(file.absolutePath) { html = withContext(Dispatchers.IO) { runCatching { file.bufferedReader(Charsets.UTF_8).use { it.readTextBounded(2_000_000) } }.getOrNull() } }
                if (html == null) Box(Modifier.fillMaxSize().padding(padding), contentAlignment=Alignment.Center) { CircularProgressIndicator() }
                else AndroidView(modifier=Modifier.fillMaxSize().padding(padding), factory={ ctx -> WebView(ctx).apply { settings.javaScriptEnabled=false; settings.allowFileAccess=false; settings.allowContentAccess=false; loadDataWithBaseURL(null, html!!, "text/html", "UTF-8", null) } })
            }
            else -> {
                var text by remember(file.absolutePath) { mutableStateOf<String?>(null) }
                LaunchedEffect(file.absolutePath) { text = withContext(Dispatchers.IO) { runCatching { file.bufferedReader(Charsets.UTF_8).use { it.readTextBounded(1_000_000) } }.getOrNull() } }
                if (text == null) Box(Modifier.fillMaxSize().padding(padding), contentAlignment=Alignment.Center) { CircularProgressIndicator() }
                else androidx.compose.foundation.lazy.LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp)) { item { Text(text ?: "Não foi possível ler este arquivo.", style=MaterialTheme.typography.bodyMedium) } }
            }
        }
    }
}

@Composable
private fun PdfReader(file: File, modifier: Modifier = Modifier) {
    var pageIndex by remember(file.absolutePath) { mutableIntStateOf(0) }
    var pageCount by remember(file.absolutePath) { mutableIntStateOf(0) }
    var bitmap by remember(file.absolutePath) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(file.absolutePath, pageIndex) {
        val result = withContext(Dispatchers.IO) {
            runCatching {
                val pfd = android.os.ParcelFileDescriptor.open(file, android.os.ParcelFileDescriptor.MODE_READ_ONLY)
                val renderer = android.graphics.pdf.PdfRenderer(pfd)
                val count = renderer.pageCount
                val index = pageIndex.coerceIn(0, (count-1).coerceAtLeast(0))
                val page = renderer.openPage(index)
                val widthScale = 1200f / page.width
                val pixelScale = kotlin.math.sqrt(12_000_000.0 / (page.width.toDouble() * page.height.toDouble())).toFloat()
                val scale = minOf(widthScale, pixelScale, 2f).coerceAtLeast(0.1f)
                val bmp = Bitmap.createBitmap((page.width*scale).toInt().coerceAtLeast(1), (page.height*scale).toInt().coerceAtLeast(1), Bitmap.Config.RGB_565)
                page.render(bmp, null, null, android.graphics.pdf.PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                page.close(); renderer.close(); pfd.close(); Triple(bmp,count,null as String?)
            }.getOrElse { Triple(null,0,it.message ?: "Não foi possível abrir o PDF.") }
        }
        bitmap = result.first; pageCount = result.second
    }
    Column(modifier) {
        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement=Arrangement.Center, verticalAlignment=Alignment.CenterVertically) {
            TextButton(enabled=pageIndex>0, onClick={pageIndex--}) { Text("Anterior") }
            Text(if(pageCount>0) "${pageIndex+1} / $pageCount" else "PDF")
            TextButton(enabled=pageCount>0 && pageIndex<pageCount-1, onClick={pageIndex++}) { Text("Próxima") }
        }
        Box(Modifier.fillMaxSize(), contentAlignment=Alignment.Center) { if(bitmap!=null) Image(bitmap!!.asImageBitmap(), contentDescription="Página ${pageIndex+1}", modifier=Modifier.fillMaxWidth(), contentScale=ContentScale.Fit) else CircularProgressIndicator() }
    }
}

private fun java.io.BufferedReader.readTextBounded(maxChars: Int): String {
    val out = StringBuilder(minOf(maxChars, 16_384))
    val buffer = CharArray(8192)
    while (out.length < maxChars) {
        val n = read(buffer, 0, minOf(buffer.size, maxChars - out.length))
        if (n <= 0) break
        out.append(buffer, 0, n)
    }
    return out.toString()
}
