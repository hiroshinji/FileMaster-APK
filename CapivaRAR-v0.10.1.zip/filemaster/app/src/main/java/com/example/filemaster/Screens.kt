@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.example.filemaster

import android.os.Environment
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties
import java.io.File
import java.nio.file.Files
import java.nio.file.attribute.BasicFileAttributes
import java.text.DateFormat
import java.util.Date
import java.time.LocalTime

enum class Screen { HOME, BROWSER, TRASH, VIEWER }

enum class SortMode(val label: String) {
    NAME("Nome"),
    DATE("Data (mais recentes)"),
    SIZE("Tamanho (maiores)")
}

data class Clipboard(val files: List<File>, val move: Boolean)

enum class FileKind { FOLDER, IMAGE, VIDEO, AUDIO, APK, PDF, SHEET, SLIDE, CODE, DOC, ARCHIVE, OTHER }

private val IMAGE_EXT = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif", "svg")
private val VIDEO_EXT = setOf("mp4", "mkv", "avi", "mov", "webm", "3gp", "flv", "wmv", "m4v", "ts")
private val AUDIO_EXT = setOf("mp3", "wav", "flac", "ogg", "m4a", "aac", "opus", "wma", "amr", "mid")
private val DOC_EXT = setOf("doc", "docx", "txt", "odt", "rtf", "md", "log")
private val SHEET_EXT = setOf("xls", "xlsx", "ods", "csv")
private val SLIDE_EXT = setOf("ppt", "pptx", "odp")
private val CODE_EXT = setOf("html", "htm", "css", "js", "json", "xml", "kt", "java", "py", "c", "cpp", "h", "sh", "yml", "yaml", "kts", "gradle")
private val ARCHIVE_EXT = setOf("zip", "rar", "7z", "gz", "bz2", "xz", "tar", "tgz", "iso")

fun kindOf(name: String, isDir: Boolean): FileKind {
    if (isDir) return FileKind.FOLDER
    val ext = name.substringAfterLast('.', "").lowercase()
    return when {
        ext in IMAGE_EXT -> FileKind.IMAGE
        ext in VIDEO_EXT -> FileKind.VIDEO
        ext in AUDIO_EXT -> FileKind.AUDIO
        ext == "apk" || ext == "xapk" || ext == "apks" -> FileKind.APK
        ext == "pdf" -> FileKind.PDF
        ext in SHEET_EXT -> FileKind.SHEET
        ext in SLIDE_EXT -> FileKind.SLIDE
        ext in CODE_EXT -> FileKind.CODE
        ext in DOC_EXT -> FileKind.DOC
        ext in ARCHIVE_EXT -> FileKind.ARCHIVE
        else -> FileKind.OTHER
    }
}

/**
 * Item da lista. TUDO que a tela precisa (nome, texto de tamanho/data, tipo) é calculado uma única vez,
 * fora da thread principal, para a rolagem não gastar tempo formatando datas ou classificando nomes.
 */
@Immutable
class Entry(
    val file: File,
    val isDir: Boolean,
    val size: Long,
    val modified: Long,
    val kind: FileKind,
    val subtitle: String
) {
    val name: String = file.name
    val path: String = file.absolutePath
    val sortKey: String = name.lowercase()
}

fun buildEntry(file: File, isDir: Boolean, size: Long, modified: Long, df: DateFormat, showParent: Boolean): Entry {
    val subtitle = (if (isDir) "" else formatSize(size) + " · ") +
        df.format(Date(modified)) +
        (if (showParent) " · " + (file.parentFile?.name ?: "") else "")
    return Entry(file, isDir, size, modified, kindOf(file.name, isDir), subtitle)
}

fun sortEntries(entries: List<Entry>, sort: SortMode): List<Entry> {
    val byName = compareBy<Entry> { it.sortKey }
    return when (sort) {
        SortMode.NAME -> entries.sortedWith(compareByDescending<Entry> { it.isDir }.then(byName))
        SortMode.DATE -> entries.sortedWith(compareByDescending<Entry> { it.isDir }.thenByDescending { it.modified })
        SortMode.SIZE -> entries.sortedWith(compareByDescending<Entry> { it.isDir }.thenByDescending { it.size }.then(byName))
    }
}

/** Lista a pasta (rodar fora da thread principal). Retorna null se não houver permissão de leitura. */
fun listDir(dir: File, showHidden: Boolean, sort: SortMode): List<Entry>? {
    val files = dir.listFiles() ?: return null
    val df = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
    val out = ArrayList<Entry>(files.size)
    for (f in files) {
        if (!showHidden && f.name.startsWith(".")) continue
        // Uma única chamada ao sistema por arquivo (em vez de três): bem mais rápido em pastas grandes.
        val attrs = try { Files.readAttributes(f.toPath(), BasicFileAttributes::class.java) } catch (_: Exception) { null }
        val isDir = attrs?.isDirectory ?: f.isDirectory
        val size = if (isDir) 0L else (attrs?.size() ?: f.length())
        val modified = attrs?.lastModifiedTime()?.toMillis() ?: f.lastModified()
        out.add(buildEntry(f, isDir, size, modified, df, false))
    }
    return sortEntries(out, sort)
}

// ───────────────────────────── TELA INICIAL ─────────────────────────────

@Composable
internal fun HomeScreen(
    hasAccess: Boolean,
    volumes: List<Volume>,
    trashCount: Int,
    dark: Boolean,
    snackbar: SnackbarHostState,
    onToggleTheme: () -> Unit,
    onRequestAccess: () -> Unit,
    onOpenVolume: (Volume) -> Unit,
    onOpenShortcut: (File) -> Unit,
    onOpenCategory: (Category) -> Unit,
    onOpenTrash: () -> Unit
) {
    val downloads = remember { Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) }
    val tiles = listOf(
        TileSpec(Icons.Default.Download, "Downloads", C_DOWNLOAD, 0) { onOpenShortcut(downloads) },
        TileSpec(Icons.Default.Image, "Imagens", C_IMAGE, 0) { onOpenCategory(Category.IMAGES) },
        TileSpec(Icons.Default.Movie, "Vídeos", C_VIDEO, 0) { onOpenCategory(Category.VIDEOS) },
        TileSpec(Icons.Default.MusicNote, "Áudios", C_AUDIO, 0) { onOpenCategory(Category.AUDIO) },
        TileSpec(Icons.Default.Description, "Documentos", C_DOC, 0) { onOpenCategory(Category.DOCS) },
        TileSpec(Icons.Default.Android, "APKs", C_APK, 0) { onOpenCategory(Category.APKS) },
        TileSpec(Icons.Default.Archive, "Compactados", C_ARCHIVE, 0) { onOpenCategory(Category.ARCHIVES) },
        TileSpec(Icons.Default.History, "Recentes", C_RECENT, 0) { onOpenCategory(Category.RECENT) },
        TileSpec(Icons.Default.Delete, "Lixeira", C_TRASH, trashCount) { onOpenTrash() }
    )

    Scaffold(snackbarHost = { SnackbarHost(snackbar) }) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp).verticalScroll(rememberScrollState())
        ) {
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("CapivaRAR", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, fontFamily = FontFamily.SansSerif)
                    Text("Seus arquivos, nossa missão!", style = MaterialTheme.typography.bodyMedium)
                }
                IconButton(onClick = onToggleTheme) {
                    Icon(if (dark) Icons.Default.LightMode else Icons.Default.DarkMode, contentDescription = "Alternar tema")
                }
            }
            Spacer(Modifier.height(12.dp))
            CapybaraGreeting()
            Spacer(Modifier.height(16.dp))

            if (!hasAccess) {
                PermissionCard(onRequestAccess)
            } else {
                volumes.forEach { v ->
                    StorageCard(v) { onOpenVolume(v) }
                    Spacer(Modifier.height(14.dp))
                }
                Spacer(Modifier.height(6.dp))
                Text("Acesso rápido", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                tiles.chunked(3).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        row.forEach { t -> ShortcutTile(t, Modifier.weight(1f)) }
                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                    Spacer(Modifier.height(10.dp))
                }
                Spacer(Modifier.height(14.dp))
            }
        }
    }
}

@Composable
private fun CapybaraGreeting() {
    val hour = LocalTime.now().hour
    val greeting = when (hour) {
        in 5..11 -> "Bom dia!"
        in 12..17 -> "Boa tarde!"
        else -> "Boa noite!"
    }
    val message = when (hour) {
        in 5..11 -> "Vamos deixar seus arquivos em ordem?"
        in 12..17 -> "Sua capivarinha está aqui para ajudar!"
        else -> "Relaxe, seus arquivos estão em boas mãos."
    }
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
        shape = RoundedCornerShape(22.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Image(
                painter = painterResource(id = R.drawable.capybara_mascot),
                contentDescription = "Mascote capivarinha do CapivaRAR",
                modifier = Modifier.size(112.dp).clip(RoundedCornerShape(18.dp))
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Surface(color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                        Text(greeting, style = MaterialTheme.typography.titleLarge, fontFamily = FontFamily.Cursive, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.height(3.dp))
                        Text(message, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}

@Composable
private fun PermissionCard(onRequestAccess: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(12.dp))
            Text("Permitir acesso aos arquivos", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Text(
                "Para mostrar o armazenamento e gerenciar seus arquivos, ative ‘Permitir gerenciamento de todos os arquivos’ nas Configurações e volte ao FileMaster. Pastas protegidas pelo Android (como Android/data) continuam inacessíveis.",
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(16.dp))
            Button(onClick = onRequestAccess, modifier = Modifier.fillMaxWidth()) { Text("Permitir acesso") }
        }
    }
}

@Composable
private fun StorageCard(volume: Volume, onClick: () -> Unit) {
    val (total, free, used) = remember(volume.root) { Storage.usage(volume.root) }
    val fraction = if (total > 0) used.toFloat() / total else 0f
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(52.dp)) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            if (volume.removable) Icons.Default.SdCard else Icons.Default.Storage,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(volume.label, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    Text("${formatSize(free)} livres de ${formatSize(total)}", style = MaterialTheme.typography.bodyMedium)
                }
                Text("${(fraction * 100).toInt()}%", style = MaterialTheme.typography.headlineSmall)
            }
            Spacer(Modifier.height(18.dp))
            LinearProgressIndicator(
                progress = { fraction },
                modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp))
            )
            Spacer(Modifier.height(8.dp))
            Text("${formatSize(used)} usados · toque para abrir", style = MaterialTheme.typography.bodySmall)
        }
    }
}

private class TileSpec(val icon: ImageVector, val label: String, val color: Color, val badge: Int, val onClick: () -> Unit)

@Composable
private fun ShortcutTile(tile: TileSpec, modifier: Modifier) {
    Card(onClick = tile.onClick, modifier = modifier) {
        Column(Modifier.fillMaxWidth().padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            BadgedBox(badge = { if (tile.badge > 0) Badge { Text("${tile.badge}") } }) {
                Box(
                    Modifier.size(46.dp).clip(CircleShape).background(tile.color.copy(alpha = 0.16f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(tile.icon, contentDescription = tile.label, tint = tile.color, modifier = Modifier.size(26.dp))
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(tile.label, style = MaterialTheme.typography.labelMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

// ───────────────────────────── NAVEGADOR DE PASTAS ─────────────────────────────

@Composable
internal fun BrowserScreen(
    title: String,
    path: String,
    entries: List<Entry>,
    loading: Boolean,
    busy: Boolean,
    error: String?,
    selected: List<String>,
    sort: SortMode,
    showHidden: Boolean,
    clipboard: Clipboard?,
    flat: Boolean,
    snackbar: SnackbarHostState,
    onBack: () -> Unit,
    onOpen: (Entry) -> Unit,
    onToggle: (Entry) -> Unit,
    onNewFolder: () -> Unit,
    onToggleHidden: () -> Unit,
    onSort: (SortMode) -> Unit,
    onSelectAll: () -> Unit,
    onClearSelection: () -> Unit,
    onCopy: () -> Unit,
    onCut: () -> Unit,
    onDelete: () -> Unit,
    onRename: () -> Unit,
    onExtract: () -> Unit,
    onPaste: () -> Unit,
    onCancelPaste: () -> Unit,
    onShare: () -> Unit
) {
    val selecting = selected.isNotEmpty()
    var sortMenu by remember { mutableStateOf(false) }
    var gridView by rememberSaveable(flat) { mutableStateOf(false) }
    val single = if (selected.size == 1) entries.firstOrNull { it.path == selected[0] } else null

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = {
                    if (selecting) {
                        Text("${selected.size} selecionado(s)")
                    } else {
                        Column {
                            Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(path, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = if (selecting) onClearSelection else onBack) {
                        Icon(
                            if (selecting) Icons.Default.Close else Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = if (selecting) "Cancelar seleção" else "Voltar"
                        )
                    }
                },
                actions = {
                    if (selecting) {
                        IconButton(onClick = onShare) { Icon(Icons.Default.Share, contentDescription = "Compartilhar selecionados") }
                        IconButton(onClick = onSelectAll) { Icon(Icons.Default.SelectAll, contentDescription = "Selecionar tudo") }
                    } else {
                        IconButton(onClick = { gridView = !gridView }) { Icon(if (gridView) Icons.Default.ViewList else Icons.Default.GridView, contentDescription = if (gridView) "Visualização em lista" else "Visualização em grade") }
                        if (!flat) {
                            IconButton(onClick = onNewFolder) { Icon(Icons.Default.CreateNewFolder, contentDescription = "Nova pasta") }
                            IconButton(onClick = onToggleHidden) {
                                Icon(
                                    if (showHidden) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = "Mostrar ou ocultar arquivos ocultos"
                                )
                            }
                        }
                        Box {
                            IconButton(onClick = { sortMenu = true }) { Icon(Icons.Default.SortByAlpha, contentDescription = "Ordenar") }
                            DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                                SortMode.values().forEach { mode ->
                                    DropdownMenuItem(
                                        text = { Text(mode.label) },
                                        leadingIcon = { if (mode == sort) Icon(Icons.Default.Check, contentDescription = null) },
                                        onClick = { sortMenu = false; onSort(mode) }
                                    )
                                }
                            }
                        }
                    }
                }
            )
        },
        bottomBar = {
            if (selecting) {
                Surface(tonalElevation = 3.dp) {
                    Row(
                        Modifier.fillMaxWidth().navigationBarsPadding().padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        BarAction(Modifier.weight(1f), Icons.Default.ContentCopy, "Copiar", onCopy)
                        BarAction(Modifier.weight(1f), Icons.Default.ContentCut, "Mover", onCut)
                        BarAction(Modifier.weight(1f), Icons.Default.Delete, "Excluir", onDelete)
                        if (single != null) BarAction(Modifier.weight(1f), Icons.Default.DriveFileRenameOutline, "Renomear", onRename)
                        if (single != null && !single.isDir && Extractor.isSupported(single.file.name)) {
                            BarAction(Modifier.weight(1f), Icons.Default.Unarchive, "Extrair", onExtract)
                        }
                    }
                }
            } else if (clipboard != null && !flat) {
                Surface(tonalElevation = 3.dp) {
                    Row(
                        Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.ContentPaste, contentDescription = null)
                        Spacer(Modifier.width(10.dp))
                        Text(
                            "${clipboard.files.size} item(ns) para ${if (clipboard.move) "mover" else "copiar"}",
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = onCancelPaste) { Text("Cancelar") }
                        Button(onClick = onPaste) { Text("Colar aqui") }
                    }
                }
            }
        }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            if (busy || loading) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            when {
                error != null -> Text(error, modifier = Modifier.padding(24.dp))
                entries.isEmpty() && !loading -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(56.dp), tint = MaterialTheme.colorScheme.outline)
                            Spacer(Modifier.height(8.dp))
                            Text(if (flat) "Nenhum arquivo encontrado." else "Esta pasta está vazia.", color = MaterialTheme.colorScheme.outline)
                        }
                    }
                }
                else -> if (gridView) {
                    LazyVerticalGrid(columns = GridCells.Adaptive(minSize = 112.dp), modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        gridItems(entries, key = { it.path }, contentType = { it.isDir }) { entry ->
                            Card(modifier = Modifier.fillMaxWidth().combinedClickable(onClick = { if (selecting) onToggle(entry) else onOpen(entry) }, onLongClick = { onToggle(entry) }), colors = CardDefaults.cardColors(containerColor = if (selected.contains(entry.path)) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceContainer)) {
                                Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Box(Modifier.fillMaxWidth().height(78.dp), contentAlignment = Alignment.Center) {
                                        when (entry.kind) {
                                            FileKind.IMAGE -> FileThumbnail(entry.file, false, Modifier.fillMaxSize())
                                            FileKind.VIDEO -> FileThumbnail(entry.file, true, Modifier.fillMaxSize())
                                            else -> Icon(when (entry.kind) { FileKind.FOLDER -> Icons.Default.Folder; FileKind.PDF -> Icons.Default.PictureAsPdf; FileKind.AUDIO -> Icons.Default.AudioFile; FileKind.ARCHIVE -> Icons.Default.Archive; else -> Icons.Default.InsertDriveFile }, contentDescription = null, modifier = Modifier.size(42.dp), tint = MaterialTheme.colorScheme.primary)
                                        }
                                    }
                                    Spacer(Modifier.height(6.dp))
                                    Text(entry.name, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                                    Text(if (entry.isDir) "Pasta" else formatSize(entry.size), maxLines = 1, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                                }
                            }
                        }
                    }
                } else LazyColumn(Modifier.fillMaxSize()) {
                    items(entries, key = { it.path }, contentType = { it.isDir }) { entry ->
                        EntryRow(entry = entry, selecting = selecting, isSelected = selected.contains(entry.path), onClick = { if (selecting) onToggle(entry) else onOpen(entry) }, onLongClick = { onToggle(entry) })
                    }
                }
            }
        }
    }
}

@Composable
private fun BarAction(modifier: Modifier, icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(
        modifier.clickable(onClick = onClick).padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = label)
        Text(label, style = MaterialTheme.typography.labelSmall, maxLines = 1)
    }
}

@Composable
private fun EntryRow(
    entry: Entry,
    selecting: Boolean,
    isSelected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(if (isSelected) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (selecting) {
            Checkbox(checked = isSelected, onCheckedChange = null)
            Spacer(Modifier.width(8.dp))
        }
        when (entry.kind) {
            FileKind.IMAGE, FileKind.VIDEO -> FileThumbnail(entry.file, video = entry.kind == FileKind.VIDEO, modifier = Modifier.size(58.dp).clip(RoundedCornerShape(9.dp)))
            FileKind.APK -> ApkThumbnail(entry.file, modifier = Modifier.size(58.dp).clip(RoundedCornerShape(9.dp)))
            else -> FileTypeIcon(entry.kind)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(entry.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge)
            Text(
                entry.subtitle,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

private val C_DOWNLOAD = Color(0xFF1E88E5)
private val C_IMAGE = Color(0xFF43A047)
private val C_VIDEO = Color(0xFFE53935)
private val C_AUDIO = Color(0xFF8E24AA)
private val C_APK = Color(0xFF00897B)
private val C_PDF = Color(0xFFD32F2F)
private val C_SHEET = Color(0xFF2E7D32)
private val C_SLIDE = Color(0xFFEF6C00)
private val C_CODE = Color(0xFF3949AB)
private val C_DOC = Color(0xFF1E88E5)
private val C_ARCHIVE = Color(0xFFF9A825)
private val C_FOLDER = Color(0xFFFFA000)
private val C_OTHER = Color(0xFF757575)
private val C_RECENT = Color(0xFF5E35B1)
private val C_TRASH = Color(0xFF607D8B)

private class KindStyle(val icon: ImageVector, val color: Color) {
    val background: Color = color.copy(alpha = 0.16f)
}

private val STYLES: Map<FileKind, KindStyle> = mapOf(
    FileKind.FOLDER to KindStyle(Icons.Default.Folder, C_FOLDER),
    FileKind.IMAGE to KindStyle(Icons.Default.Image, C_IMAGE),
    FileKind.VIDEO to KindStyle(Icons.Default.Movie, C_VIDEO),
    FileKind.AUDIO to KindStyle(Icons.Default.MusicNote, C_AUDIO),
    FileKind.APK to KindStyle(Icons.Default.Android, C_APK),
    FileKind.PDF to KindStyle(Icons.Default.PictureAsPdf, C_PDF),
    FileKind.SHEET to KindStyle(Icons.Default.TableChart, C_SHEET),
    FileKind.SLIDE to KindStyle(Icons.Default.Slideshow, C_SLIDE),
    FileKind.CODE to KindStyle(Icons.Default.Code, C_CODE),
    FileKind.DOC to KindStyle(Icons.Default.Description, C_DOC),
    FileKind.ARCHIVE to KindStyle(Icons.Default.Archive, C_ARCHIVE),
    FileKind.OTHER to KindStyle(Icons.Default.InsertDriveFile, C_OTHER)
)

/** Ícone colorido por tipo (estilos criados uma vez só). */
@Composable
private fun FileTypeIcon(kind: FileKind) {
    val k = STYLES.getValue(kind)
    Box(
        Modifier.size(42.dp).clip(RoundedCornerShape(10.dp)).background(k.background),
        contentAlignment = Alignment.Center
    ) {
        Icon(k.icon, contentDescription = null, tint = k.color, modifier = Modifier.size(26.dp))
    }
}

// ───────────────────────────── LIXEIRA ─────────────────────────────

@Composable
internal fun TrashScreen(
    items: List<TrashItem>,
    busy: Boolean,
    snackbar: SnackbarHostState,
    onBack: () -> Unit,
    onRestore: (TrashItem) -> Unit,
    onDelete: (TrashItem) -> Unit,
    onEmpty: () -> Unit
) {
    val dateFormat = remember { DateFormat.getDateInstance(DateFormat.SHORT) }
    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text("Lixeira") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar") } },
                actions = {
                    IconButton(onClick = onEmpty, enabled = items.isNotEmpty()) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = "Esvaziar lixeira")
                    }
                }
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            if (busy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            Text(
                "Os itens ficam aqui por ${TrashStore.RETENTION_DAYS} dias e depois são apagados definitivamente.",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
            if (items.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(56.dp), tint = MaterialTheme.colorScheme.outline)
                        Spacer(Modifier.height(8.dp))
                        Text("A lixeira está vazia.", color = MaterialTheme.colorScheme.outline)
                    }
                }
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(items, key = { it.id }) { item ->
                        val passed = (System.currentTimeMillis() - item.deletedAt) / (24L * 60L * 60L * 1000L)
                        val left = (TrashStore.RETENTION_DAYS - passed).coerceAtLeast(0)
                        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            FileTypeIcon(kindOf(item.name, item.isDir))
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(item.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge)
                                Text(
                                    "Excluído em ${dateFormat.format(Date(item.deletedAt))} · restam $left dia(s)",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Text(
                                    item.originalPath,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.outline,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            IconButton(onClick = { onRestore(item) }) { Icon(Icons.Default.Restore, contentDescription = "Restaurar") }
                            IconButton(onClick = { onDelete(item) }) { Icon(Icons.Default.DeleteForever, contentDescription = "Apagar definitivamente") }
                        }
                        HorizontalDivider()
                    }
                }
            }
        }
    }
}

// ───────────────────────────── DIÁLOGOS ─────────────────────────────

@Composable
internal fun NameDialog(title: String, initial: String, confirm: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    val valid = text.isNotBlank() && !text.contains('/')
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true) },
        confirmButton = { TextButton(enabled = valid, onClick = { onConfirm(text.trim()) }) { Text(confirm) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
internal fun ConfirmDialog(title: String, text: String, confirm: String, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirm) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
internal fun PasswordDialog(retry: Boolean, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Senha do arquivo") },
        text = {
            Column {
                if (retry) Text("Senha incorreta ou arquivo danificado. Tente novamente.", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true, visualTransformation = PasswordVisualTransformation())
            }
        },
        confirmButton = { TextButton(enabled = text.isNotEmpty(), onClick = { onConfirm(text) }) { Text("Extrair") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
internal fun DeleteDialog(count: Int, onDismiss: () -> Unit, onConfirm: (permanent: Boolean) -> Unit) {
    var permanent by remember { mutableStateOf(true) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (permanent) "Apagar definitivamente?" else "Mover para a lixeira?") },
        text = {
            Column {
                Text(
                    if (permanent) "$count item(ns) serão apagados e não poderão ser recuperados."
                    else "$count item(ns) ficam na lixeira por ${TrashStore.RETENTION_DAYS} dias e podem ser restaurados."
                )
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth().clickable { permanent = !permanent }, verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = permanent, onCheckedChange = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Apagar definitivamente (sem lixeira)")
                }
            }
        },
        confirmButton = { TextButton(onClick = { onConfirm(permanent) }) { Text(if (permanent) "Apagar" else "Mover") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

private fun formatDuration(ms: Long): String {
    val s = (ms + 999) / 1000
    return if (s < 60) "$s s" else "${s / 60} min ${s % 60} s"
}

private fun progressLine(p: ExtractProgress?, cancelling: Boolean): String {
    if (cancelling) return "Cancelando e limpando os arquivos…"
    if (p == null) return "Preparando…"
    val parts = mutableListOf<String>()
    val f = p.fraction
    if (f != null) parts.add("${(f * 100).toInt()}%")
    parts.add("${p.files} arquivo(s)")
    parts.add(formatSize(p.bytesDone))
    if (f != null && f > 0.03f && p.elapsedMs > 1500L) {
        val remaining = (p.elapsedMs * (1f - f) / f).toLong()
        parts.add("restam ~${formatDuration(remaining)}")
    }
    return parts.joinToString(" · ")
}

@Composable
internal fun ExtractProgressDialog(name: String, progress: ExtractProgress?, cancelling: Boolean, onCancel: () -> Unit) {
    val fraction = progress?.fraction
    AlertDialog(
        onDismissRequest = {},
        properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false),
        title = { Text("Extraindo…") },
        text = {
            Column {
                Text(name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(14.dp))
                if (fraction != null) {
                    LinearProgressIndicator(progress = { fraction }, modifier = Modifier.fillMaxWidth())
                } else {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
                Spacer(Modifier.height(10.dp))
                Text(progressLine(progress, cancelling), style = MaterialTheme.typography.bodyMedium)
                if (progress != null && progress.currentName.isNotEmpty() && !cancelling) {
                    Text(
                        progress.currentName,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.outline,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = onCancel, enabled = !cancelling) { Text(if (cancelling) "Cancelando…" else "Cancelar") } }
    )
}
