package com.example.filemaster

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.StatFs
import android.os.Environment
import android.provider.Settings
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.util.zip.ZipInputStream

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FileMasterApp() }
    }

    override fun onResume() {
        super.onResume()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && Environment.isExternalStorageManager()) {
            // A tela Compose verifica a permissão ao voltar das Configurações.
        }
    }
}

private enum class PendingFolderAction { OPEN, COPY, MOVE }

@Composable
private fun FileMasterApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var dark by remember { mutableStateOf(false) }
    var showHidden by remember { mutableStateOf(false) }
    val folderStack = remember { mutableStateListOf<DocumentFile>() }
    var refresh by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf("Escolha uma pasta para começar. O Android solicitará autorização de acesso.") }
    var selectedFile by remember { mutableStateOf<DocumentFile?>(null) }
    var menuFileUri by remember { mutableStateOf<String?>(null) }
    var renameDialog by remember { mutableStateOf(false) }
    var deleteDialog by remember { mutableStateOf(false) }
    var renameText by remember { mutableStateOf("") }
    var folderPickerPurpose by remember { mutableStateOf(PendingFolderAction.OPEN) }
    var hasAllFilesAccess by remember { mutableStateOf(Build.VERSION.SDK_INT < Build.VERSION_CODES.R || Environment.isExternalStorageManager()) }

    fun openStorageSettings() {
        try {
            val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${context.packageName}"))
            } else Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
            context.startActivity(intent)
        } catch (_: Exception) {
            message = "Abra Configurações > Aplicativos > FileMaster > Permissões."
        }
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                val allowed = Build.VERSION.SDK_INT < Build.VERSION_CODES.R || Environment.isExternalStorageManager()
                hasAllFilesAccess = allowed
                if (allowed) {
                    val root = DocumentFile.fromFile(Environment.getExternalStorageDirectory())
                    folderStack.clear(); folderStack.add(root); refresh++
                    message = "Acesso ao armazenamento ativado."
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(hasAllFilesAccess) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && Environment.isExternalStorageManager()) {
            hasAllFilesAccess = true
            val root = DocumentFile.fromFile(Environment.getExternalStorageDirectory())
            folderStack.clear()
            folderStack.add(root)
            message = "Acesso ao armazenamento ativado."
            refresh++
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (_: Exception) { }
            val chosenFolder = DocumentFile.fromTreeUri(context, uri)
            if (chosenFolder != null) {
                when (folderPickerPurpose) {
                    PendingFolderAction.OPEN -> {
                        folderStack.clear()
                        folderStack.add(chosenFolder)
                        message = "Pasta aberta: ${chosenFolder.name ?: "Pasta"}"
                        refresh++
                    }
                    PendingFolderAction.COPY, PendingFolderAction.MOVE -> {
                        val source = selectedFile
                        if (source != null) {
                            val isMove = folderPickerPurpose == PendingFolderAction.MOVE
                            scope.launch {
                                message = if (isMove) "Movendo arquivo…" else "Copiando arquivo…"
                                val result = withContext(Dispatchers.IO) {
                                    runCatching {
                                        if (isMove && source.parentFile?.uri == chosenFolder.uri) {
                                            "O item já está nessa pasta."
                                        } else {
                                            copyDocument(context.contentResolver, source, chosenFolder)
                                            if (isMove) {
                                                if (!deleteRecursively(source)) error("A cópia foi feita, mas não foi possível excluir o original.")
                                                "Item movido com sucesso."
                                            } else "Item copiado com sucesso."
                                        }
                                    }.fold({ it }, { "Não foi possível concluir: ${it.message ?: "erro de acesso"}" })
                                }
                                message = result
                                refresh++
                                selectedFile = null
                            }
                        }
                    }
                }
            } else message = "Não foi possível abrir a pasta escolhida."
        }
    }

    val currentFolder = folderStack.lastOrNull()
    val entries = remember(currentFolder, showHidden, refresh) {
        (currentFolder?.listFiles()?.toList() ?: emptyList())
            .filter { showHidden || !(it.name ?: "").startsWith(".") }
            .sortedWith(compareByDescending<DocumentFile> { it.isDirectory }.thenBy { (it.name ?: "").lowercase() })
    }

    MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
        Scaffold { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.weight(1f)) {
                        Text("FileMaster", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Text("Gerenciador de arquivos", style = MaterialTheme.typography.bodyMedium)
                    }
                    TextButton(onClick = { dark = !dark }) { Text(if (dark) "☀ Claro" else "☾ Escuro") }
                }
                Spacer(Modifier.height(14.dp))
                StorageCard()
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !Environment.isExternalStorageManager()) {
                            openStorageSettings()
                        } else {
                            hasAllFilesAccess = true
                            val root = DocumentFile.fromFile(Environment.getExternalStorageDirectory())
                            folderStack.clear(); folderStack.add(root); refresh++
                            message = "Armazenamento interno aberto."
                        }
                    }) { Text(if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !Environment.isExternalStorageManager()) "Permitir acesso" else "Armazenamento") }
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton(onClick = { folderPickerPurpose = PendingFolderAction.OPEN; picker.launch(null) }) { Text("Escolher pasta") }
                    Spacer(Modifier.width(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = showHidden, onCheckedChange = { showHidden = it; refresh++ })
                        Text("Ocultos", style = MaterialTheme.typography.bodyMedium)
                    }
                }
                Text(message, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp, bottom = 8.dp))

                if (currentFolder != null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(currentFolder.name ?: "Arquivos", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f), maxLines = 1)
                        TextButton(onClick = { if (folderStack.size > 1) { folderStack.removeAt(folderStack.lastIndex); refresh++ } }, enabled = folderStack.size > 1) { Text("Voltar") }
                        TextButton(onClick = { refresh++ }) { Text("Atualizar") }
                    }
                    if (entries.isEmpty()) {
                        Text("Esta pasta está vazia.", modifier = Modifier.padding(vertical = 16.dp))
                    }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        items(entries, key = { it.uri.toString() }) { item ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(if (item.isDirectory) "📁" else if (isZip(item.name)) "🗜️" else "📄", modifier = Modifier.width(34.dp))
                                Column(Modifier.weight(1f).clickable {
                                    if (item.isDirectory) { folderStack.add(item); refresh++ }
                                    else {
                                        val intent = Intent(Intent.ACTION_VIEW).apply {
                                            setDataAndType(item.uri, context.contentResolver.getType(item.uri) ?: "*/*")
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        try { context.startActivity(Intent.createChooser(intent, "Abrir arquivo com")) }
                                        catch (_: Exception) { message = "Nenhum aplicativo compatível encontrado." }
                                    }
                                }.padding(vertical = 4.dp)) {
                                    Text(item.name ?: "(sem nome)", maxLines = 1, style = MaterialTheme.typography.bodyLarge)
                                    Text(if (item.isDirectory) "Pasta" else formatSize(item.length()), style = MaterialTheme.typography.bodySmall)
                                }
                                Box {
                                    TextButton(onClick = { menuFileUri = item.uri.toString(); selectedFile = item }) { Text("⋮") }
                                    DropdownMenu(expanded = menuFileUri == item.uri.toString(), onDismissRequest = { menuFileUri = null }) {
                                        DropdownMenuItem(text = { Text("Copiar para…") }, onClick = {
                                            menuFileUri = null; selectedFile = item; folderPickerPurpose = PendingFolderAction.COPY; picker.launch(null)
                                        })
                                        DropdownMenuItem(text = { Text("Mover para…") }, onClick = {
                                            menuFileUri = null; selectedFile = item; folderPickerPurpose = PendingFolderAction.MOVE; picker.launch(null)
                                        })
                                        DropdownMenuItem(text = { Text("Renomear") }, onClick = {
                                            menuFileUri = null; selectedFile = item; renameText = item.name ?: ""; renameDialog = true
                                        })
                                        DropdownMenuItem(text = { Text("Excluir") }, onClick = {
                                            menuFileUri = null; selectedFile = item; deleteDialog = true
                                        })
                                        if (!item.isDirectory && isZip(item.name)) {
                                            DropdownMenuItem(text = { Text("Extrair ZIP aqui") }, onClick = {
                                                menuFileUri = null
                                                val destination = currentFolder
                                                scope.launch {
                                                    message = "Extraindo arquivo ZIP…"
                                                    val result = withContext(Dispatchers.IO) {
                                                        runCatching { extractZip(context.contentResolver, context.contentResolver.openInputStream(item.uri), destination!!); "ZIP extraído com sucesso." }
                                                            .fold({ it }, { "Falha ao extrair ZIP: ${it.message ?: "arquivo inválido ou sem acesso"}" })
                                                    }
                                                    message = result; refresh++
                                                }
                                            })
                                        }
                                    }
                                }
                            }
                            HorizontalDivider()
                        }
                    }
                } else {
                    Spacer(Modifier.height(24.dp))
                    Text("Acesso ao armazenamento", style = MaterialTheme.typography.titleMedium)
                    Text("Toque em ‘Permitir acesso’ e ative ‘Permitir gerenciamento de todos os arquivos’ nas Configurações. Depois volte ao FileMaster. Android/data, Android/obb e áreas privadas de outros aplicativos continuam protegidos pelo sistema.")
                }
            }
        }
    }

    if (renameDialog && selectedFile != null) {
        AlertDialog(
            onDismissRequest = { renameDialog = false },
            title = { Text("Renomear item") },
            text = { OutlinedTextField(value = renameText, onValueChange = { renameText = it }, label = { Text("Novo nome") }, singleLine = true) },
            confirmButton = { TextButton(onClick = {
                val file = selectedFile
                val newName = renameText.trim()
                if (file != null && newName.isNotBlank() && !newName.contains('/') && !newName.contains('\\')) {
                    val ok = file.renameTo(newName)
                    message = if (ok) "Item renomeado." else "Não foi possível renomear este item."
                    refresh++
                } else message = "Digite um nome válido."
                renameDialog = false
            }) { Text("Renomear") } },
            dismissButton = { TextButton(onClick = { renameDialog = false }) { Text("Cancelar") } }
        )
    }

    if (deleteDialog && selectedFile != null) {
        AlertDialog(
            onDismissRequest = { deleteDialog = false },
            title = { Text("Excluir item?") },
            text = { Text("Deseja excluir ‘${selectedFile?.name ?: "item"}’? Essa ação não pode ser desfeita.") },
            confirmButton = { TextButton(onClick = {
                val file = selectedFile
                scope.launch {
                    val ok = withContext(Dispatchers.IO) { file?.let { runCatching { deleteRecursively(it) }.getOrDefault(false) } ?: false }
                    message = if (ok) "Item excluído." else "Não foi possível excluir o item."
                    refresh++
                }
                deleteDialog = false
            }) { Text("Excluir") } },
            dismissButton = { TextButton(onClick = { deleteDialog = false }) { Text("Cancelar") } }
        )
    }
}

private fun isZip(name: String?): Boolean = name?.lowercase()?.endsWith(".zip") == true

private fun uniqueName(parent: DocumentFile, wanted: String): String {
    if (parent.findFile(wanted) == null) return wanted
    val dot = wanted.lastIndexOf('.')
    val base = if (dot > 0) wanted.substring(0, dot) else wanted
    val ext = if (dot > 0) wanted.substring(dot) else ""
    var index = 1
    while (parent.findFile("$base ($index)$ext") != null) index++
    return "$base ($index)$ext"
}

private fun copyDocument(resolver: android.content.ContentResolver, source: DocumentFile, destinationParent: DocumentFile): DocumentFile {
    val sourceName = source.name ?: "arquivo"
    return if (source.isDirectory) {
        val newFolder = destinationParent.createDirectory(uniqueName(destinationParent, sourceName))
            ?: error("Não foi possível criar a pasta de destino")
        source.listFiles().forEach { child -> copyDocument(resolver, child, newFolder) }
        newFolder
    } else {
        val mime = resolver.getType(source.uri) ?: "application/octet-stream"
        val target = destinationParent.createFile(mime, uniqueName(destinationParent, sourceName))
            ?: error("Não foi possível criar o arquivo de destino")
        resolver.openInputStream(source.uri).use { input ->
            if (input == null) error("Não foi possível ler o arquivo original")
            resolver.openOutputStream(target.uri, "w").use { output ->
                if (output == null) error("Não foi possível gravar o arquivo de destino")
                input.copyTo(output)
            }
        }
        target
    }
}

private fun deleteRecursively(file: DocumentFile): Boolean {
    if (file.isDirectory) {
        var allDeleted = true
        file.listFiles().forEach { child -> if (!deleteRecursively(child)) allDeleted = false }
        if (!allDeleted) return false
    }
    return file.delete()
}

private fun extractZip(resolver: android.content.ContentResolver, input: InputStream?, destination: DocumentFile) {
    if (input == null) error("Não foi possível abrir o ZIP")
    ZipInputStream(input.buffered()).use { zip ->
        var entry = zip.nextEntry
        while (entry != null) {
            val safeName = entry.name.replace('\\', '/')
            val parts = safeName.split('/').filter { it.isNotBlank() && it != "." && it != ".." }
            if (parts.isNotEmpty()) {
                var parent = destination
                for (part in parts.dropLast(1)) {
                    parent = parent.findFile(part)?.takeIf { it.isDirectory }
                        ?: parent.createDirectory(uniqueName(parent, part))
                        ?: error("Não foi possível criar a pasta $part")
                }
                val leaf = parts.last()
                if (entry.isDirectory || safeName.endsWith('/')) {
                    if (parent.findFile(leaf) == null && parent.createDirectory(leaf) == null) error("Não foi possível criar a pasta $leaf")
                } else {
                    val target = parent.createFile("application/octet-stream", uniqueName(parent, leaf))
                        ?: error("Não foi possível criar o arquivo $leaf")
                    resolver.openOutputStream(target.uri, "w").use { output ->
                        if (output == null) error("Não foi possível gravar $leaf")
                        zip.copyTo(output)
                    }
                }
            }
            zip.closeEntry()
            entry = zip.nextEntry
        }
    }
}

@Composable
private fun StorageCard() {
    val stats = remember {
        try {
            val fs = StatFs(android.os.Environment.getDataDirectory().path)
            val total = fs.totalBytes; val free = fs.availableBytes
            Triple(total, free, total - free)
        } catch (_: Exception) { Triple(0L, 0L, 0L) }
    }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("Armazenamento interno", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            Text("${formatSize(stats.third)} usados · ${formatSize(stats.second)} livres")
            LinearProgressIndicator(progress = { if (stats.first > 0) stats.third.toFloat() / stats.first else 0f }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp))
            Text("Total: ${formatSize(stats.first)}", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

private fun formatSize(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val units = listOf("KB", "MB", "GB", "TB")
    var value = bytes.toDouble(); var index = -1
    do { value /= 1024.0; index++ } while (value >= 1024 && index < units.lastIndex)
    return String.format(java.util.Locale.getDefault(), "%.1f %s", value, units[index])
}
