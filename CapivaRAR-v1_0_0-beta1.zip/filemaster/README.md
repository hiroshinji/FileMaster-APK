# CapivaRAR 1.0.0-beta1

Gerenciador de arquivos Android (Kotlin + Jetpack Compose). Usa a permissão "Gerenciar todos os arquivos" e acessa o
armazenamento direto com `java.io.File`. Requer Android 11 ou superior.

## Novidades da 1.0.0-beta1

### Leitura
- **Modo leitura estilo Kindle** para PDF, EPUB, DOCX, ODT, PPTX, HTML, TXT e Markdown: o texto é extraído e reorganizado
  em parágrafos, com páginas (toque na lateral direita/esquerda para virar, no centro para os menus) ou rolagem.
  Ajustes: tema da página (papel, sépia, cinza, menta, noite, preto), fonte, tamanho, espaço entre linhas, margens, justificar,
  **brilho da tela** e **filtro de luz quente (sépia/âmbar)** para ler à noite. Lembra a página onde você parou.
  PDF digitalizado (só imagem) não tem texto: use a visualização original.
- **PDF original com dois modos:** rolagem vertical contínua ou páginas horizontais (toque nas laterais para virar,
  pinça para zoom), com ir-para-página, brilho e filtro quente. Botão "Modo leitura" para trocar para o estilo Kindle.

### Compartilhar e integrar
- **Compartilhar** arquivos pelo menu do Android (Bluetooth, WhatsApp, Quick Share, Drive, e-mail...). Pastas são
  compactadas em ZIP automaticamente antes de compartilhar. Também dá para só **compactar em ZIP**.
- O CapivaRAR aparece em **"Abrir com"** nos outros apps para imagens, vídeo, áudio, PDF, EPUB, texto, HTML, DOCX/ODT/PPTX
  e arquivos compactados. Arquivos compactados recebidos oferecem "Extrair".
- **Abrir imagens e outros tipos:** para cada tipo você escolhe abrir no leitor do CapivaRAR, em outro app, ou perguntar.
  Ao perguntar, há "Só uma vez" e "Sempre". Em "outro app" o próprio Android oferece "Só uma vez / Sempre" e lembra o padrão.
  Tudo isso em Configurações (engrenagem na tela inicial), junto com o atalho para os "Apps padrão" do Android.

### Visual
- **9 paletas de cores** (Capivara, cores do sistema, Oceano, Floresta, Sakura, Ametista, Pôr do sol, Grafite, AMOLED)
  e modo claro/escuro/automático.
- Visualização em **lista ou grade** e **busca** dentro da pasta/categoria.

## O que o app faz
- Início com armazenamento (interno e cartão SD) e acesso rápido: Downloads, Imagens, Vídeos, Áudios, Documentos, APKs,
  Compactados, Recentes e Lixeira.
- Miniaturas de fotos e vídeos (usa as miniaturas do próprio Android quando existem, então aparecem quase na hora),
  ícone real dos APKs, seleção múltipla, copiar, mover, renomear, nova pasta, ordenar e mostrar ocultos.
- Excluir apaga definitivamente por padrão; desmarque a caixa para usar a lixeira (30 dias).
- Extrair zip, tar, tar.gz, tar.bz2, tar.xz, gz, 7z e rar, com progresso e cancelamento. Senha em 7z e RAR.
- Leitores internos: imagens (deslizar, zoom), vídeo e áudio (Media3), PDF, HTML (sem JavaScript e sem internet),
  texto e código.

## Limites conhecidos
- ZIP com senha, PDF com senha e RAR5 não são suportados. O áudio não toca com o app fechado.
- Nada disto foi compilado nem testado em aparelho no ambiente em que foi escrito: se o GitHub Actions acusar erro,
  envie o trecho do log.
