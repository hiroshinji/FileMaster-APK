package com.example.filemaster

import android.content.Context
import android.os.Build
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance

enum class ThemeMode(val label: String) {
    SYSTEM("Automático"),
    LIGHT("Claro"),
    DARK("Escuro")
}

/** Paletas do app. A cor-semente gera todo o esquema claro/escuro. */
enum class AppTheme(val label: String, val seed: Long) {
    CAPIVARA("Capivara", 0xFF9A5B2E),
    DYNAMIC("Cores do sistema", 0xFF9A5B2E),
    OCEANO("Oceano", 0xFF1E6FD9),
    FLORESTA("Floresta", 0xFF2E8B57),
    SAKURA("Sakura", 0xFFD6447F),
    AMETISTA("Ametista", 0xFF7B3FC4),
    POR_DO_SOL("Pôr do sol", 0xFFE8710A),
    GRAFITE("Grafite", 0xFF5F7482),
    AMOLED("AMOLED (preto)", 0xFFD98E04)
}

fun schemeFor(theme: AppTheme, dark: Boolean, context: Context): ColorScheme {
    if (theme == AppTheme.DYNAMIC && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        return if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    }
    return seedScheme(Color(theme.seed), dark, theme == AppTheme.AMOLED)
}

private fun seedScheme(seed: Color, dark: Boolean, amoled: Boolean): ColorScheme {
    val white = Color.White
    val black = Color.Black
    return if (!dark) {
        val onSeed = if (seed.luminance() > 0.5f) black else white
        lightColorScheme(
            primary = seed,
            onPrimary = onSeed,
            primaryContainer = lerp(seed, white, 0.82f),
            onPrimaryContainer = lerp(seed, black, 0.65f),
            secondary = lerp(seed, Color(0xFF6B6B6B), 0.55f),
            onSecondary = white,
            secondaryContainer = lerp(seed, white, 0.88f),
            onSecondaryContainer = lerp(seed, black, 0.7f),
            tertiary = lerp(seed, Color(0xFF8A4F9E), 0.5f),
            onTertiary = white,
            tertiaryContainer = lerp(seed, white, 0.85f),
            onTertiaryContainer = lerp(seed, black, 0.7f),
            background = lerp(white, seed, 0.035f),
            onBackground = Color(0xFF1D1B1A),
            surface = lerp(white, seed, 0.035f),
            onSurface = Color(0xFF1D1B1A),
            surfaceVariant = lerp(white, seed, 0.14f),
            onSurfaceVariant = lerp(Color(0xFF3A3836), seed, 0.25f),
            outline = lerp(Color(0xFF7A7672), seed, 0.25f),
            outlineVariant = lerp(white, seed, 0.25f),
            surfaceContainerLowest = white,
            surfaceContainerLow = lerp(white, seed, 0.05f),
            surfaceContainer = lerp(white, seed, 0.08f),
            surfaceContainerHigh = lerp(white, seed, 0.11f),
            surfaceContainerHighest = lerp(white, seed, 0.14f)
        )
    } else {
        val base = if (amoled) black else lerp(Color(0xFF121110), seed, 0.07f)
        fun tint(a: Float) = if (amoled) lerp(black, seed, a * 0.5f) else lerp(base, seed, a)
        darkColorScheme(
            primary = lerp(seed, white, 0.45f),
            onPrimary = lerp(seed, black, 0.8f),
            primaryContainer = lerp(seed, black, 0.5f),
            onPrimaryContainer = lerp(seed, white, 0.82f),
            secondary = lerp(lerp(seed, white, 0.5f), Color(0xFFB0B0B0), 0.5f),
            onSecondary = lerp(seed, black, 0.85f),
            secondaryContainer = lerp(seed, black, 0.62f),
            onSecondaryContainer = lerp(seed, white, 0.85f),
            tertiary = lerp(lerp(seed, white, 0.5f), Color(0xFFD0A5E0), 0.5f),
            onTertiary = lerp(seed, black, 0.85f),
            tertiaryContainer = lerp(seed, black, 0.6f),
            onTertiaryContainer = lerp(seed, white, 0.85f),
            background = base,
            onBackground = Color(0xFFE8E2DF),
            surface = base,
            onSurface = Color(0xFFE8E2DF),
            surfaceVariant = tint(0.18f),
            onSurfaceVariant = lerp(Color(0xFFCFC9C5), seed, 0.1f),
            outline = lerp(Color(0xFF948F8B), seed, 0.2f),
            outlineVariant = tint(0.3f),
            surfaceContainerLowest = if (amoled) black else lerp(base, black, 0.4f),
            surfaceContainerLow = tint(0.05f),
            surfaceContainer = tint(0.09f),
            surfaceContainerHigh = tint(0.13f),
            surfaceContainerHighest = tint(0.17f)
        )
    }
}
