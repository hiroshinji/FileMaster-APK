package com.example.filemaster

import android.app.Activity
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.webkit.MimeTypeMap
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.core.view.WindowCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : ComponentActivity() {
    // Arquivo recebido de outro app ("Abrir com o CapivaRAR").
    private val incoming = mutableStateOf<Uri?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) incoming.value = uriFrom(intent)
        setContent { CapivaRARLaunch(incoming) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        incoming.value = uriFrom(intent)
    }

    private fun uriFrom(i: Intent?): Uri? = if (i != null && i.action == Intent.ACTION_VIEW) i.data else null
}

@Composable
private fun CapivaRARLaunch(incoming: MutableState<Uri?>) {
    // Quando outro app abre um arquivo, vai direto ao leitor (sem a abertura com a capivara).
    var showSplash by remember { mutableStateOf(incoming.value == null) }
    LaunchedEffect(Unit) {
        if (showSplash) {
            delay(1000)
            showSplash = false
        }
    }
    if (showSplash) {
        Column(
            modifier = Modifier.fillMaxSize().background(Color(0xFF211516)).padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.capybara_mascot),
                contentDescription = "Capivarinha do CapivaRAR",
                modifier = Modifier.fillMaxWidth(0.82f).weight(1f, fill = false).heightIn(max = 360.dp),
                contentScale = ContentScale.Fit
            )
            Spacer(Modifier.height(20.dp))
            Text("CapivaRAR", color = Color(0xFFFFE6B0), style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(8.dp))
            Text("FOTOS  •  VÍDEOS  •  ARQUIVOS", color = Color(0xFFF2D6D8), style = MaterialTheme.typography.titleSmall)
        }
    } else {
        FileMasterApp(incoming)
    }
}

private class ExtractJob(val title: String, val name: String, val cancel: AtomicBoolean)

private sealed interface UiDialog {
    data object NewFolder : UiDialog
    data class Rename(val file: File) : UiDialog
    data class Delete(val files: List<File>) : UiDialog
    data class Password(val file: File, val retry: Boolean, val destDir: File?) : UiDialog
    data class DeleteForever(val item: TrashItem) : UiDialog
    data object EmptyTrash : UiDialog
    data class OpenWith(val file: File, val viewer: Viewer) : UiDialog
    data class ExtractIncoming(val file: File, val isCopy: Boolean) : UiDialog
    data class ShareFolders(val files: List<File>) : UiDialog
}

private fun readThemeMode(p: SharedPreferences): ThemeMode {
    val s = p.getString("theme_mode", null)
    val found = ThemeMode.values().firstOrNull { it.name == s }
    if (found != null) return found
    // Migração: a versão anterior guardava só "dark".
    return if (p.contains("dark")) (if (p.getBoolean("dark", false)) ThemeMode.DARK else ThemeMode.LIGHT) else ThemeMode.SYSTEM
}

private fun readAppTheme(p: SharedPreferences): AppTheme {
    val s = p.getString("app_theme", null)
    return AppTheme.values().firstOrNull { it.name == s } ?: AppTheme.DYNAMIC
}

@Composable
private fun FileMasterApp(incoming: MutableState<Uri?>) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("capivarar", Context.MODE_PRIVATE) }
    val systemDark = isSystemInDarkTheme()

    var themeMode by remember { mutableStateOf(readThemeMode(prefs)) }
    var appTheme by remember { mutableStateOf(readAppTheme(prefs)) }
    val dark = when (themeMode) {
        ThemeMode.SYSTEM -> systemDark
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    var grid by remember { mutableStateOf(prefs.getBoolean("grid", false)) }
    var openModes by remember { mutableStateOf(OpenGroup.values().associateWith { prefs.openMode(it) }) }
    var showSettings by remember { mutableStateOf(false) }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }

    var showHidden by remember { mutableStateOf(false) }
    var sort by remember { mutableStateOf(SortMode.NAME) }
    var hasAccess by remember { mutableStateOf(Environment.isExternalStorageManager()) }
    val volumes = remember(hasAccess) { Storage.volumes(context) }
    val trash = remember(volumes) { TrashStore(volumes.map { it.root }) }

    var screen by remember { mutableStateOf(Screen.HOME) }
    var viewer by remember { mutableStateOf<Viewer?>(null) }
    var currentDir by remember { mutableStateOf<File?>(null) }
    var browseRoot by remember { mutableStateOf<File?>(null) }
    val selected = remember { mutableStateListOf<String>() }
    var clipboard by remember { mutableStateOf<Clipboard?>(null) }
    var refresh by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf<UiDialog?>(null) }
    var entries by remember { mutableStateOf(emptyList<Entry>()) }
    var loading by remember { mutableStateOf(false) }
    var listError by remember { mutableStateOf<String?>(null) }
    var trashItems by remember { mutableStateOf(emptyList<TrashItem>()) }
    var hintShown by remember { mutableStateOf(prefs.getBoolean("selection_hint_shown", false)) }
    var category by remember { mutableStateOf<Category?>(null) }
    var flatSort by remember { mutableStateOf(SortMode.DATE) }
    var extractJob by remember { mutableStateOf<ExtractJob?>(null) }
    var extractProgress by remember { mutableStateOf<ExtractProgress?>(null) }
    var cancelling by remember { mutableStateOf(false) }
    val snackbar = remember { SnackbarHostState() }

    fun toast(msg: String) {
        scope.launch {
            snackbar.currentSnackbarData?.dismiss()
            snackbar.showSnackbar(msg)
        }
    }

    // Roda a operação fora da thread principal; o bloco devolve a mensagem a mostrar.
    fun runTask(block: () -> String) {
        scope.launch {
            busy = true
            val message = try {
                withContext(Dispatchers.IO) { block() }
            } catch (e: Exception) {
                "Operação falhou: ${e.message ?: "erro desconhecido"}"
            }
            busy = false
            refresh++
            toast(message)
        }
    }

    fun requestAccess() {
        try {
            context.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${context.packageName}")))
        } catch (_: Exception) {
            try {
                context.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            } catch (_: Exception) {
                toast("Abra Configurações > Aplicativos > CapivaRAR > Permissões.")
            }
        }
    }

    fun hint() {
        if (!hintShown) {
            hintShown = true
            prefs.edit().putBoolean("selection_hint_shown", true).apply()
            toast("Dica da Capivarinha 🦫: segure um item para selecionar vários.")
        }
    }

    fun openFolder(dir: File, root: File) {
        if (!dir.isDirectory) {
            toast("Pasta não encontrada.")
            return
        }
        category = null
        currentDir = dir
        browseRoot = root
        selected.clear()
        screen = Screen.BROWSER
        hint()
    }

    fun openCategory(c: Category) {
        category = c
        currentDir = null
        selected.clear()
        entries = emptyList()
        screen = Screen.BROWSER
        hint()
    }

    fun goBack() {
        when {
            viewer != null -> viewer = null
            selected.isNotEmpty() -> selected.clear()
            searching -> {
                searching = false
                query = ""
            }
            screen == Screen.TRASH -> screen = Screen.HOME
            screen == Screen.BROWSER && category != null -> {
                category = null
                screen = Screen.HOME
            }
            screen == Screen.BROWSER -> {
                val d = currentDir
                val r = browseRoot
                val parent = d?.parentFile
                if (d != null && r != null && parent != null && d.absolutePath != r.absolutePath) {
                    currentDir = parent
                } else {
                    screen = Screen.HOME
                }
            }
        }
    }

    /** Abre em outro app. Usa o menu nativo do Android, que já oferece "Só uma vez" e "Sempre". */
    fun openExternal(file: File) {
        val ext = file.extension.lowercase()
        val isApk = ext == "apk"
        try {
            if (!file.isFile || !file.canRead()) {
                toast("Não foi possível ler este arquivo.")
                return
            }
            if (isApk && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !context.packageManager.canRequestPackageInstalls()) {
                val settingsIntent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${context.packageName}"))
                settingsIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(settingsIntent)
                toast("Permita instalar apps desconhecidos para o CapivaRAR e toque no APK novamente.")
                return
            }
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val mime = if (isApk) "application/vnd.android.package-archive" else (MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*")
            val intent = Intent(if (isApk) Intent.ACTION_INSTALL_PACKAGE else Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                clipData = ClipData.newRawUri("", uri)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            toast(if (isApk) "Não foi possível iniciar o instalador. Verifique a permissão para instalar apps desconhecidos e se o APK está íntegro." else "Nenhum aplicativo compatível encontrado.")
        }
    }

    fun shareFiles(files: List<File>) {
        try {
            ShareHelper.share(context, files)
        } catch (_: Exception) {
            toast("Não foi possível abrir o menu de compartilhamento.")
        }
    }

    // Abre no leitor interno, em outro app ou pergunta, conforme a preferência de cada tipo.
    fun openFile(file: File) {
        val v = viewerFor(file, entries)
        if (v == null) {
            openExternal(file)
            return
        }
        when (openModes[groupOf(v)] ?: OpenMode.INTERNAL) {
            OpenMode.INTERNAL -> viewer = v
            OpenMode.EXTERNAL -> openExternal(file)
            OpenMode.ASK -> dialog = UiDialog.OpenWith(file, v)
        }
    }

    val viewerActions = remember {
        ViewerActions(
            openExternal = { f -> openExternal(f) },
            share = { f -> shareFiles(listOf(f)) },
            navigate = { v -> viewer = v }
        )
    }

    fun startExtract(file: File, password: String?, destDir: File? = null) {
        val dir = destDir ?: currentDir ?: file.parentFile ?: return
        selected.clear()
        val cancel = AtomicBoolean(false)
        extractJob = ExtractJob("Extraindo…", file.name, cancel)
        extractProgress = null
        cancelling = false
        scope.launch {
            busy = true
            val result = try {
                withContext(Dispatchers.IO) {
                    Extractor.extract(file, dir, password, cancel) { p -> extractProgress = p }
                }
            } catch (_: Exception) {
                ExtractResult.Failed("Falha inesperada na extração.")
            }
            busy = false
            extractJob = null
            extractProgress = null
            refresh++
            when (result) {
                is ExtractResult.Done -> {
                    toast(
                        "Extraído em \"${result.folderName}\": ${result.files} arquivo(s)" +
                            (if (result.skipped > 0) " · ${result.skipped} ignorado(s)" else "")
                    )
                    withContext(Dispatchers.IO) { MediaScan.scan(context, listOf(File(dir, result.folderName).absolutePath)) }
                }
                ExtractResult.NeedPassword -> dialog = UiDialog.Password(file, password != null, destDir)
                ExtractResult.Cancelled -> toast("Extração cancelada.")
                is ExtractResult.Failed -> toast(result.reason)
            }
        }
    }

    /** Compacta em ZIP: para guardar na pasta atual ou, com [forShare], para compartilhar pastas. */
    fun startCompress(files: List<File>, forShare: Boolean) {
        if (files.isEmpty()) return
        val destDir = if (forShare) {
            File(context.cacheDir, "share").also { it.mkdirs() }
        } else {
            currentDir ?: files[0].parentFile ?: return
        }
        val first = files[0]
        val base = if (files.size == 1) (if (first.isFile) first.nameWithoutExtension.ifBlank { first.name } else first.name) else "Arquivos"
        val dest = FileOps.uniqueFile(destDir, "$base.zip")
        selected.clear()
        val cancel = AtomicBoolean(false)
        extractJob = ExtractJob("Compactando…", dest.name, cancel)
        extractProgress = null
        cancelling = false
        scope.launch {
            busy = true
            val outcome: String? = try {
                withContext(Dispatchers.IO) { Archiver.zip(files, dest, cancel) { p -> extractProgress = p } }
                null
            } catch (_: ArchiveCancelled) {
                dest.delete()
                "Compactação cancelada."
            } catch (e: Exception) {
                dest.delete()
                "Não foi possível compactar: ${e.message ?: "erro desconhecido"}"
            }
            busy = false
            extractJob = null
            extractProgress = null
            refresh++
            if (outcome != null) {
                toast(outcome)
            } else if (forShare) {
                shareFiles(listOf(dest))
            } else {
                toast("Criado \"${dest.name}\".")
                withContext(Dispatchers.IO) { MediaScan.scan(context, listOf(dest.absolutePath)) }
            }
        }
    }

    fun selectedFiles(): List<File> = entries.filter { selected.contains(it.path) }.map { it.file }

    fun paste() {
        val clip = clipboard ?: return
        val dest = currentDir ?: return
        clipboard = null
        selected.clear()
        runTask {
            val r = FileOps.pasteAll(clip.files, dest, clip.move)
            MediaScan.scan(context, r.created.map { it.absolutePath } + (if (clip.move) clip.files.map { it.absolutePath } else emptyList()))
            val verb = if (clip.move) "movido(s)" else "copiado(s)"
            if (r.failed == 0) "${r.ok} item(ns) $verb." else "${r.ok} $verb, ${r.failed} falharam."
        }
    }

    // ── efeitos ──
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) hasAccess = Environment.isExternalStorageManager()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(Unit) { withContext(Dispatchers.IO) { ShareHelper.cleanup(context) } }

    LaunchedEffect(hasAccess, trash) {
        if (hasAccess) withContext(Dispatchers.IO) { trash.purgeExpired() }
    }

    LaunchedEffect(screen, refresh, hasAccess, trash) {
        if (hasAccess && screen != Screen.BROWSER) {
            trashItems = withContext(Dispatchers.IO) { trash.list() }
        }
    }

    // A busca vale só para a lista atual: some ao trocar de pasta ou categoria.
    LaunchedEffect(currentDir, category) {
        query = ""
        searching = false
    }

    LaunchedEffect(currentDir, category, refresh, showHidden, sort, flatSort, screen) {
        if (screen == Screen.BROWSER) {
            val cat = category
            val dir = currentDir
            if (cat != null) {
                loading = true
                if (flatSort == SortMode.DATE) {
                    // 1) primeira página na hora; 2) o restante em segundo plano. As chaves da lista são as mesmas,
                    // então a rolagem não "pula" quando o restante chega.
                    val first = withContext(Dispatchers.IO) { Categories.query(context, cat, 400) }
                    entries = first
                    listError = null
                    loading = false
                    if (first.size >= 400) {
                        entries = withContext(Dispatchers.IO) { Categories.query(context, cat) }
                    }
                } else {
                    entries = withContext(Dispatchers.IO) { sortEntries(Categories.query(context, cat), flatSort) }
                    listError = null
                    loading = false
                }
            } else if (dir != null) {
                loading = true
                val result = withContext(Dispatchers.IO) { listDir(dir, showHidden, sort, context) }
                entries = result ?: emptyList()
                listError = if (result == null) "Sem permissão para ler esta pasta." else null
                loading = false
            }
        }
    }

    // Arquivo vindo de outro app: abre direto no leitor (ou oferece extrair, se for compactado).
    LaunchedEffect(incoming.value) {
        val uri = incoming.value ?: return@LaunchedEffect
        incoming.value = null
        busy = true
        val res = withContext(Dispatchers.IO) { Incoming.resolve(context, uri) }
        busy = false
        if (res == null) {
            toast("Não foi possível abrir este arquivo.")
            return@LaunchedEffect
        }
        val f = res.file
        if (Extractor.isSupported(f.name)) {
            dialog = UiDialog.ExtractIncoming(f, res.isCopy)
            return@LaunchedEffect
        }
        val siblings: List<Entry> = if (!res.isCopy) {
            withContext(Dispatchers.IO) { f.parentFile?.let { listDir(it, false, SortMode.NAME, context) } } ?: emptyList()
        } else {
            emptyList()
        }
        val v = viewerFor(f, siblings)
        if (v != null) viewer = v else toast("O CapivaRAR ainda não tem leitor para este tipo de arquivo.")
    }

    BackHandler(enabled = screen != Screen.HOME || selected.isNotEmpty() || viewer != null || searching) { goBack() }

    // Cor dos ícones da barra de status/navegação acompanha o tema escolhido no app.
    val view = LocalView.current
    val vw = viewer
    val darkViewer = vw is Viewer.Image || (vw is Viewer.Media && vw.video)
    SideEffect {
        val window = (view.context as? Activity)?.window
        if (window != null) {
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !dark && !darkViewer
            controller.isAppearanceLightNavigationBars = !dark && !darkViewer
        }
    }

    val colors = remember(dark, appTheme, context) { schemeFor(appTheme, dark, context) }

    // Lista com a busca aplicada.
    val shownEntries = remember(entries, query) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) entries else entries.filter { it.sortKey.contains(q) }
    }

    MaterialTheme(colorScheme = colors) {
        Box(Modifier.fillMaxSize()) {
            Surface(Modifier.fillMaxSize()) {
                when (screen) {
                    Screen.HOME -> HomeScreen(
                        hasAccess = hasAccess,
                        volumes = volumes,
                        trashCount = trashItems.size,
                        dark = dark,
                        snackbar = snackbar,
                        onToggleTheme = {
                            themeMode = if (dark) ThemeMode.LIGHT else ThemeMode.DARK
                            prefs.edit().putString("theme_mode", themeMode.name).apply()
                        },
                        onOpenSettings = { showSettings = true },
                        onRequestAccess = { requestAccess() },
                        onOpenVolume = { v -> openFolder(v.root, v.root) },
                        onOpenShortcut = { f -> openFolder(f, volumes.first().root) },
                        onOpenCategory = { c -> openCategory(c) },
                        onOpenTrash = { screen = Screen.TRASH }
                    )

                    Screen.BROWSER -> {
                        val dir = currentDir
                        val cat = category
                        if (dir != null || cat != null) {
                            val title = cat?.label
                                ?: dir?.let { d -> volumes.firstOrNull { it.root.absolutePath == d.absolutePath }?.label ?: d.name.ifBlank { "Armazenamento" } }
                                ?: ""
                            val flat = cat != null
                            BrowserScreen(
                                title = title,
                                path = if (flat) "${entries.size} arquivo(s)" else (dir?.absolutePath ?: ""),
                                entries = shownEntries,
                                loading = loading,
                                busy = busy,
                                error = listError,
                                selected = selected,
                                sort = if (flat) flatSort else sort,
                                showHidden = showHidden,
                                clipboard = if (flat) null else clipboard,
                                flat = flat,
                                grid = grid,
                                searching = searching,
                                query = query,
                                snackbar = snackbar,
                                onBack = { goBack() },
                                onOpen = { e -> if (e.isDir) { selected.clear(); currentDir = e.file } else openFile(e.file) },
                                onToggle = { e ->
                                    val p = e.path
                                    if (selected.contains(p)) selected.remove(p) else selected.add(p)
                                },
                                onNewFolder = { dialog = UiDialog.NewFolder },
                                onToggleHidden = { showHidden = !showHidden },
                                onSort = { if (flat) flatSort = it else sort = it },
                                onSelectAll = {
                                    selected.clear()
                                    selected.addAll(shownEntries.map { it.path })
                                },
                                onClearSelection = { selected.clear() },
                                onCopy = {
                                    val files = selectedFiles()
                                    clipboard = Clipboard(files, move = false)
                                    selected.clear()
                                    toast("${files.size} item(ns) copiado(s). Abra a pasta de destino e toque em Colar aqui.")
                                },
                                onCut = {
                                    val files = selectedFiles()
                                    clipboard = Clipboard(files, move = true)
                                    selected.clear()
                                    toast("${files.size} item(ns) para mover. Abra a pasta de destino e toque em Colar aqui.")
                                },
                                onDelete = { dialog = UiDialog.Delete(selectedFiles()) },
                                onRename = { selectedFiles().firstOrNull()?.let { dialog = UiDialog.Rename(it) } },
                                onExtract = { selectedFiles().firstOrNull()?.let { startExtract(it, null) } },
                                onShare = {
                                    val files = selectedFiles()
                                    when {
                                        files.isEmpty() -> {}
                                        files.any { it.isDirectory } -> dialog = UiDialog.ShareFolders(files)
                                        else -> {
                                            shareFiles(files)
                                            selected.clear()
                                        }
                                    }
                                },
                                onCompress = { startCompress(selectedFiles(), false) },
                                onPaste = { paste() },
                                onCancelPaste = { clipboard = null },
                                onToggleGrid = {
                                    grid = !grid
                                    prefs.edit().putBoolean("grid", grid).apply()
                                },
                                onSearch = {
                                    searching = !searching
                                    if (!searching) query = ""
                                },
                                onQueryChange = { query = it }
                            )
                        }
                    }

                    Screen.TRASH -> TrashScreen(
                        items = trashItems,
                        busy = busy,
                        snackbar = snackbar,
                        onBack = { screen = Screen.HOME },
                        onRestore = { item -> runTask { trash.restore(item) ?: "\"${item.name}\" restaurado." } },
                        onDelete = { item -> dialog = UiDialog.DeleteForever(item) },
                        onEmpty = { dialog = UiDialog.EmptyTrash }
                    )
                }
            }
            // Leitor por cima da lista: a lista continua "viva" por baixo e volta exatamente onde estava.
            val openViewer = viewer
            if (openViewer != null) {
                ViewerHost(openViewer, viewerActions, onClose = { viewer = null })
            }
        }

        if (showSettings) {
            SettingsDialog(
                themeMode = themeMode,
                appTheme = appTheme,
                openModes = openModes,
                onThemeMode = {
                    themeMode = it
                    prefs.edit().putString("theme_mode", it.name).apply()
                },
                onAppTheme = {
                    appTheme = it
                    prefs.edit().putString("app_theme", it.name).apply()
                },
                onOpenMode = { g, m ->
                    prefs.saveOpenMode(g, m)
                    openModes = openModes + (g to m)
                },
                onDefaultApps = {
                    try {
                        context.startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
                    } catch (_: Exception) {
                        toast("Abra Configurações > Apps > Apps padrão.")
                    }
                },
                onDismiss = { showSettings = false }
            )
        }

        when (val d = dialog) {
            null -> {}
            UiDialog.NewFolder -> NameDialog("Nova pasta", "", "Criar", { dialog = null }) { name ->
                dialog = null
                val dir = currentDir
                if (dir != null) runTask { FileOps.createFolder(dir, name) ?: "Pasta criada." }
            }
            is UiDialog.Rename -> NameDialog("Renomear", d.file.name, "Renomear", { dialog = null }) { name ->
                dialog = null
                selected.clear()
                if (name != d.file.name) runTask {
                    val err = FileOps.rename(d.file, name)
                    if (err == null) MediaScan.scan(context, listOf(d.file.absolutePath, File(d.file.parentFile, name).absolutePath))
                    err ?: "Renomeado."
                }
            }
            is UiDialog.Delete -> DeleteDialog(d.files.size, { dialog = null }) { permanent ->
                dialog = null
                selected.clear()
                runTask {
                    var ok = 0
                    val errors = mutableListOf<String>()
                    for (f in d.files) {
                        if (permanent) {
                            if (FileOps.deleteForever(f)) ok++ else errors.add("não foi possível apagar \"${f.name}\"")
                        } else {
                            val e = trash.moveToTrash(f)
                            if (e == null) ok++ else errors.add(e)
                        }
                    }
                    MediaScan.scan(context, d.files.map { it.absolutePath })
                    val what = if (permanent) "apagado(s)" else "movido(s) para a lixeira"
                    if (errors.isEmpty()) "$ok item(ns) $what." else "$ok $what. Falha: ${errors.first()}"
                }
            }
            is UiDialog.Password -> PasswordDialog(d.retry, { dialog = null }) { pw ->
                dialog = null
                startExtract(d.file, pw, d.destDir)
            }
            is UiDialog.DeleteForever -> ConfirmDialog(
                title = "Apagar definitivamente?",
                text = "\"${d.item.name}\" será apagado e não poderá ser recuperado.",
                confirm = "Apagar",
                onDismiss = { dialog = null }
            ) {
                dialog = null
                runTask { if (trash.deleteForever(d.item)) "Item apagado." else "Não foi possível apagar." }
            }
            UiDialog.EmptyTrash -> ConfirmDialog(
                title = "Esvaziar a lixeira?",
                text = "Todos os itens da lixeira serão apagados definitivamente.",
                confirm = "Esvaziar",
                onDismiss = { dialog = null }
            ) {
                dialog = null
                runTask {
                    val failed = trash.emptyAll()
                    if (failed == 0) "Lixeira esvaziada." else "$failed item(ns) não puderam ser apagados."
                }
            }
            is UiDialog.OpenWith -> OpenWithDialog(d.file.name, { internal, always ->
                dialog = null
                if (always) {
                    val g = groupOf(d.viewer)
                    val m = if (internal) OpenMode.INTERNAL else OpenMode.EXTERNAL
                    prefs.saveOpenMode(g, m)
                    openModes = openModes + (g to m)
                }
                if (internal) viewer = d.viewer else openExternal(d.file)
            }, { dialog = null })
            is UiDialog.ExtractIncoming -> {
                val dest = if (d.isCopy) Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) else d.file.parentFile
                ConfirmDialog(
                    title = "Extrair arquivo?",
                    text = "Extrair \"${d.file.name}\" ${if (dest != null) "em ${dest.name}" else "aqui"}?",
                    confirm = "Extrair",
                    onDismiss = { dialog = null }
                ) {
                    dialog = null
                    if (!hasAccess) toast("Permita o acesso aos arquivos na tela inicial para extrair.") else startExtract(d.file, null, dest)
                }
            }
            is UiDialog.ShareFolders -> ConfirmDialog(
                title = "Compartilhar pastas?",
                text = "As pastas serão compactadas em um ZIP antes de compartilhar.",
                confirm = "Compactar e compartilhar",
                onDismiss = { dialog = null }
            ) {
                dialog = null
                startCompress(d.files, true)
            }
        }

        val job = extractJob
        if (job != null) {
            ExtractProgressDialog(job.title, job.name, extractProgress, cancelling) {
                cancelling = true
                job.cancel.set(true)
            }
        }
    }
}
