package com.example.filemaster

import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import java.io.File

class IncomingFile(val file: File, val isCopy: Boolean)

/** Resolve o arquivo recebido de outro app ("Abrir com o CapivaRAR"). */
object Incoming {
    private const val MAX_COPY = 1024L * 1024L * 1024L // 1 GB

    fun resolve(context: Context, uri: Uri): IncomingFile? {
        if (uri.scheme == "file") {
            val f = uri.path?.let { File(it) }
            return if (f != null && f.isFile && f.canRead()) IncomingFile(f, false) else null
        }
        if (uri.scheme != "content") return null

        // 1) Caminho real no armazenamento (permite ver as outras fotos da pasta e não gasta espaço).
        try {
            context.contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.DATA), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val p = c.getString(0)
                    if (p != null) {
                        val f = File(p)
                        if (f.isFile && f.canRead()) return IncomingFile(f, false)
                    }
                }
            }
        } catch (_: Exception) {
            // provedor sem caminho: copia abaixo
        }

        // 2) Cópia temporária no cache do app.
        var name = "arquivo"
        var size = -1L
        try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) c.getString(i)?.let { name = it }
                    val j = c.getColumnIndex(OpenableColumns.SIZE)
                    if (j >= 0 && !c.isNull(j)) size = c.getLong(j)
                }
            }
        } catch (_: Exception) {
        }
        if (size > MAX_COPY) return null
        name = name.replace('/', '_').ifBlank { "arquivo" }
        if (!name.contains('.')) {
            val type = context.contentResolver.getType(uri)
            val ext = if (type != null) MimeTypeMap.getSingleton().getExtensionFromMimeType(type) else null
            if (ext != null) name += ".$ext"
        }
        val dir = File(context.cacheDir, "incoming")
        dir.mkdirs()
        val dest = FileOps.uniqueFile(dir, name)
        return try {
            val input = context.contentResolver.openInputStream(uri) ?: return null
            input.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
            IncomingFile(dest, true)
        } catch (_: Exception) {
            dest.delete()
            null
        }
    }
}
