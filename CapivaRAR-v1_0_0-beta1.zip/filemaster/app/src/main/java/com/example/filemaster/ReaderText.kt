package com.example.filemaster

import android.content.Context
import android.text.Html
import android.util.Xml
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.net.URLDecoder
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.ZipFile

enum class ReaderSource { TEXT, MARKDOWN, DOCX, ODT, PPTX, EPUB, HTML, PDF }

/** Documento já separado em parágrafos, pronto para o leitor "estilo livro". */
class ReaderDoc(val paragraphs: List<String>, val note: String?)

class ReaderFailure(message: String) : Exception(message)
class ReaderCancelled : Exception("cancelado")

/** Extrai o texto de vários formatos e o reorganiza em parágrafos (reflow), como um leitor de e-books. */
object ReaderText {
    private const val MAX_CHARS = 12_000_000

    fun load(
        context: Context,
        file: File,
        source: ReaderSource,
        cancel: AtomicBoolean,
        onProgress: (Float?, String) -> Unit
    ): ReaderDoc {
        onProgress(null, "Preparando…")
        return when (source) {
            ReaderSource.TEXT -> plain(file, false)
            ReaderSource.MARKDOWN -> plain(file, true)
            ReaderSource.DOCX -> office(file, TextMode.DOCX)
            ReaderSource.ODT -> office(file, TextMode.ODT)
            ReaderSource.PPTX -> office(file, TextMode.PPTX)
            ReaderSource.EPUB -> epub(file, cancel, onProgress)
            ReaderSource.HTML -> html(file)
            ReaderSource.PDF -> pdf(context, file, cancel, onProgress)
        }
    }

    // ── texto puro e Markdown ──

    private fun plain(file: File, markdown: Boolean): ReaderDoc {
        val r = DocText.read(file, TextMode.PLAIN)
        if (r.text.isBlank()) throw ReaderFailure(r.note ?: "Arquivo vazio.")
        var text = r.text.replace("\r", "")
        if (markdown) {
            text = text.lines().joinToString("\n") { line ->
                line.trimStart().removePrefix("###### ").removePrefix("##### ").removePrefix("#### ")
                    .removePrefix("### ").removePrefix("## ").removePrefix("# ")
                    .replace("**", "").replace("__", "").replace("`", "")
            }
        }
        val lines = text.split('\n')
        val blank = lines.count { it.isBlank() }
        val paragraphs = ArrayList<String>()
        if (blank > lines.size / 20) {
            // Texto com linhas em branco entre parágrafos: junta as linhas "quebradas" de cada parágrafo.
            val cur = StringBuilder()
            fun flush() {
                val t = cur.toString().trim()
                if (t.isNotEmpty()) paragraphs.add(t)
                cur.setLength(0)
            }
            for (l in lines) {
                val t = l.trim()
                if (t.isEmpty()) flush() else {
                    if (cur.isNotEmpty()) {
                        if (cur.endsWith("-") && t.firstOrNull()?.isLowerCase() == true) cur.setLength(cur.length - 1) else cur.append(' ')
                    }
                    cur.append(t)
                }
            }
            flush()
        } else {
            for (l in lines) {
                val t = l.trim()
                if (t.isNotEmpty()) paragraphs.add(t)
            }
        }
        return ReaderDoc(paragraphs, r.note)
    }

    // ── DOCX / ODT / PPTX ──

    private fun office(file: File, mode: TextMode): ReaderDoc {
        val r = DocText.read(file, mode)
        val paragraphs = r.text.split('\n').map { it.trim() }.filter { it.isNotEmpty() }
        if (paragraphs.isEmpty()) throw ReaderFailure(r.note ?: "Nenhum texto encontrado neste documento.")
        return ReaderDoc(paragraphs, r.note)
    }

    // ── HTML ──

    private fun htmlToParagraphs(html: String): List<String> {
        val cleaned = html.replace(Regex("(?is)<(script|style|head)[^>]*>.*?</\\1>"), " ")
        val text = Html.fromHtml(cleaned, Html.FROM_HTML_MODE_LEGACY).toString().replace('\uFFFC', ' ')
        val ws = Regex("\\s+")
        return text.split('\n').map { it.replace(ws, " ").trim() }.filter { it.isNotEmpty() }
    }

    private fun readLimited(input: InputStream, max: Int): ByteArray {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(16 * 1024)
        var total = 0
        while (total < max) {
            val n = input.read(buf, 0, minOf(buf.size, max - total))
            if (n < 0) break
            out.write(buf, 0, n)
            total += n
        }
        return out.toByteArray()
    }

    private fun html(file: File): ReaderDoc {
        val bytes = file.inputStream().use { readLimited(it, 4 * 1024 * 1024) }
        val paragraphs = htmlToParagraphs(String(bytes, Charsets.UTF_8))
        if (paragraphs.isEmpty()) throw ReaderFailure("Nenhum texto encontrado nesta página.")
        return ReaderDoc(paragraphs, if (file.length() > bytes.size) "Mostrando só o início da página." else null)
    }

    // ── EPUB ──

    private fun zipPath(base: String, rel: String): String {
        val parts = ArrayList<String>()
        if (base.isNotEmpty()) parts.addAll(base.split('/'))
        for (seg in rel.split('/')) {
            when (seg) {
                "", "." -> {}
                ".." -> if (parts.isNotEmpty()) parts.removeAt(parts.size - 1)
                else -> parts.add(seg)
            }
        }
        return parts.joinToString("/")
    }

    private fun epub(file: File, cancel: AtomicBoolean, onProgress: (Float?, String) -> Unit): ReaderDoc {
        return ZipFile(file).use { zf ->
            val container = zf.getEntry("META-INF/container.xml") ?: throw ReaderFailure("EPUB inválido (sem container.xml).")
            var opfPath: String? = null
            zf.getInputStream(container).use { s ->
                val p = Xml.newPullParser()
                p.setInput(s, null)
                var ev = p.eventType
                while (ev != XmlPullParser.END_DOCUMENT) {
                    if (ev == XmlPullParser.START_TAG && p.name.substringAfter(':') == "rootfile") {
                        opfPath = p.getAttributeValue(null, "full-path")
                        break
                    }
                    ev = p.next()
                }
            }
            val opf = opfPath ?: throw ReaderFailure("EPUB inválido (sem pacote OPF).")
            val opfEntry = zf.getEntry(opf) ?: throw ReaderFailure("EPUB inválido (OPF não encontrado).")
            val manifest = HashMap<String, String>()
            val spine = ArrayList<String>()
            zf.getInputStream(opfEntry).use { s ->
                val p = Xml.newPullParser()
                p.setInput(s, null)
                var ev = p.eventType
                while (ev != XmlPullParser.END_DOCUMENT) {
                    if (ev == XmlPullParser.START_TAG) {
                        when (p.name.substringAfter(':')) {
                            "item" -> {
                                val id = p.getAttributeValue(null, "id")
                                val href = p.getAttributeValue(null, "href")
                                if (id != null && href != null) manifest[id] = href
                            }
                            "itemref" -> p.getAttributeValue(null, "idref")?.let { spine.add(it) }
                        }
                    }
                    ev = p.next()
                }
            }
            if (spine.isEmpty()) throw ReaderFailure("Este EPUB não tem capítulos legíveis.")
            val baseDir = opf.substringBeforeLast('/', "")
            val paragraphs = ArrayList<String>()
            var chars = 0L
            for ((i, idref) in spine.withIndex()) {
                if (cancel.get()) throw ReaderCancelled()
                val href = manifest[idref] ?: continue
                val path = zipPath(baseDir, URLDecoder.decode(href.substringBefore('#'), "UTF-8"))
                val entry = zf.getEntry(path) ?: continue
                val html = zf.getInputStream(entry).use { readLimited(it, 4 * 1024 * 1024) }
                for (para in htmlToParagraphs(String(html, Charsets.UTF_8))) {
                    paragraphs.add(para)
                    chars += para.length
                }
                onProgress((i + 1f) / spine.size, "Capítulo ${i + 1} de ${spine.size}")
                if (chars > MAX_CHARS) break
            }
            if (paragraphs.isEmpty()) throw ReaderFailure("Nenhum texto encontrado neste EPUB.")
            ReaderDoc(paragraphs, if (chars > MAX_CHARS) "Mostrando só o início do livro." else null)
        }
    }

    // ── PDF (extração de texto com PdfBox) ──

    private fun cacheFor(context: Context, file: File): File {
        val raw = file.absolutePath + "|" + file.lastModified() + "|" + file.length()
        val hash = MessageDigest.getInstance("SHA-1").digest(raw.toByteArray()).joinToString("") { "%02x".format(it) }
        return File(File(context.cacheDir, "reader"), "$hash.txt")
    }

    private fun pdf(context: Context, file: File, cancel: AtomicBoolean, onProgress: (Float?, String) -> Unit): ReaderDoc {
        val cached = cacheFor(context, file)
        if (cached.exists()) {
            val list = cached.readText().split('\n').filter { it.isNotBlank() }
            if (list.isNotEmpty()) return ReaderDoc(list, null)
        }
        if (file.length() > 120L * 1024 * 1024) throw ReaderFailure("Este PDF é grande demais para o modo leitura. Use a visualização original.")
        PDFBoxResourceLoader.init(context.applicationContext)
        val sb = StringBuilder()
        try {
            PDDocument.load(file).use { doc ->
                if (doc.isEncrypted) throw ReaderFailure("Este PDF é protegido por senha.")
                val total = doc.numberOfPages
                val stripper = PDFTextStripper()
                for (p in 1..total) {
                    if (cancel.get()) throw ReaderCancelled()
                    stripper.startPage = p
                    stripper.endPage = p
                    sb.append(stripper.getText(doc)).append('\u000C')
                    onProgress(p.toFloat() / total, "Lendo texto: página $p de $total")
                    if (sb.length > MAX_CHARS) break
                }
            }
        } catch (e: IOException) {
            if (e.javaClass.simpleName.contains("Password")) throw ReaderFailure("Este PDF é protegido por senha.")
            throw ReaderFailure("Não foi possível ler o texto deste PDF.")
        } catch (_: OutOfMemoryError) {
            throw ReaderFailure("Memória insuficiente para este PDF. Use a visualização original.")
        }
        val paragraphs = reflow(sb.toString())
        if (paragraphs.isEmpty()) {
            throw ReaderFailure("Este PDF não tem texto selecionável (parece ser digitalizado). Use a visualização original.")
        }
        try {
            cached.parentFile?.mkdirs()
            cached.writeText(paragraphs.joinToString("\n"))
        } catch (_: Exception) {
        }
        return ReaderDoc(paragraphs, null)
    }

    private val PAGE_NUMBER = Regex("^[-–—]?\\s*\\d{1,4}\\s*[-–—]?$")
    private val LIST_START = Regex("^(\\d{1,3}[.)]|[•·▪■\\-–—*])\\s+")

    /**
     * Junta as linhas quebradas do PDF em parágrafos: remove números de página, une hifenização no fim da linha
     * e só começa parágrafo novo quando a frase terminou e a linha era curta (fim de parágrafo).
     */
    fun reflow(raw: String): List<String> {
        val lines = raw.replace("\r", "").split('\n')
        val lens = lines.map { it.trim().length }.filter { it > 20 }.sorted()
        val typical = if (lens.isEmpty()) 60 else lens[((lens.size - 1) * 0.9).toInt()]
        val out = ArrayList<String>()
        val cur = StringBuilder()
        var lastLen = 0
        fun flush() {
            val t = cur.toString().trim()
            if (t.isNotEmpty()) out.add(t)
            cur.setLength(0)
        }
        for (rawLine in lines) {
            val line = rawLine.replace('\u000C', ' ').trim()
            if (line.isEmpty()) {
                if (rawLine.contains('\u000C')) continue // fim de página: não quebra parágrafo
                flush()
                continue
            }
            if (PAGE_NUMBER.matches(line)) continue
            val letters = line.count { it.isLetter() }
            if (line.length < 60 && letters >= 4 && line == line.uppercase()) {
                flush()
                out.add(line)
                lastLen = 0
                continue
            }
            if (cur.isNotEmpty()) {
                val last = cur.last()
                val ended = last == '.' || last == '!' || last == '?' || last == ':' || last == '”' || last == '"' || last == '…'
                if (LIST_START.containsMatchIn(line) || (ended && lastLen < typical * 0.75)) {
                    flush()
                } else if (last == '-' && line.firstOrNull()?.isLowerCase() == true) {
                    cur.setLength(cur.length - 1)
                    cur.append(line)
                    lastLen = line.length
                    continue
                } else {
                    cur.append(' ')
                }
            }
            cur.append(line)
            lastLen = line.length
        }
        flush()
        return out
    }
}
