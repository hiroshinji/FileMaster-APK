@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.filemaster

import android.graphics.Paint
import android.text.Layout
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.StaticLayout
import android.text.TextPaint
import android.text.style.LeadingMarginSpan
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextIndent
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/** Texto paginado: o StaticLayout inteiro + onde cada página começa e termina (em linhas e em caracteres). */
private class BookLayout(
    val layout: StaticLayout,
    val pageStart: IntArray,
    val pageEnd: IntArray,
    val pageChar: IntArray
)

private fun buildBook(doc: ReaderDoc, s: ReaderSettings, widthPx: Int, heightPx: Int, textPx: Float): BookLayout {
    val text = SpannableStringBuilder()
    val indentPx = (textPx * 1.4f).toInt()
    val useIndent = doc.paragraphs.size < 40_000
    for ((i, p) in doc.paragraphs.withIndex()) {
        if (i > 0) text.append('\n')
        val start = text.length
        text.append(p)
        if (useIndent) text.setSpan(LeadingMarginSpan.Standard(indentPx, 0), start, text.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }
    val paint = TextPaint(Paint.ANTI_ALIAS_FLAG)
    paint.textSize = textPx
    paint.typeface = s.font.typeface
    val big = text.length > 800_000
    val builder = StaticLayout.Builder.obtain(text, 0, text.length, paint, widthPx.coerceAtLeast(50))
        .setLineSpacing(0f, s.lineSpacing)
        .setIncludePad(false)
        .setBreakStrategy(if (big) Layout.BREAK_STRATEGY_SIMPLE else Layout.BREAK_STRATEGY_HIGH_QUALITY)
        .setHyphenationFrequency(if (big) Layout.HYPHENATION_FREQUENCY_NONE else Layout.HYPHENATION_FREQUENCY_NORMAL)
    if (s.justify) builder.setJustificationMode(Layout.JUSTIFICATION_MODE_INTER_WORD)
    val layout = builder.build()

    val starts = ArrayList<Int>()
    val ends = ArrayList<Int>()
    val n = layout.lineCount
    var pageStart = 0
    var pageTop = if (n > 0) layout.getLineTop(0) else 0
    for (i in 0 until n) {
        if (layout.getLineBottom(i) - pageTop > heightPx && i > pageStart) {
            starts.add(pageStart)
            ends.add(i)
            pageStart = i
            pageTop = layout.getLineTop(i)
        }
    }
    if (n > 0) {
        starts.add(pageStart)
        ends.add(n)
    }
    val chars = IntArray(starts.size) { layout.getLineStart(starts[it]) }
    return BookLayout(layout, starts.toIntArray(), ends.toIntArray(), chars)
}

private fun indexForChar(chars: IntArray, target: Int): Int {
    if (chars.isEmpty()) return 0
    var lo = 0
    var hi = chars.size - 1
    while (lo < hi) {
        val mid = (lo + hi + 1) / 2
        if (chars[mid] <= target) lo = mid else hi = mid - 1
    }
    return lo
}

@Composable
internal fun ReaderScreen(file: File, source: ReaderSource, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val actions = LocalViewerActions.current
    val (settings, setSettings) = rememberReaderSettings()
    ApplyBrightness(settings.autoBrightness, settings.brightness)

    var doc by remember(file) { mutableStateOf<ReaderDoc?>(null) }
    var error by remember(file) { mutableStateOf<String?>(null) }
    var progress by remember(file) { mutableStateOf<Float?>(null) }
    var status by remember(file) { mutableStateOf("Preparando…") }
    val cancel = remember(file) { AtomicBoolean(false) }
    var showBars by remember { mutableStateOf(true) }
    var showSheet by remember { mutableStateOf(false) }
    val positions = remember { ReaderPositions(ctx) }
    var positionChar by remember(file) { mutableIntStateOf(positions.get(file)) }

    LaunchedEffect(file) {
        try {
            doc = withContext(Dispatchers.IO) {
                ReaderText.load(ctx, file, source, cancel) { p, s ->
                    progress = p
                    status = s
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (_: ReaderCancelled) {
            // o usuário saiu
        } catch (e: ReaderFailure) {
            error = e.message
        } catch (_: Throwable) {
            error = "Não foi possível preparar o texto deste arquivo."
        }
    }
    DisposableEffect(file) { onDispose { cancel.set(true) } }

    val bg = Color(settings.theme.bg)
    val fg = Color(settings.theme.fg)

    Box(Modifier.fillMaxSize().background(bg).warmFilter(settings.warm)) {
        val d = doc
        val err = error
        when {
            err != null -> Column(
                Modifier.fillMaxSize().padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(err, color = fg, style = MaterialTheme.typography.bodyLarge)
                Spacer(Modifier.height(16.dp))
                if (source == ReaderSource.PDF) {
                    Button(onClick = { actions.navigate(Viewer.Pdf(file)) }) { Text("Ver o PDF original") }
                } else {
                    Button(onClick = { actions.openExternal(file) }) { Text("Abrir com outro app") }
                }
                TextButton(onClick = onClose) { Text("Voltar", color = fg) }
            }
            d == null -> Column(
                Modifier.fillMaxSize().padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                val p = progress
                if (p != null) LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth())
                else LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(12.dp))
                Text(status, color = fg, style = MaterialTheme.typography.bodyMedium)
                Text("Na primeira vez pode demorar; depois fica guardado.", color = fg.copy(alpha = 0.6f), style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { cancel.set(true); onClose() }) { Text("Cancelar", color = fg) }
            }
            else -> ReaderBody(
                doc = d,
                s = settings,
                startChar = positionChar,
                fg = fg,
                bg = bg,
                barsVisible = showBars,
                onPosition = { c ->
                    positionChar = c
                    positions.put(file, c)
                },
                onToggleBars = { showBars = !showBars }
            )
        }

        if (showBars || d == null || err != null) {
            Surface(color = bg.copy(alpha = 0.96f), contentColor = fg, modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth()) {
                Row(Modifier.statusBarsPadding().height(56.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar") }
                    Text(file.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
                    if (source == ReaderSource.PDF) {
                        IconButton(onClick = { actions.navigate(Viewer.Pdf(file)) }) {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = "Ver o PDF original")
                        }
                    }
                    IconButton(onClick = { showSheet = true }) { Icon(Icons.Default.Tune, contentDescription = "Ajustes de leitura") }
                    IconButton(onClick = { actions.share(file) }) { Icon(Icons.Default.Share, contentDescription = "Compartilhar") }
                }
            }
        }
    }

    if (showSheet) ReaderSettingsSheet(settings, setSettings) { showSheet = false }
}

@Composable
private fun ReaderBody(
    doc: ReaderDoc,
    s: ReaderSettings,
    startChar: Int,
    fg: Color,
    bg: Color,
    barsVisible: Boolean,
    onPosition: (Int) -> Unit,
    onToggleBars: () -> Unit
) {
    BoxWithConstraints(Modifier.fillMaxSize().systemBarsPadding()) {
        val density = LocalDensity.current
        val marginPx = with(density) { s.marginDp.dp.roundToPx() }
        val vPadPx = with(density) { 28.dp.roundToPx() }
        val widthPx = constraints.maxWidth - 2 * marginPx
        val heightPx = constraints.maxHeight - 2 * vPadPx
        val textPx = with(density) { s.sizeSp.sp.toPx() }
        if (s.paged) {
            PagedBook(doc, s, widthPx, heightPx, textPx, startChar, fg, bg, barsVisible, onPosition, onToggleBars)
        } else {
            ScrollBook(doc, s, startChar, fg, bg, barsVisible, onPosition, onToggleBars)
        }
    }
}

@Composable
private fun BoxScope.PagedBook(
    doc: ReaderDoc,
    s: ReaderSettings,
    widthPx: Int,
    heightPx: Int,
    textPx: Float,
    startChar: Int,
    fg: Color,
    bg: Color,
    barsVisible: Boolean,
    onPosition: (Int) -> Unit,
    onToggleBars: () -> Unit
) {
    var book by remember { mutableStateOf<BookLayout?>(null) }
    var lastChar by remember { mutableIntStateOf(startChar) }
    LaunchedEffect(doc, s.font, s.sizeSp, s.lineSpacing, s.justify, widthPx, heightPx) {
        book = withContext(Dispatchers.Default) { buildBook(doc, s, widthPx, heightPx, textPx) }
    }
    val b = book
    if (b == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = fg) }
        return
    }
    if (b.pageStart.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Documento vazio.", color = fg) }
        return
    }
    key(b) {
        val pager = rememberPagerState(initialPage = indexForChar(b.pageChar, lastChar)) { b.pageStart.size }
        val scope = rememberCoroutineScope()
        LaunchedEffect(pager) {
            snapshotFlow { pager.currentPage }.collect { page ->
                lastChar = b.pageChar[page]
                onPosition(lastChar)
            }
        }
        Box(Modifier.fillMaxSize()) {
            HorizontalPager(
                state = pager,
                modifier = Modifier.fillMaxSize().pointerInput(Unit) {
                    detectTapGestures { off ->
                        val w = size.width
                        when {
                            off.x < w * 0.28f -> scope.launch { if (pager.currentPage > 0) pager.animateScrollToPage(pager.currentPage - 1) }
                            off.x > w * 0.72f -> scope.launch { if (pager.currentPage < pager.pageCount - 1) pager.animateScrollToPage(pager.currentPage + 1) }
                            else -> onToggleBars()
                        }
                    }
                }
            ) { page -> BookPage(b, page, fg, s.marginDp.dp, 28.dp) }

            Text(
                "${pager.currentPage + 1} / ${b.pageStart.size}",
                color = fg.copy(alpha = 0.55f),
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 6.dp)
            )
            if (barsVisible) {
                Surface(color = bg.copy(alpha = 0.96f), contentColor = fg, modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth()) {
                    Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                        Slider(
                            value = pager.currentPage.toFloat(),
                            onValueChange = { v -> scope.launch { pager.scrollToPage(v.toInt()) } },
                            valueRange = 0f..maxOf(1, b.pageStart.size - 1).toFloat()
                        )
                        Text(
                            "Página ${pager.currentPage + 1} de ${b.pageStart.size}  ·  ${(pager.currentPage + 1) * 100 / b.pageStart.size}%",
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BookPage(b: BookLayout, page: Int, fg: Color, hPad: Dp, vPad: Dp) {
    Canvas(Modifier.fillMaxSize().padding(horizontal = hPad, vertical = vPad)) {
        val top = b.layout.getLineTop(b.pageStart[page])
        val bottom = b.layout.getLineBottom(b.pageEnd[page] - 1)
        b.layout.paint.color = fg.toArgb()
        drawIntoCanvas { c ->
            val nc = c.nativeCanvas
            nc.save()
            nc.clipRect(0f, 0f, size.width, (bottom - top).toFloat())
            nc.translate(0f, -top.toFloat())
            b.layout.draw(nc)
            nc.restore()
        }
    }
}

@Composable
private fun BoxScope.ScrollBook(
    doc: ReaderDoc,
    s: ReaderSettings,
    startChar: Int,
    fg: Color,
    bg: Color,
    barsVisible: Boolean,
    onPosition: (Int) -> Unit,
    onToggleBars: () -> Unit
) {
    val paraStarts = remember(doc) {
        val a = IntArray(doc.paragraphs.size)
        var run = 0
        for (i in a.indices) {
            a[i] = run
            run += doc.paragraphs[i].length + 1
        }
        a
    }
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = indexForChar(paraStarts, startChar))
    LaunchedEffect(listState) {
        snapshotFlow { listState.firstVisibleItemIndex }.collect { i ->
            if (paraStarts.isNotEmpty()) onPosition(paraStarts[i.coerceIn(0, paraStarts.size - 1)])
        }
    }
    val style = TextStyle(
        fontSize = s.sizeSp.sp,
        lineHeight = (s.sizeSp * s.lineSpacing).sp,
        fontFamily = s.font.compose,
        color = fg,
        textAlign = if (s.justify) TextAlign.Justify else TextAlign.Start,
        textIndent = TextIndent(firstLine = (s.sizeSp * 1.4f).sp)
    )
    Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { onToggleBars() } }) {
        SelectionContainer {
            LazyColumn(
                state = listState,
                contentPadding = PaddingValues(horizontal = s.marginDp.dp, vertical = 28.dp),
                verticalArrangement = Arrangement.spacedBy((s.sizeSp * 0.35f).dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(doc.paragraphs.size) { i -> Text(doc.paragraphs[i], style = style) }
            }
        }
        val total = doc.paragraphs.size.coerceAtLeast(1)
        Text(
            "${(listState.firstVisibleItemIndex + 1) * 100 / total}%",
            color = fg.copy(alpha = 0.55f),
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 6.dp)
        )
    }
}

// ───────────────────────────── AJUSTES ─────────────────────────────

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 14.dp, bottom = 4.dp))
}

/** Brilho da tela + filtro de luz quente: usado no leitor e no PDF. */
@Composable
internal fun BrightnessAndFilterSection(s: ReaderSettings, onChange: (ReaderSettings) -> Unit) {
    SectionTitle("Brilho da tela")
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("Automático (sistema)", Modifier.weight(1f))
        Switch(checked = s.autoBrightness, onCheckedChange = { onChange(s.copy(autoBrightness = it)) })
    }
    Slider(
        value = s.brightness,
        onValueChange = { onChange(s.copy(brightness = it, autoBrightness = false)) },
        valueRange = 0.02f..1f
    )
    SectionTitle("Filtro de luz quente (sépia/âmbar)")
    Text("Reduz o azul para ler à noite. Deslize para aumentar.", style = MaterialTheme.typography.bodySmall)
    Slider(value = s.warm, onValueChange = { onChange(s.copy(warm = it)) }, valueRange = 0f..0.85f)
}

@Composable
private fun ReaderSettingsSheet(s: ReaderSettings, onChange: (ReaderSettings) -> Unit, onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 28.dp)) {
            BrightnessAndFilterSection(s, onChange)

            SectionTitle("Tema da página")
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ReaderTheme.values().forEach { t ->
                    Box(
                        Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(Color(t.bg))
                            .border(
                                BorderStroke(if (t == s.theme) 3.dp else 1.dp, if (t == s.theme) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline),
                                CircleShape
                            )
                            .clickable { onChange(s.copy(theme = t)) },
                        contentAlignment = Alignment.Center
                    ) { Text("A", color = Color(t.fg), style = MaterialTheme.typography.titleMedium) }
                }
            }
            Text(s.theme.label, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 4.dp))

            SectionTitle("Fonte")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ReaderFont.values().forEach { f ->
                    FilterChip(selected = f == s.font, onClick = { onChange(s.copy(font = f)) }, label = { Text(f.label) })
                }
            }

            SectionTitle("Tamanho do texto: ${s.sizeSp.toInt()}")
            Slider(value = s.sizeSp, onValueChange = { onChange(s.copy(sizeSp = it)) }, valueRange = 12f..36f)

            SectionTitle("Espaço entre linhas: ${"%.2f".format(s.lineSpacing)}")
            Slider(value = s.lineSpacing, onValueChange = { onChange(s.copy(lineSpacing = it)) }, valueRange = 1.1f..2.0f)

            SectionTitle("Margens: ${s.marginDp}")
            Slider(value = s.marginDp.toFloat(), onValueChange = { onChange(s.copy(marginDp = it.toInt())) }, valueRange = 8f..56f)

            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
                Text("Justificar texto", Modifier.weight(1f))
                Switch(checked = s.justify, onCheckedChange = { onChange(s.copy(justify = it)) })
            }

            SectionTitle("Modo de leitura")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = s.paged, onClick = { onChange(s.copy(paged = true)) }, label = { Text("Páginas (como o Kindle)") })
                FilterChip(selected = !s.paged, onClick = { onChange(s.copy(paged = false)) }, label = { Text("Rolagem") })
            }
            Text(
                "Nas páginas: toque na lateral direita ou esquerda para virar, no centro para mostrar ou esconder os menus.",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 6.dp)
            )
        }
    }
}
