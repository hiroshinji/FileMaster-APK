package com.example.filemaster

import android.content.SharedPreferences
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

/** Tipos de arquivo para a escolha "abrir no CapivaRAR ou em outro app". */
enum class OpenGroup(val label: String) {
    IMAGE("Imagens"),
    VIDEO("Vídeos"),
    AUDIO("Áudios"),
    PDF("PDF"),
    DOCS("Documentos, livros e páginas web"),
    TEXT("Texto e código")
}

enum class OpenMode(val label: String) {
    ASK("Perguntar"),
    INTERNAL("CapivaRAR"),
    EXTERNAL("Outro app")
}

fun SharedPreferences.openMode(g: OpenGroup): OpenMode {
    val s = getString("open_${g.name}", null)
    return OpenMode.values().firstOrNull { it.name == s } ?: if (g == OpenGroup.IMAGE) OpenMode.ASK else OpenMode.INTERNAL
}

fun SharedPreferences.saveOpenMode(g: OpenGroup, m: OpenMode) {
    edit().putString("open_${g.name}", m.name).apply()
}

fun groupOf(v: Viewer): OpenGroup = when (v) {
    is Viewer.Image -> OpenGroup.IMAGE
    is Viewer.Media -> if (v.video) OpenGroup.VIDEO else OpenGroup.AUDIO
    is Viewer.Pdf -> OpenGroup.PDF
    is Viewer.Reader, is Viewer.Html -> OpenGroup.DOCS
    is Viewer.TextDoc -> OpenGroup.TEXT
}

@Composable
internal fun SettingsDialog(
    themeMode: ThemeMode,
    appTheme: AppTheme,
    openModes: Map<OpenGroup, OpenMode>,
    onThemeMode: (ThemeMode) -> Unit,
    onAppTheme: (AppTheme) -> Unit,
    onOpenMode: (OpenGroup, OpenMode) -> Unit,
    onDefaultApps: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Configurações") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Aparência", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemeMode.values().forEach { m ->
                        FilterChip(selected = m == themeMode, onClick = { onThemeMode(m) }, label = { Text(m.label) })
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text("Paleta de cores", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(6.dp))
                AppTheme.values().toList().chunked(3).forEach { row ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        row.forEach { t ->
                            Column(
                                Modifier.weight(1f).clickable { onAppTheme(t) }.padding(4.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                val selected = t == appTheme
                                Box(
                                    Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(if (t == AppTheme.DYNAMIC) Color(0xFF8E8E93) else Color(t.seed))
                                        .border(
                                            BorderStroke(if (selected) 3.dp else 0.dp, MaterialTheme.colorScheme.onSurface),
                                            CircleShape
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (t == AppTheme.DYNAMIC) Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White)
                                }
                                Text(
                                    t.label,
                                    style = MaterialTheme.typography.labelSmall,
                                    textAlign = TextAlign.Center,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }

                Spacer(Modifier.height(14.dp))
                Text("Ao tocar em um arquivo", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(
                    "Escolha se cada tipo abre no leitor do CapivaRAR, em outro app, ou se o app pergunta. Toque para alternar.",
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(Modifier.height(4.dp))
                OpenGroup.values().forEach { g ->
                    val m = openModes[g] ?: OpenMode.INTERNAL
                    Row(
                        Modifier.fillMaxWidth().clickable { onOpenMode(g, OpenMode.values()[(m.ordinal + 1) % OpenMode.values().size]) }.padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(g.label, Modifier.weight(1f))
                        AssistChip(onClick = { onOpenMode(g, OpenMode.values()[(m.ordinal + 1) % OpenMode.values().size]) }, label = { Text(m.label) })
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = onDefaultApps, modifier = Modifier.fillMaxWidth()) { Text("Apps padrão do Android") }
                Spacer(Modifier.height(10.dp))
                Text("CapivaRAR 1.0.0-beta1", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fechar") } }
    )
}

@Composable
internal fun OpenWithDialog(fileName: String, onChoose: (internal: Boolean, always: Boolean) -> Unit, onDismiss: () -> Unit) {
    var internal by remember { mutableStateOf(true) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Abrir com") },
        text = {
            Column {
                Text(fileName, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(12.dp))
                ChoiceRow("CapivaRAR", "Leitor interno do app", internal) { internal = true }
                ChoiceRow("Outro aplicativo", "Escolher no Android (galeria, WhatsApp, etc.)", !internal) { internal = false }
            }
        },
        confirmButton = { Button(onClick = { onChoose(internal, true) }) { Text("Sempre") } },
        dismissButton = { TextButton(onClick = { onChoose(internal, false) }) { Text("Só uma vez") } }
    )
}

@Composable
private fun ChoiceRow(title: String, subtitle: String, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = selected, onClick = null)
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
