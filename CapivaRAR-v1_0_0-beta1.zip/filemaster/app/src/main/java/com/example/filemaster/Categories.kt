package com.example.filemaster

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.media.MediaScannerConnection
import android.os.Bundle
import android.provider.MediaStore
import java.io.File
import java.text.DateFormat

enum class Category(val label: String) {
    RECENT("Recentes"),
    IMAGES("Imagens"),
    VIDEOS("Vídeos"),
    AUDIO("Áudios"),
    DOCS("Documentos"),
    APKS("APKs"),
    ARCHIVES("Compactados")
}

/** Lista arquivos por categoria usando o índice do sistema (MediaStore): instantâneo, sem varrer o armazenamento. */
object Categories {
    private val DOC_EXT = listOf("pdf", "doc", "docx", "txt", "xls", "xlsx", "ppt", "pptx", "odt", "ods", "odp", "csv", "rtf", "md")
    private val APK_EXT = listOf("apk", "xapk", "apks")
    private val ARCHIVE_EXT = listOf("zip", "rar", "7z", "gz", "tgz", "bz2", "xz", "tar", "iso")

    private fun extensionFilter(exts: List<String>): Pair<String, Array<String>> {
        val sel = "(" + exts.joinToString(" OR ") { "${MediaStore.MediaColumns.DATA} LIKE ?" } + ")"
        return sel to exts.map { "%.$it" }.toTypedArray()
    }

    /** Caminhos escondidos, dados de outros apps e a nossa lixeira ficam de fora. */
    private fun excluded(path: String): Boolean =
        path.contains("/.") || path.contains("/Android/data/") || path.contains("/Android/obb/")

    fun query(context: Context, category: Category, maxResults: Int = 30_000): List<Entry> {
        val (selection, args) = when (category) {
            Category.IMAGES -> "${MediaStore.Files.FileColumns.MEDIA_TYPE}=?" to arrayOf(MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE.toString())
            Category.VIDEOS -> "${MediaStore.Files.FileColumns.MEDIA_TYPE}=?" to arrayOf(MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO.toString())
            Category.AUDIO -> "${MediaStore.Files.FileColumns.MEDIA_TYPE}=?" to arrayOf(MediaStore.Files.FileColumns.MEDIA_TYPE_AUDIO.toString())
            Category.DOCS -> extensionFilter(DOC_EXT)
            Category.APKS -> extensionFilter(APK_EXT)
            Category.ARCHIVES -> extensionFilter(ARCHIVE_EXT)
            Category.RECENT -> "${MediaStore.MediaColumns.MIME_TYPE} IS NOT NULL AND ${MediaStore.MediaColumns.SIZE}>0" to emptyArray<String>()
        }
        // Limites iniciais para evitar que o acesso rápido fique preso montando dezenas de milhares
        // de linhas antes de exibir a primeira tela. Imagens/vídeos têm limite maior que recentes,
        // mas continuam sendo consultados pelo índice do Android, sem varredura do armazenamento.
        val cap = if (category == Category.RECENT) minOf(maxResults, 300) else maxResults
        val limit = cap + cap / 2 + 100 // margem: parte das linhas é descartada (ocultos, apagados)
        val bundle = Bundle().apply {
            putString(ContentResolver.QUERY_ARG_SQL_SELECTION, selection)
            putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, args)
            putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, "${MediaStore.MediaColumns.DATE_MODIFIED} DESC")
            putInt(ContentResolver.QUERY_ARG_LIMIT, limit)
        }
        val projection = arrayOf(
            MediaStore.MediaColumns.DATA, MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.DATE_MODIFIED,
            MediaStore.MediaColumns._ID, MediaStore.Files.FileColumns.MEDIA_TYPE
        )
        val df = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
        val out = ArrayList<Entry>()
        try {
            context.contentResolver.query(MediaStore.Files.getContentUri("external"), projection, bundle, null)?.use { c ->
                val iData = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA)
                val iSize = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
                val iDate = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED)
                val iId = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val iType = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MEDIA_TYPE)
                while (c.moveToNext()) {
                    val path = c.getString(iData) ?: continue
                    if (excluded(path)) continue
                    val f = File(path)
                    if (!f.isFile) continue // o índice pode ter itens já apagados
                    val id = c.getLong(iId)
                    val uri: Uri? = when (c.getInt(iType)) {
                        MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE -> ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
                        MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO -> ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
                        else -> null
                    }
                    out.add(buildEntry(f, false, c.getLong(iSize), c.getLong(iDate) * 1000L, df, true, uri))
                    if (out.size >= cap) break
                }
            }
        } catch (_: Exception) {
            // índice indisponível: devolve o que tiver
        }
        return out
    }
}

/** Mapa caminho → URI de mídia para as fotos e vídeos de uma pasta (uma única consulta), usado nas miniaturas. */
object MediaIndex {
    fun uris(context: Context, dir: File): Map<String, Uri> {
        val prefix = dir.absolutePath.trimEnd('/') + "/"
        val out = HashMap<String, Uri>()
        try {
            context.contentResolver.query(
                MediaStore.Files.getContentUri("external"),
                arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DATA, MediaStore.Files.FileColumns.MEDIA_TYPE),
                "${MediaStore.MediaColumns.DATA} LIKE ? AND ${MediaStore.MediaColumns.DATA} NOT LIKE ? AND ${MediaStore.Files.FileColumns.MEDIA_TYPE} IN (?, ?)",
                arrayOf(
                    prefix + "%", prefix + "%/%",
                    MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE.toString(), MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO.toString()
                ),
                null
            )?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val iData = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA)
                val iType = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MEDIA_TYPE)
                while (c.moveToNext()) {
                    val path = c.getString(iData) ?: continue
                    val id = c.getLong(iId)
                    val uri = if (c.getInt(iType) == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO) {
                        ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
                    } else {
                        ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
                    }
                    out[path] = uri
                }
            }
        } catch (_: Exception) {
        }
        return out
    }
}

/** Avisa o sistema sobre arquivos criados/removidos/renomeados para as categorias refletirem a mudança. */
object MediaScan {
    fun scan(context: Context, paths: Collection<String>) {
        val list = ArrayList<String>()
        for (p in paths) {
            val f = File(p)
            if (f.isDirectory) {
                var n = 0
                for (c in f.walkTopDown()) {
                    if (c.isFile) {
                        list.add(c.absolutePath)
                        n++
                        if (n >= 3000) break
                    }
                }
            } else {
                list.add(p)
            }
        }
        if (list.isNotEmpty()) {
            try {
                MediaScannerConnection.scanFile(context.applicationContext, list.toTypedArray(), null, null)
            } catch (_: Exception) {
            }
        }
    }
}
