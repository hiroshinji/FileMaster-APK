package com.example.filemaster

import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.media.ThumbnailUtils
import android.os.Build
import android.os.CancellationSignal
import android.util.LruCache
import android.util.Size
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.util.Collections

/**
 * Miniaturas de fotos, vídeos e APKs.
 * 1) Usa primeiro as miniaturas que o próprio Android já guarda (galeria): quase instantâneo.
 * 2) Se não houver, gera a miniatura em segundo plano. No máximo 4 por vez; cancela quando o item sai da tela.
 * 3) Mantém um cache em memória, então voltar na rolagem não gera nada de novo.
 */
object Thumbs {
    private val cache = object : LruCache<String, Bitmap>(48 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val gate = Semaphore(4)
    private val failed: MutableSet<String> = Collections.synchronizedSet(HashSet<String>())

    private fun key(e: Entry, px: Int) = (if (e.kind == FileKind.APK) "apk|" else "") + e.path + "|" + e.modified + "|" + px

    fun cached(e: Entry, px: Int): Bitmap? = cache.get(key(e, px))

    suspend fun load(context: Context, e: Entry, px: Int): Bitmap? {
        val k = key(e, px)
        cache.get(k)?.let { return it }
        if (failed.contains(k)) return null
        return gate.withPermit {
            val again = cache.get(k)
            if (again != null) {
                again
            } else {
                withContext(Dispatchers.IO) {
                    val signal = CancellationSignal()
                    val handle = coroutineContext[Job]?.invokeOnCompletion { cause -> if (cause != null) signal.cancel() }
                    try {
                        val size = Size(px, px)
                        var bmp: Bitmap? = null
                        val uri = e.mediaUri
                        if (uri != null) {
                            try {
                                bmp = context.contentResolver.loadThumbnail(uri, size, signal)
                            } catch (_: Exception) {
                                // sem miniatura no índice do sistema: gera abaixo
                            }
                        }
                        if (bmp == null && isActive) {
                            bmp = when (e.kind) {
                                FileKind.IMAGE -> ThumbnailUtils.createImageThumbnail(e.file, size, signal)
                                FileKind.VIDEO -> ThumbnailUtils.createVideoThumbnail(e.file, size, signal)
                                else -> null
                            }
                        }
                        if (bmp != null) cache.put(k, bmp)
                        bmp
                    } catch (_: Exception) {
                        if (isActive) failed.add(k) // cancelado pela rolagem não conta como falha
                        null
                    } finally {
                        handle?.dispose()
                    }
                }
            }
        }
    }

    /** Ícone embutido no APK, com cache e no máximo 4 leituras de APK ao mesmo tempo. */
    suspend fun loadApk(context: Context, e: Entry): Bitmap? {
        val k = key(e, 96)
        cache.get(k)?.let { return it }
        if (failed.contains(k)) return null
        return gate.withPermit {
            val again = cache.get(k)
            if (again != null) {
                again
            } else {
                withContext(Dispatchers.IO) {
                    try {
                        val pm = context.packageManager
                        val info = if (Build.VERSION.SDK_INT >= 33) {
                            pm.getPackageArchiveInfo(e.path, PackageManager.PackageInfoFlags.of(0L))
                        } else {
                            @Suppress("DEPRECATION")
                            pm.getPackageArchiveInfo(e.path, 0)
                        }
                        val appInfo = info?.applicationInfo
                        if (appInfo != null) {
                            appInfo.sourceDir = e.path
                            appInfo.publicSourceDir = e.path
                            val bmp = appInfo.loadIcon(pm).toBitmap(96, 96, Bitmap.Config.ARGB_8888)
                            cache.put(k, bmp)
                            bmp
                        } else {
                            failed.add(k)
                            null
                        }
                    } catch (_: Exception) {
                        failed.add(k)
                        null
                    }
                }
            }
        }
    }
}
