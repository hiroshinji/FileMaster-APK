package com.example.filemaster

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.file.Files
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Compartilhamento pelo menu do Android: Bluetooth, WhatsApp, Quick Share, Drive, e-mail e o que estiver instalado. */
object ShareHelper {
    private fun mimeOf(f: File): String =
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "application/octet-stream"

    fun share(context: Context, files: List<File>) {
        if (files.isEmpty()) return
        val uris = files.map { FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", it) }
        val mimes = files.map { mimeOf(it) }.distinct()
        val type = when {
            mimes.size == 1 -> mimes[0]
            mimes.map { it.substringBefore('/') }.distinct().size == 1 -> mimes[0].substringBefore('/') + "/*"
            else -> "*/*"
        }
        val send = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
        }
        send.type = type
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val clip = ClipData.newRawUri("", uris[0])
        for (i in 1 until uris.size) clip.addItem(ClipData.Item(uris[i]))
        send.clipData = clip
        context.startActivity(Intent.createChooser(send, "Compartilhar via"))
    }

    /** Apaga ZIPs temporários de compartilhamentos antigos. */
    fun cleanup(context: Context) {
        try {
            val dir = File(context.cacheDir, "share")
            val limit = System.currentTimeMillis() - 24L * 60L * 60L * 1000L
            dir.listFiles()?.forEach { if (it.lastModified() < limit) it.delete() }
            val inc = File(context.cacheDir, "incoming")
            inc.listFiles()?.forEach { if (it.lastModified() < limit) it.deleteRecursively() }
        } catch (_: Exception) {
        }
    }
}

class ArchiveCancelled : Exception("cancelado")

/** Compacta arquivos e pastas em ZIP (para guardar ou para compartilhar pastas). */
object Archiver {
    private fun isSymlink(f: File) = try { Files.isSymbolicLink(f.toPath()) } catch (_: Exception) { false }

    /** Retorna quantos arquivos foram compactados. Lança [ArchiveCancelled] se cancelado. */
    fun zip(sources: List<File>, dest: File, cancel: AtomicBoolean, onProgress: (ExtractProgress) -> Unit): Int {
        val skip = TrashStore.DIR_NAME
        var total = 0L
        for (s in sources) {
            for (f in s.walkTopDown().onEnter { it.name != skip }) if (f.isFile) total += f.length()
        }
        val startNs = System.nanoTime()
        var lastNs = 0L
        var done = 0L
        var count = 0
        ZipOutputStream(BufferedOutputStream(FileOutputStream(dest))).use { zip ->
            zip.setLevel(Deflater.DEFAULT_COMPRESSION)
            val buf = ByteArray(64 * 1024)
            for (s in sources) {
                val base = s.parentFile ?: continue
                for (f in s.walkTopDown().onEnter { it.name != skip }) {
                    if (cancel.get()) throw ArchiveCancelled()
                    if (f.absolutePath == dest.absolutePath || isSymlink(f)) continue
                    val rel = f.relativeTo(base).path.replace(File.separatorChar, '/')
                    if (f.isDirectory) {
                        val e = ZipEntry("$rel/")
                        e.time = f.lastModified()
                        zip.putNextEntry(e)
                        zip.closeEntry()
                    } else if (f.isFile) {
                        val e = ZipEntry(rel)
                        e.time = f.lastModified()
                        zip.putNextEntry(e)
                        f.inputStream().use { input ->
                            while (true) {
                                if (cancel.get()) throw ArchiveCancelled()
                                val n = input.read(buf)
                                if (n < 0) break
                                zip.write(buf, 0, n)
                                done += n
                                val now = System.nanoTime()
                                if (now - lastNs > 150_000_000L) {
                                    lastNs = now
                                    onProgress(
                                        ExtractProgress(
                                            if (total > 0) (done.toFloat() / total).coerceIn(0f, 1f) else null,
                                            f.name, count, done, (now - startNs) / 1_000_000L
                                        )
                                    )
                                }
                            }
                        }
                        zip.closeEntry()
                        count++
                    }
                }
            }
        }
        return count
    }
}
