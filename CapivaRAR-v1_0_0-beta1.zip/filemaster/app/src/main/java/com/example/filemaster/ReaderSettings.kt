package com.example.filemaster

import android.app.Activity
import android.content.Context
import android.graphics.Typeface
import android.view.WindowManager
import java.io.File
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily

enum class ReaderTheme(val label: String, val bg: Long, val fg: Long) {
    PAPEL("Papel", 0xFFFFFFFF, 0xFF1B1B1B),
    SEPIA("Sépia", 0xFFF4ECD8, 0xFF5B4636),
    CINZA("Cinza", 0xFFDADADA, 0xFF202020),
    MENTA("Menta", 0xFFDDEBDD, 0xFF23362A),
    NOITE("Noite", 0xFF1B1B1F, 0xFFC8C8CC),
    PRETO("Preto", 0xFF000000, 0xFFB8B8B8)
}

enum class ReaderFont(val label: String, val typeface: Typeface, val compose: FontFamily) {
    SERIF("Serifada", Typeface.SERIF, FontFamily.Serif),
    SANS("Sem serifa", Typeface.SANS_SERIF, FontFamily.SansSerif),
    MONO("Monoespaçada", Typeface.MONOSPACE, FontFamily.Monospace)
}

enum class PdfMode(val label: String) {
    VERTICAL("Rolagem vertical"),
    HORIZONTAL("Páginas (toque nas laterais)")
}

data class ReaderSettings(
    val theme: ReaderTheme = ReaderTheme.SEPIA,
    val font: ReaderFont = ReaderFont.SERIF,
    val sizeSp: Float = 18f,
    val lineSpacing: Float = 1.45f,
    val marginDp: Int = 22,
    val justify: Boolean = true,
    val paged: Boolean = true,
    val autoBrightness: Boolean = true,
    val brightness: Float = 0.6f,
    val warm: Float = 0f,
    val pdfMode: PdfMode = PdfMode.VERTICAL
)

private inline fun <reified T : Enum<T>> String?.toEnum(default: T): T =
    enumValues<T>().firstOrNull { it.name == this } ?: default

class ReaderSettingsStore(context: Context) {
    private val p = context.getSharedPreferences("capivarar_reader", Context.MODE_PRIVATE)

    fun load(): ReaderSettings {
        val d = ReaderSettings()
        return ReaderSettings(
            theme = p.getString("theme", null).toEnum(d.theme),
            font = p.getString("font", null).toEnum(d.font),
            sizeSp = p.getFloat("size", d.sizeSp),
            lineSpacing = p.getFloat("spacing", d.lineSpacing),
            marginDp = p.getInt("margin", d.marginDp),
            justify = p.getBoolean("justify", d.justify),
            paged = p.getBoolean("paged", d.paged),
            autoBrightness = p.getBoolean("autoBright", d.autoBrightness),
            brightness = p.getFloat("bright", d.brightness),
            warm = p.getFloat("warm", d.warm),
            pdfMode = p.getString("pdfMode", null).toEnum(d.pdfMode)
        )
    }

    fun save(s: ReaderSettings) {
        p.edit()
            .putString("theme", s.theme.name)
            .putString("font", s.font.name)
            .putFloat("size", s.sizeSp)
            .putFloat("spacing", s.lineSpacing)
            .putInt("margin", s.marginDp)
            .putBoolean("justify", s.justify)
            .putBoolean("paged", s.paged)
            .putBoolean("autoBright", s.autoBrightness)
            .putFloat("bright", s.brightness)
            .putFloat("warm", s.warm)
            .putString("pdfMode", s.pdfMode.name)
            .apply()
    }
}

/** Posição de leitura por arquivo (retoma de onde parou). */
class ReaderPositions(context: Context) {
    private val p = context.getSharedPreferences("capivarar_positions", Context.MODE_PRIVATE)
    private fun key(f: File) = f.absolutePath.hashCode().toString() + ":" + f.length()
    fun get(f: File): Int = p.getInt(key(f), 0)
    fun put(f: File, value: Int) {
        p.edit().putInt(key(f), value).apply()
    }
}

@Composable
internal fun rememberReaderSettings(): Pair<ReaderSettings, (ReaderSettings) -> Unit> {
    val ctx = LocalContext.current
    val store = remember { ReaderSettingsStore(ctx) }
    var s by remember { mutableStateOf(store.load()) }
    return s to { n: ReaderSettings ->
        s = n
        store.save(n)
    }
}

/** Brilho da tela só enquanto o leitor está aberto; volta ao automático do sistema ao sair. */
@Composable
internal fun ApplyBrightness(auto: Boolean, value: Float) {
    val view = LocalView.current
    DisposableEffect(auto, value) {
        val window = (view.context as? Activity)?.window
        if (window != null) {
            val lp = window.attributes
            lp.screenBrightness = if (auto) WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE else value.coerceIn(0.02f, 1f)
            window.attributes = lp
        }
        onDispose {
            val w = (view.context as? Activity)?.window
            if (w != null) {
                val lp = w.attributes
                lp.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                w.attributes = lp
            }
        }
    }
}

/** Filtro de luz quente (sépia/âmbar) por cima do conteúdo: reduz o azul sem depender do filtro do sistema. */
internal fun Modifier.warmFilter(strength: Float): Modifier =
    if (strength <= 0.01f) {
        this
    } else {
        this
            .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
            .drawWithContent {
                drawContent()
                drawRect(lerp(Color.White, Color(0xFFFFA64D), strength.coerceIn(0f, 1f)), blendMode = BlendMode.Multiply)
            }
    }
