package com.example.filemaster

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.io.InputStream
import java.util.zip.ZipFile

enum class TextMode { PLAIN, DOCX, ODT, PPTX }

/** Leitura de texto para o visualizador: arquivos de texto e texto extraído de DOCX, ODT e PPTX. */
object DocText {
    private const val MAX_BYTES = 2 * 1024 * 1024
    private const val MAX_CHARS = 2_000_000

    class Result(val text: String, val note: String?)

    fun read(file: File, mode: TextMode): Result = try {
        when (mode) {
            TextMode.PLAIN -> plain(file)
            TextMode.DOCX -> single(file, "word/document.xml", "w:t", setOf("w:p"), mapOf("w:tab" to "\t", "w:br" to "\n"))
            TextMode.ODT -> single(
                file, "content.xml", "office:text", setOf("text:p", "text:h"),
                mapOf("text:tab" to "\t", "text:line-break" to "\n", "text:s" to " ")
            )
            TextMode.PPTX -> pptx(file)
        }
    } catch (_: Exception) {
        Result("", "Não foi possível ler este arquivo.")
    }

    private fun plain(file: File): Result {
        val len = file.length()
        val n = minOf(len, MAX_BYTES.toLong()).toInt()
        val buf = ByteArray(n)
        var read = 0
        file.inputStream().use { input ->
            while (read < n) {
                val r = input.read(buf, read, n - read)
                if (r < 0) break
                read += r
            }
        }
        val head = minOf(read, 4096)
        for (i in 0 until head) {
            if (buf[i] == 0.toByte()) return Result("", "Este arquivo parece ser binário e não pode ser exibido como texto.")
        }
        val note = if (len > MAX_BYTES) "Mostrando só os primeiros 2 MB do arquivo." else null
        return Result(String(buf, 0, read, Charsets.UTF_8), note)
    }

    private fun finish(sb: StringBuilder): Result {
        if (sb.isBlank()) return Result("", "Nenhum texto encontrado neste documento.")
        val note = if (sb.length >= MAX_CHARS) "Mostrando só o início do documento." else null
        return Result(sb.toString(), note)
    }

    private fun single(file: File, entry: String, content: String, paras: Set<String>, special: Map<String, String>): Result {
        val sb = StringBuilder()
        ZipFile(file).use { zf ->
            val e = zf.getEntry(entry) ?: return Result("", "Não encontrei o conteúdo do documento.")
            zf.getInputStream(e).use { parse(it, content, paras, special, sb) }
        }
        return finish(sb)
    }

    private fun pptx(file: File): Result {
        val sb = StringBuilder()
        val rx = Regex("ppt/slides/slide(\\d+)\\.xml")
        ZipFile(file).use { zf ->
            val slides = zf.entries().toList()
                .mapNotNull { e -> rx.matchEntire(e.name)?.let { m -> m.groupValues[1].toInt() to e } }
                .sortedBy { it.first }
            for ((n, e) in slides) {
                sb.append("— Slide ").append(n).append(" —\n")
                zf.getInputStream(e).use { parse(it, "a:t", setOf("a:p"), emptyMap(), sb) }
                sb.append('\n')
                if (sb.length >= MAX_CHARS) break
            }
        }
        return finish(sb)
    }

    private fun parse(stream: InputStream, contentTag: String, paras: Set<String>, special: Map<String, String>, sb: StringBuilder) {
        val p = Xml.newPullParser()
        p.setInput(stream, null)
        var inContent = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT && sb.length < MAX_CHARS) {
            when (ev) {
                XmlPullParser.START_TAG -> {
                    val n = p.name
                    if (n == contentTag) {
                        inContent = true
                    } else {
                        val s = special[n]
                        if (s != null) sb.append(s)
                    }
                }
                XmlPullParser.TEXT -> if (inContent) sb.append(p.text)
                XmlPullParser.END_TAG -> {
                    val n = p.name
                    if (n == contentTag) inContent = false
                    if (n in paras) sb.append('\n')
                }
            }
            ev = p.next()
        }
    }
}
