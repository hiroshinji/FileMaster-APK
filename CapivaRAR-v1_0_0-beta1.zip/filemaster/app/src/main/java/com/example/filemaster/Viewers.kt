@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.filemaster

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.pdf.PdfRenderer
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.util.LruCache
import android.view.SurfaceView
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

sealed interface Viewer {
    data class Image(val files: List<File>, val index: Int) : Viewer
    data class Media(val files: List<File>, val index: Int, val video: Boolean) : Viewer
    data class Pdf(val file: File) : Viewer
    data class Html(val file: File) : Viewer
    data class TextDoc(val file: File, val mode: TextMode) : Viewer
    data class Reader(val file: File, val source: ReaderSource) : Viewer
}

/** O que os leitores podem pedir ao app: abrir em outro app, compartilhar ou trocar de leitor. */
class ViewerActions(
    val openExternal: (File) -> Unit,
    val share: (File) -> Unit,
    val navigate: (Viewer) -> Unit
)

val LocalViewerActions = staticCompositionLocalOf<ViewerActions> { error("ViewerActions não fornecido") }

private val IMG_EXT = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif")
private val HTML_EXT = setOf("html", "htm", "xhtml")
private val CODE_TEXT_EXT = setOf(
    "json", "xml", "csv", "tsv", "ini", "conf", "properties", "yml", "yaml", "toml",
    "kt", "kts", "java", "py", "js", "css", "c", "cpp", "h", "sh", "gradle", "srt", "log"
)

/** Decide qual leitor interno abre o arquivo. Retorna null quando o tipo não é suportado (aí abre em outro app). */
fun viewerFor(file: File, siblings: List<Entry>): Viewer? {
    val ext = file.extension.lowercase()
    val kind = kindOf(file.name, false)
    return when {
        ext in IMG_EXT -> {
            val imgs = siblings.filter { !it.isDir && it.file.extension.lowercase() in IMG_EXT }.map { it.file }
            val i = imgs.indexOfFirst { it.absolutePath == file.absolutePath }
            if (i >= 0) Viewer.Image(imgs, i) else Viewer.Image(listOf(file), 0)
        }
        kind == FileKind.VIDEO || kind == FileKind.AUDIO -> {
            val same = siblings.filter { !it.isDir && it.kind == kind }.map { it.file }
            val i = same.indexOfFirst { it.absolutePath == file.absolutePath }
            if (i >= 0) Viewer.Media(same, i, kind == FileKind.VIDEO) else Viewer.Media(listOf(file), 0, kind == FileKind.VIDEO)
        }
        ext == "pdf" -> Viewer.Pdf(file)
        ext == "epub" -> Viewer.Reader(file, ReaderSource.EPUB)
        ext == "docx" -> Viewer.Reader(file, ReaderSource.DOCX)
        ext == "odt" -> Viewer.Reader(file, ReaderSource.ODT)
        ext == "pptx" -> Viewer.Reader(file, ReaderSource.PPTX)
        ext == "txt" -> Viewer.Reader(file, ReaderSource.TEXT)
        ext == "md" -> Viewer.Reader(file, ReaderSource.MARKDOWN)
        ext in HTML_EXT -> Viewer.Html(file)
        ext in CODE_TEXT_EXT -> Viewer.TextDoc(file, TextMode.PLAIN)
        else -> null
    }
}

@Composable
internal fun ViewerHost(viewer: Viewer, actions: ViewerActions, onClose: () -> Unit) {
    CompositionLocalProvider(LocalViewerActions provides actions) {
        // O pointerInput vazio impede que toques "vazem" para a lista que fica por baixo.
        Surface(Modifier.fillMaxSize().pointerInput(Unit) {}, color = MaterialTheme.colorScheme.background) {
            when (viewer) {
                is Viewer.Image -> ImageViewer(viewer, onClose)
                is Viewer.Media -> MediaScreen(viewer, onClose)
                is Viewer.Pdf -> PdfViewer(viewer.file, onClose)
                is Viewer.Html -> HtmlViewer(viewer.file, onClose)
                is Viewer.TextDoc -> TextViewer(viewer.file, viewer.mode, onClose)
                is Viewer.Reader -> ReaderScreen(viewer.file, viewer.source, onClose)
            }
        }
    }
}

@Composable
private fun ViewerBar(
    file: File,
    title: String,
    subtitle: String?,
    overlay: Boolean,
    onClose: () -> Unit,
    actions: @Composable RowScope.() -> Unit = {}
) {
    val acts = LocalViewerActions.current
    var menu by remember { mutableStateOf(false) }
    val colors = if (overlay) {
        TopAppBarDefaults.topAppBarColors(
            containerColor = Color.Black.copy(alpha = 0.55f),
            titleContentColor = Color.White,
            navigationIconContentColor = Color.White,
            actionIconContentColor = Color.White
        )
    } else {
        TopAppBarDefaults.topAppBarColors()
    }
    TopAppBar(
        title = {
            Column {
                Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.labelSmall, maxLines = 1)
            }
        },
        navigationIcon = { IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar") } },
        actions = {
            actions()
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, contentDescription = "Mais opções") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text("Compartilhar") },
                        leadingIcon = { Icon(Icons.Default.Share, contentDescription = null) },
                        onClick = { menu = false; acts.share(file) }
                    )
                    DropdownMenuItem(
                        text = { Text("Abrir com outro app") },
                        leadingIcon = { Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null) },
                        onClick = { menu = false; acts.openExternal(file) }
                    )
                }
            }
        },
        colors = colors
    )
}

// ───────────────────────────── IMAGENS ─────────────────────────────

private val imageCache = object : LruCache<String, Bitmap>(48 * 1024 * 1024) {
    override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
}

private fun decodeScaled(file: File, max: Int): Bitmap? = try {
    ImageDecoder.decodeBitmap(ImageDecoder.createSource(file)) { decoder, info, _ ->
        val m = maxOf(info.size.width, info.size.height)
        if (m > max) decoder.setTargetSampleSize((m / max).coerceAtLeast(1))
        decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
    }
} catch (_: Throwable) {
    null
}

@Composable
private fun ImageViewer(v: Viewer.Image, onClose: () -> Unit) {
    val pager = rememberPagerState(initialPage = v.index) { v.files.size }
    var showBar by remember { mutableStateOf(true) }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        HorizontalPager(
            state = pager,
            modifier = Modifier.fillMaxSize(),
            beyondViewportPageCount = 1,
            key = { v.files[it].absolutePath }
        ) { page ->
            ZoomBox(Modifier.fillMaxSize(), onTap = { _, _, scale -> if (scale <= 1f) showBar = !showBar }) { PageImage(v.files[page]) }
        }
        if (showBar) {
            val current = v.files[pager.currentPage.coerceIn(0, v.files.size - 1)]
            Box(Modifier.align(Alignment.TopCenter)) {
                ViewerBar(current, current.name, "${pager.currentPage + 1} / ${v.files.size}", true, onClose)
            }
        }
    }
}

@Composable
private fun PageImage(file: File) {
    val key = file.absolutePath + "|" + file.lastModified()
    var bmp by remember(key) { mutableStateOf<Bitmap?>(imageCache.get(key)) }
    var failed by remember(key) { mutableStateOf(false) }
    LaunchedEffect(key) {
        if (bmp == null) {
            val r = withContext(Dispatchers.IO) { decodeScaled(file, 2048) }
            if (r == null) {
                failed = true
            } else {
                imageCache.put(key, r)
                bmp = r
            }
        }
    }
    val b = bmp
    if (b != null) {
        Image(
            bitmap = remember(b) { b.asImageBitmap() },
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize()
        )
    } else {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            if (failed) Text("Não foi possível abrir a imagem.", color = Color.White) else CircularProgressIndicator()
        }
    }
}

/**
 * Zoom com pinça e arrasto; toque duplo alterna 1x/2,5x. Com 1 dedo e sem zoom, deixa o gesto passar (troca de página).
 * [onTap] recebe (posição, tamanho da área, zoom atual).
 */
@Composable
internal fun ZoomBox(
    modifier: Modifier = Modifier,
    maxScale: Float = 5f,
    onTap: ((Offset, IntSize, Float) -> Unit)? = null,
    content: @Composable () -> Unit
) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    var boxSize by remember { mutableStateOf(IntSize.Zero) }
    Box(
        modifier
            .onSizeChanged { boxSize = it }
            .pointerInput(Unit) {
                detectTapGestures(
                    onDoubleTap = {
                        scale = if (scale > 1f) 1f else 2.5f
                        offset = Offset.Zero
                    },
                    onTap = { off -> onTap?.invoke(off, boxSize, scale) }
                )
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    do {
                        val event = awaitPointerEvent(PointerEventPass.Initial)
                        if (event.changes.size >= 2 || scale > 1f) {
                            val zoom = event.calculateZoom()
                            val pan = event.calculatePan()
                            val newScale = (scale * zoom).coerceIn(1f, maxScale)
                            val maxX = boxSize.width * (newScale - 1f) / 2f
                            val maxY = boxSize.height * (newScale - 1f) / 2f
                            offset = if (newScale > 1f) {
                                Offset((offset.x + pan.x).coerceIn(-maxX, maxX), (offset.y + pan.y).coerceIn(-maxY, maxY))
                            } else {
                                Offset.Zero
                            }
                            scale = newScale
                            event.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (event.changes.any { it.pressed })
                }
            }
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                translationX = offset.x
                translationY = offset.y
            }
    ) { content() }
}

// ───────────────────────────── VÍDEO E ÁUDIO ─────────────────────────────

private class AudioMeta(val art: Bitmap?, val title: String?, val artist: String?)

private fun readAudioMeta(file: File): AudioMeta {
    val r = MediaMetadataRetriever()
    return try {
        r.setDataSource(file.absolutePath)
        val bytes = r.embeddedPicture
        val art = if (bytes != null) BitmapFactory.decodeByteArray(bytes, 0, bytes.size) else null
        AudioMeta(art, r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE), r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST))
    } catch (_: Exception) {
        AudioMeta(null, null, null)
    } finally {
        try { r.release() } catch (_: Exception) {}
    }
}

private fun fmtTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}

@Composable
private fun MediaScreen(v: Viewer.Media, onClose: () -> Unit) {
    val context = LocalContext.current
    val actions = LocalViewerActions.current
    val player = remember { ExoPlayer.Builder(context).build() }
    var isPlaying by remember { mutableStateOf(false) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var index by remember { mutableIntStateOf(v.index) }
    var ratio by remember { mutableFloatStateOf(16f / 9f) }
    var error by remember { mutableStateOf<String?>(null) }
    var speedIdx by remember { mutableIntStateOf(1) }
    var showControls by remember { mutableStateOf(true) }
    var dragging by remember { mutableStateOf<Float?>(null) }
    val speeds = remember { listOf(0.5f, 1f, 1.25f, 1.5f, 2f) }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                index = player.currentMediaItemIndex
                error = null
            }
            override fun onPlaybackStateChanged(playbackState: Int) { duration = player.duration.coerceAtLeast(0L) }
            override fun onVideoSizeChanged(videoSize: VideoSize) {
                if (videoSize.height > 0) ratio = videoSize.width * videoSize.pixelWidthHeightRatio / videoSize.height
            }
            override fun onPlayerError(e: PlaybackException) { error = "Não foi possível reproduzir este arquivo." }
        }
        player.addListener(listener)
        player.setMediaItems(v.files.map { MediaItem.fromUri(Uri.fromFile(it)) }, v.index, 0L)
        player.prepare()
        player.playWhenReady = true
        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }

    // Pausa quando o app sai da tela.
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event -> if (event == Lifecycle.Event.ON_STOP) player.pause() }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(player) {
        while (true) {
            if (dragging == null) position = player.currentPosition.coerceAtLeast(0L)
            delay(250)
        }
    }

    // Tela acesa durante o vídeo.
    val view = LocalView.current
    DisposableEffect(isPlaying) {
        view.keepScreenOn = isPlaying && v.video
        onDispose { view.keepScreenOn = false }
    }

    val file = v.files[index.coerceIn(0, v.files.size - 1)]
    val subtitle = if (v.files.size > 1) "${index + 1} / ${v.files.size}" else null

    val onPlayPause = {
        if (player.playbackState == Player.STATE_ENDED) {
            player.seekTo(player.currentMediaItemIndex, 0L)
            player.play()
        } else if (player.isPlaying) {
            player.pause()
        } else {
            player.play()
        }
    }

    @Composable
    fun Controls(color: Color) {
        PlayerControls(
            isPlaying = isPlaying,
            position = position,
            duration = duration,
            dragging = dragging,
            speedLabel = "${speeds[speedIdx]}x",
            hasPrev = index > 0,
            hasNext = index < v.files.size - 1,
            color = color,
            onSeekChange = { dragging = it },
            onSeekDone = {
                val d = dragging
                if (d != null) {
                    player.seekTo(d.toLong())
                    position = d.toLong()
                }
                dragging = null
            },
            onPlayPause = { onPlayPause() },
            onBack10 = { player.seekTo((player.currentPosition - 10_000L).coerceAtLeast(0L)) },
            onFwd10 = { player.seekTo(player.currentPosition + 10_000L) },
            onPrev = { player.seekToPreviousMediaItem() },
            onNext = { player.seekToNextMediaItem() },
            onSpeed = {
                speedIdx = (speedIdx + 1) % speeds.size
                player.setPlaybackSpeed(speeds[speedIdx])
            }
        )
    }

    if (v.video) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { showControls = !showControls }
        ) {
            AndroidView(
                factory = { ctx -> SurfaceView(ctx).also { player.setVideoSurfaceView(it) } },
                modifier = Modifier.align(Alignment.Center).aspectRatio(ratio)
            )
            val err = error
            if (err != null) {
                Column(Modifier.align(Alignment.Center).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(err, color = Color.White)
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { actions.openExternal(file) }) { Text("Abrir com outro app") }
                }
            }
            if (showControls) {
                Box(Modifier.align(Alignment.TopCenter)) { ViewerBar(file, file.name, subtitle, true, onClose) }
                Column(
                    Modifier.align(Alignment.BottomCenter).background(Color.Black.copy(alpha = 0.55f)).navigationBarsPadding()
                ) { Controls(Color.White) }
            }
        }
    } else {
        var art by remember(file) { mutableStateOf<Bitmap?>(null) }
        var title by remember(file) { mutableStateOf<String?>(null) }
        var artist by remember(file) { mutableStateOf<String?>(null) }
        LaunchedEffect(file) {
            val m = withContext(Dispatchers.IO) { readAudioMeta(file) }
            art = m.art
            title = m.title
            artist = m.artist
        }
        Column(Modifier.fillMaxSize()) {
            ViewerBar(file, file.name, subtitle, false, onClose)
            Column(
                Modifier.weight(1f).fillMaxWidth().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                val a = art
                if (a != null) {
                    Image(
                        bitmap = remember(a) { a.asImageBitmap() },
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.size(260.dp).clip(CircleShape)
                    )
                } else {
                    Box(
                        Modifier.size(200.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.MusicNote, contentDescription = null, modifier = Modifier.size(96.dp), tint = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                }
                Spacer(Modifier.height(24.dp))
                Text(title ?: file.nameWithoutExtension, style = MaterialTheme.typography.titleLarge, maxLines = 2, overflow = TextOverflow.Ellipsis)
                val ar = artist
                if (ar != null) Text(ar, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                val err = error
                if (err != null) {
                    Spacer(Modifier.height(12.dp))
                    Text(err, color = MaterialTheme.colorScheme.error)
                    Button(onClick = { actions.openExternal(file) }) { Text("Abrir com outro app") }
                }
            }
            Column(Modifier.navigationBarsPadding()) { Controls(MaterialTheme.colorScheme.onSurface) }
        }
    }
}

@Composable
private fun PlayerControls(
    isPlaying: Boolean,
    position: Long,
    duration: Long,
    dragging: Float?,
    speedLabel: String,
    hasPrev: Boolean,
    hasNext: Boolean,
    color: Color,
    onSeekChange: (Float) -> Unit,
    onSeekDone: () -> Unit,
    onPlayPause: () -> Unit,
    onBack10: () -> Unit,
    onFwd10: () -> Unit,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onSpeed: () -> Unit
) {
    val max = maxOf(duration, 1L).toFloat()
    val shown = (dragging ?: position.toFloat()).coerceIn(0f, max)
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
        Slider(
            value = shown,
            onValueChange = onSeekChange,
            onValueChangeFinished = onSeekDone,
            valueRange = 0f..max,
            colors = SliderDefaults.colors(thumbColor = color, activeTrackColor = color, inactiveTrackColor = color.copy(alpha = 0.3f))
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(fmtTime(shown.toLong()), color = color, style = MaterialTheme.typography.labelMedium)
            Text(fmtTime(duration), color = color, style = MaterialTheme.typography.labelMedium)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onPrev, enabled = hasPrev) {
                Icon(Icons.Default.SkipPrevious, contentDescription = "Anterior", tint = if (hasPrev) color else color.copy(alpha = 0.38f))
            }
            IconButton(onClick = onBack10) { Icon(Icons.Default.Replay10, contentDescription = "Voltar 10 segundos", tint = color) }
            FilledIconButton(onClick = onPlayPause, modifier = Modifier.size(56.dp)) {
                Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = if (isPlaying) "Pausar" else "Reproduzir")
            }
            IconButton(onClick = onFwd10) { Icon(Icons.Default.Forward10, contentDescription = "Avançar 10 segundos", tint = color) }
            IconButton(onClick = onNext, enabled = hasNext) {
                Icon(Icons.Default.SkipNext, contentDescription = "Próximo", tint = if (hasNext) color else color.copy(alpha = 0.38f))
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            TextButton(onClick = onSpeed) { Text("Velocidade $speedLabel", color = color) }
        }
    }
}

// ───────────────────────────── PDF ─────────────────────────────

private val pdfCache = object : LruCache<String, Bitmap>(96 * 1024 * 1024) {
    override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
}

private class PdfDoc private constructor(
    private val pfd: ParcelFileDescriptor,
    private val renderer: PdfRenderer,
    val id: String
) {
    private val lock = Any()
    private var closed = false
    val pageCount: Int = renderer.pageCount
    var firstAspect: Float = 1.414f // altura / largura da primeira página

    companion object {
        fun open(file: File): PdfDoc {
            val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            try {
                val renderer = PdfRenderer(pfd)
                val doc = PdfDoc(pfd, renderer, file.absolutePath + "|" + file.lastModified())
                if (renderer.pageCount > 0) {
                    val p = renderer.openPage(0)
                    try {
                        doc.firstAspect = p.height.toFloat() / p.width
                    } finally {
                        p.close()
                    }
                }
                return doc
            } catch (e: Throwable) {
                try { pfd.close() } catch (_: Exception) {}
                throw e
            }
        }
    }

    fun render(index: Int, widthPx: Int): Bitmap? = synchronized(lock) { renderLocked(index, widthPx) }

    private fun renderLocked(index: Int, widthPx: Int): Bitmap? {
        if (closed) return null
        return try {
            val page = renderer.openPage(index)
            try {
                val h = (widthPx.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
                val bmp = Bitmap.createBitmap(widthPx, h, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(android.graphics.Color.WHITE)
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                bmp
            } finally {
                page.close()
            }
        } catch (_: Throwable) {
            null
        }
    }

    fun close() {
        synchronized(lock) {
            if (!closed) {
                closed = true
                try { renderer.close() } catch (_: Exception) {}
                try { pfd.close() } catch (_: Exception) {}
            }
        }
    }
}

@Composable
private fun rememberPdfBitmap(doc: PdfDoc, index: Int, widthPx: Int): State<Bitmap?> {
    val key = "${doc.id}#$index#$widthPx"
    return produceState<Bitmap?>(pdfCache.get(key), key) {
        if (value == null) {
            val r = withContext(Dispatchers.IO) { if (isActive) doc.render(index, widthPx) else null }
            if (r != null) {
                pdfCache.put(key, r)
                value = r
            }
        }
    }
}

@Composable
private fun PdfViewer(file: File, onClose: () -> Unit) {
    val actions = LocalViewerActions.current
    val (settings, setSettings) = rememberReaderSettings()
    ApplyBrightness(settings.autoBrightness, settings.brightness)
    var doc by remember(file) { mutableStateOf<PdfDoc?>(null) }
    var error by remember(file) { mutableStateOf<String?>(null) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var currentPage by remember(file) { mutableIntStateOf(0) }
    var jumpTo by remember { mutableStateOf<Int?>(null) }
    var showSheet by remember { mutableStateOf(false) }
    var goTo by remember { mutableStateOf(false) }

    LaunchedEffect(file) {
        try {
            doc = withContext(Dispatchers.IO) { PdfDoc.open(file) }
        } catch (e: CancellationException) {
            throw e
        } catch (_: SecurityException) {
            error = "Este PDF é protegido por senha, o que ainda não é suportado."
        } catch (_: Throwable) {
            error = "Não foi possível abrir este PDF."
        }
    }
    DisposableEffect(file) { onDispose { doc?.close() } }

    Column(Modifier.fillMaxSize().background(Color(0xFF424242)).warmFilter(settings.warm)) {
        val d = doc
        ViewerBar(file, file.name, if (d != null) "pág. ${currentPage + 1} / ${d.pageCount}" else null, false, onClose) {
            IconButton(onClick = { actions.navigate(Viewer.Reader(file, ReaderSource.PDF)) }) {
                Icon(Icons.AutoMirrored.Filled.MenuBook, contentDescription = "Modo leitura (estilo Kindle)")
            }
            IconButton(onClick = { showSheet = true }) { Icon(Icons.Default.Tune, contentDescription = "Ajustes de leitura") }
        }
        val err = error
        when {
            err != null -> Column(
                Modifier.fillMaxSize().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(err, color = Color.White)
                Spacer(Modifier.height(8.dp))
                Button(onClick = { actions.openExternal(file) }) { Text("Abrir com outro app") }
            }
            d == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            settings.pdfMode == PdfMode.VERTICAL -> PdfVertical(
                doc = d,
                zoom = zoom,
                startPage = currentPage,
                jumpTo = jumpTo,
                onPage = { currentPage = it },
                onJumpDone = { jumpTo = null },
                onDoubleTap = { zoom = if (zoom > 1f) 1f else 2f }
            )
            else -> PdfHorizontal(
                doc = d,
                startPage = currentPage,
                jumpTo = jumpTo,
                onPage = { currentPage = it },
                onJumpDone = { jumpTo = null }
            )
        }
    }

    if (showSheet) {
        ModalBottomSheet(onDismissRequest = { showSheet = false }, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 28.dp)) {
                Text("Como ler", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(bottom = 6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PdfMode.values().forEach { m ->
                        FilterChip(selected = m == settings.pdfMode, onClick = { setSettings(settings.copy(pdfMode = m)) }, label = { Text(m.label) })
                    }
                }
                if (settings.pdfMode == PdfMode.HORIZONTAL) {
                    Text(
                        "Toque na lateral direita ou esquerda da página para virar. Com 2 dedos, dê zoom.",
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                } else {
                    Text("Zoom: ${"%.1f".format(zoom)}x", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 12.dp))
                    Slider(value = zoom, onValueChange = { zoom = it }, valueRange = 1f..2.5f)
                }
                OutlinedButton(
                    onClick = { showSheet = false; goTo = true },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                ) { Text("Ir para a página…") }
                BrightnessAndFilterSection(settings, setSettings)
            }
        }
    }
    if (goTo) {
        NameDialog("Ir para a página", "", "Ir", { goTo = false }) { s ->
            goTo = false
            val n = s.toIntOrNull()
            val count = doc?.pageCount ?: 1
            if (n != null) jumpTo = (n - 1).coerceIn(0, count - 1)
        }
    }
}

@Composable
private fun PdfVertical(
    doc: PdfDoc,
    zoom: Float,
    startPage: Int,
    jumpTo: Int?,
    onPage: (Int) -> Unit,
    onJumpDone: () -> Unit,
    onDoubleTap: () -> Unit
) {
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = startPage.coerceIn(0, (doc.pageCount - 1).coerceAtLeast(0)))
    LaunchedEffect(listState) { snapshotFlow { listState.firstVisibleItemIndex }.collect { onPage(it) } }
    LaunchedEffect(jumpTo) {
        if (jumpTo != null) {
            listState.scrollToItem(jumpTo.coerceIn(0, (doc.pageCount - 1).coerceAtLeast(0)))
            onJumpDone()
        }
    }
    BoxWithConstraints(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures(onDoubleTap = { onDoubleTap() }) }) {
        val contentWidth = maxWidth * zoom
        val widthPx = with(LocalDensity.current) { contentWidth.roundToPx() }.coerceAtMost(2400)
        Box(Modifier.fillMaxSize().horizontalScroll(rememberScrollState())) {
            LazyColumn(
                state = listState,
                modifier = Modifier.width(contentWidth).fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(vertical = 8.dp)
            ) {
                items(doc.pageCount) { i -> PdfPageView(doc, i, widthPx) }
            }
        }
    }
}

@Composable
private fun PdfHorizontal(doc: PdfDoc, startPage: Int, jumpTo: Int?, onPage: (Int) -> Unit, onJumpDone: () -> Unit) {
    val last = (doc.pageCount - 1).coerceAtLeast(0)
    val pager = rememberPagerState(initialPage = startPage.coerceIn(0, last)) { doc.pageCount }
    val scope = rememberCoroutineScope()
    LaunchedEffect(pager) { snapshotFlow { pager.currentPage }.collect { onPage(it) } }
    LaunchedEffect(jumpTo) {
        if (jumpTo != null) {
            pager.scrollToPage(jumpTo.coerceIn(0, last))
            onJumpDone()
        }
    }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val widthPx = with(LocalDensity.current) { (maxWidth * 1.6f).roundToPx() }.coerceAtMost(2200)
        HorizontalPager(state = pager, beyondViewportPageCount = 1, modifier = Modifier.fillMaxSize()) { i ->
            ZoomBox(
                Modifier.fillMaxSize(),
                onTap = { off, boxSize, scale ->
                    if (scale <= 1f) {
                        val w = boxSize.width
                        if (off.x < w * 0.3f) {
                            scope.launch { if (pager.currentPage > 0) pager.animateScrollToPage(pager.currentPage - 1) }
                        } else if (off.x > w * 0.7f) {
                            scope.launch { if (pager.currentPage < pager.pageCount - 1) pager.animateScrollToPage(pager.currentPage + 1) }
                        }
                    }
                }
            ) { PdfPageFit(doc, i, widthPx) }
        }
    }
}

@Composable
private fun PdfPageFit(doc: PdfDoc, index: Int, widthPx: Int) {
    val bmp by rememberPdfBitmap(doc, index, widthPx)
    val b = bmp
    if (b != null) {
        Image(
            bitmap = remember(b) { b.asImageBitmap() },
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize()
        )
    } else {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
    }
}

@Composable
private fun PdfPageView(doc: PdfDoc, index: Int, widthPx: Int) {
    val bmp by rememberPdfBitmap(doc, index, widthPx)
    val b = bmp
    if (b != null) {
        Image(
            bitmap = remember(b) { b.asImageBitmap() },
            contentDescription = null,
            contentScale = ContentScale.FillWidth,
            modifier = Modifier.fillMaxWidth().aspectRatio(b.width.toFloat() / b.height)
        )
    } else {
        Box(
            Modifier.fillMaxWidth().aspectRatio(1f / doc.firstAspect).background(Color.White),
            contentAlignment = Alignment.Center
        ) { CircularProgressIndicator(Modifier.size(24.dp)) }
    }
}

// ───────────────────────────── HTML E TEXTO ─────────────────────────────

@Composable
private fun HtmlViewer(file: File, onClose: () -> Unit) {
    val actions = LocalViewerActions.current
    var code by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        ViewerBar(file, file.name, if (code) "Código-fonte" else null, false, onClose) {
            IconButton(onClick = { actions.navigate(Viewer.Reader(file, ReaderSource.HTML)) }) {
                Icon(Icons.AutoMirrored.Filled.MenuBook, contentDescription = "Modo leitura (estilo Kindle)")
            }
            IconButton(onClick = { code = !code }) {
                Icon(if (code) Icons.Default.Language else Icons.Default.Code, contentDescription = "Alternar página e código")
            }
        }
        if (code) {
            TextBody(file, TextMode.PLAIN, Modifier.weight(1f).fillMaxWidth())
        } else {
            AndroidView(
                factory = { ctx ->
                    WebView(ctx).apply {
                        // JavaScript e rede desligados: o arquivo é local e não precisa falar com a internet.
                        settings.javaScriptEnabled = false
                        settings.allowFileAccess = true
                        settings.allowContentAccess = false
                        settings.blockNetworkLoads = true
                        settings.builtInZoomControls = true
                        settings.displayZoomControls = false
                        settings.useWideViewPort = true
                        settings.loadWithOverviewMode = true
                        webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean =
                                request?.url?.scheme != "file"
                        }
                        loadUrl(Uri.fromFile(file).toString())
                    }
                },
                onRelease = { it.destroy() },
                modifier = Modifier.weight(1f).fillMaxWidth()
            )
        }
    }
}

@Composable
private fun TextViewer(file: File, mode: TextMode, onClose: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        ViewerBar(file, file.name, if (mode == TextMode.PLAIN) null else "Texto extraído (sem formatação)", false, onClose)
        TextBody(file, mode, Modifier.weight(1f).fillMaxWidth())
    }
}

@Composable
private fun TextBody(file: File, mode: TextMode, modifier: Modifier) {
    var blocks by remember(file, mode) { mutableStateOf<List<String>?>(null) }
    var note by remember(file, mode) { mutableStateOf<String?>(null) }
    LaunchedEffect(file, mode) {
        val r = withContext(Dispatchers.IO) {
            val res = DocText.read(file, mode)
            res to res.text.split('\n').chunked(40).map { it.joinToString("\n") }
        }
        note = r.first.note
        blocks = r.second
    }
    val b = blocks
    if (b == null) {
        Box(modifier, contentAlignment = Alignment.Center) { CircularProgressIndicator() }
    } else {
        val mono = mode == TextMode.PLAIN
        Column(modifier) {
            val n = note
            if (n != null) {
                Text(n, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
            }
            SelectionContainer {
                LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                    items(b) { block ->
                        Text(
                            block,
                            fontFamily = if (mono) FontFamily.Monospace else FontFamily.Default,
                            fontSize = if (mono) 13.sp else 15.sp
                        )
                    }
                }
            }
        }
    }
}
