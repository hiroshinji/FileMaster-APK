package com.example.filemaster

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.content.pm.PackageManager
import android.media.ThumbnailUtils
import android.provider.MediaStore
import android.webkit.WebView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.graphics.drawable.toBitmap
import androidx.core.content.FileProvider
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.io.File
import java.util.LinkedHashMap
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.android.gms.tasks.Tasks

/** Cache LRU limitado a 24 MiB; miniaturas compactas e itens fora de tela não mantêm bitmaps próprios na composição. */
private object ThumbnailCache {
    private const val MAX_BYTES = 24 * 1024 * 1024
    private val cache = object : LinkedHashMap<String, Bitmap>(32, .75f, true) {
        var bytes = 0
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Bitmap>?): Boolean {
            if (bytes > MAX_BYTES && eldest != null) { bytes -= eldest.value.byteCount; return true }
            return false
        }
    }
    @Synchronized fun get(key: String) = cache[key]
    @Synchronized fun put(key: String, bitmap: Bitmap) { cache.put(key, bitmap)?.let { cache.bytes -= it.byteCount }; cache.bytes += bitmap.byteCount; while (cache.bytes > MAX_BYTES && cache.isNotEmpty()) { val first = cache.entries.iterator().next(); cache.bytes -= first.value.byteCount; cache.remove(first.key) } }
}

private val thumbnailSemaphore = Semaphore(2)

private suspend fun loadThumbnail(file: File, video: Boolean): Bitmap? = thumbnailSemaphore.withPermit {
    val key = "${file.absolutePath}:${file.lastModified()}:${file.length()}:$video"
    ThumbnailCache.get(key)?.let { return@withPermit it }
    val bitmap = try {
        if (video) ThumbnailUtils.createVideoThumbnail(file, android.util.Size(128, 128), null)
        else {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) null else {
                var sample = 1
                while (bounds.outWidth / sample > 192 || bounds.outHeight / sample > 192) sample *= 2
                BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.RGB_565 })
            }
        }
    } catch (_: Exception) { null }
    if (bitmap != null) ThumbnailCache.put(key, bitmap)
    bitmap
}

@Composable
internal fun FileThumbnail(file: File, video: Boolean, modifier: Modifier = Modifier) {
    // Só é iniciado enquanto este item da LazyColumn está composto/próximo da tela.
    val bitmap by produceState<Bitmap?>(initialValue = null, key1 = file.absolutePath, key2 = file.lastModified()) {
        value = withContext(Dispatchers.IO) { loadThumbnail(file, video) }
    }
    Box(modifier.background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
        if (bitmap != null) Image(bitmap!!.asImageBitmap(), contentDescription = file.name, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text(if (video) "▶" else "▧", color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (video) Text("▶", modifier = Modifier.align(Alignment.BottomEnd).padding(4.dp).background(Color.Black.copy(alpha=.65f)), color = Color.White)
    }
}


/** Carrega o ícone incorporado no APK apenas quando a linha entra na composição. */
@Composable
internal fun ApkThumbnail(file: File, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val bitmap by produceState<Bitmap?>(initialValue = null, key1 = file.absolutePath, key2 = file.lastModified()) {
        value = withContext(Dispatchers.IO) {
            try {
                val pm = context.packageManager
                val info = if (android.os.Build.VERSION.SDK_INT >= 33) {
                    pm.getPackageArchiveInfo(file.absolutePath, PackageManager.PackageInfoFlags.of(0L))
                } else {
                    @Suppress("DEPRECATION")
                    pm.getPackageArchiveInfo(file.absolutePath, 0)
                }
                val appInfo = info?.applicationInfo
                if (appInfo != null) {
                    appInfo.sourceDir = file.absolutePath
                    appInfo.publicSourceDir = file.absolutePath
                    appInfo.loadIcon(pm).toBitmap(96, 96, Bitmap.Config.ARGB_8888)
                } else null
            } catch (_: Exception) { null }
        }
    }
    Box(modifier.background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
        if (bitmap != null) Image(bitmap!!.asImageBitmap(), contentDescription = "Ícone de ${file.name}", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        else Text("APK", color = MaterialTheme.colorScheme.primary)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun MediaViewer(file: File, onBack: () -> Unit) {
    val ext = file.extension.lowercase()
    val isImage = ext in setOf("jpg","jpeg","png","gif","webp","bmp","heic","heif")
    val isVideo = ext in setOf("mp4","mkv","avi","mov","webm","3gp","flv","wmv","m4v","ts")
    val isAudio = ext in setOf("mp3","wav","flac","ogg","m4a","aac","opus","wma","amr","mid")
    val isPdf = ext == "pdf"
    val isHtml = ext == "html" || ext == "htm"
    val context = LocalContext.current
    BackHandler(onBack = onBack)
    Scaffold(topBar = { TopAppBar(
        title = { Text(file.name, maxLines=1, overflow=TextOverflow.Ellipsis) },
        navigationIcon = { IconButton(onClick=onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription="Voltar") } },
        actions = {
            if (isImage || isPdf) IconButton(onClick = {
                runCatching {
                    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                    val mime = if (isPdf) "application/pdf" else (android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "image/*")
                    val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply { setDataAndType(uri, mime); addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION); clipData = android.content.ClipData.newRawUri(file.name, uri) }
                    context.startActivity(intent)
                }
            }) { Icon(Icons.Default.OpenInNew, contentDescription = "Abrir em outro aplicativo") }
        }
    ) }) { padding ->
        when {
            isImage -> {
                var scale by remember(file.absolutePath) { mutableFloatStateOf(1f) }
                var panX by remember(file.absolutePath) { mutableFloatStateOf(0f) }
                var panY by remember(file.absolutePath) { mutableFloatStateOf(0f) }
                val state = rememberTransformableState { zoom, pan, _ -> scale = (scale * zoom).coerceIn(1f, 5f); panX += pan.x; panY += pan.y }
                val bitmap by produceState<Bitmap?>(null, file.absolutePath) {
                    value = withContext(Dispatchers.IO) {
                        try {
                            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                            BitmapFactory.decodeFile(file.absolutePath, bounds)
                            var sample = 1
                            while (bounds.outWidth / sample > 2048 || bounds.outHeight / sample > 2048) sample *= 2
                            BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.RGB_565 })
                        } catch (_: Exception) { null }
                    }
                }
                Box(Modifier.fillMaxSize().padding(padding).background(Color.Black), contentAlignment=Alignment.Center) {
                    if (bitmap != null) Image(bitmap!!.asImageBitmap(), contentDescription=file.name, modifier=Modifier.fillMaxSize().graphicsLayer { scaleX=scale; scaleY=scale; translationX=panX; translationY=panY }.transformable(state), contentScale=ContentScale.Fit)
                    else CircularProgressIndicator()
                }
            }
            isVideo || isAudio -> {
                val player = remember(file.absolutePath) { ExoPlayer.Builder(context).build().apply { setMediaItem(MediaItem.fromUri(android.net.Uri.fromFile(file))); prepare() } }
                DisposableEffect(player) { onDispose { player.release() } }
                Column(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement=Arrangement.Center, horizontalAlignment=Alignment.CenterHorizontally) {
                    if (isVideo) AndroidView(factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true } }, modifier=Modifier.fillMaxWidth().weight(1f))
                    else {
                        Icon(Icons.Default.PlayArrow, contentDescription=null, modifier=Modifier.size(96.dp), tint=MaterialTheme.colorScheme.primary)
                        Text(file.name, style=MaterialTheme.typography.titleMedium, maxLines=2, overflow=TextOverflow.Ellipsis)
                        Spacer(Modifier.height(20.dp))
                        var playing by remember { mutableStateOf(false) }
                        Button(onClick = { if (player.isPlaying) { player.pause(); playing=false } else { player.play(); playing=true } }) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription=null); Spacer(Modifier.width(8.dp)); Text(if (playing) "Pausar" else "Reproduzir") }
                    }
                }
            }
            isPdf -> PdfReader(file, Modifier.padding(padding).fillMaxSize())
            isHtml -> {
                var html by remember(file.absolutePath) { mutableStateOf<String?>(null) }
                LaunchedEffect(file.absolutePath) { html = withContext(Dispatchers.IO) { runCatching { file.bufferedReader(Charsets.UTF_8).use { it.readTextBounded(2_000_000) } }.getOrNull() } }
                if (html == null) Box(Modifier.fillMaxSize().padding(padding), contentAlignment=Alignment.Center) { CircularProgressIndicator() }
                else AndroidView(modifier=Modifier.fillMaxSize().padding(padding), factory={ ctx -> WebView(ctx).apply { settings.javaScriptEnabled=false; settings.allowFileAccess=false; settings.allowContentAccess=false; loadDataWithBaseURL(null, html!!, "text/html", "UTF-8", null) } })
            }
            else -> {
                var text by remember(file.absolutePath) { mutableStateOf<String?>(null) }
                LaunchedEffect(file.absolutePath) { text = withContext(Dispatchers.IO) { runCatching { file.bufferedReader(Charsets.UTF_8).use { it.readTextBounded(1_000_000) } }.getOrNull() } }
                if (text == null) Box(Modifier.fillMaxSize().padding(padding), contentAlignment=Alignment.Center) { CircularProgressIndicator() }
                else androidx.compose.foundation.lazy.LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp)) { item { Text(text ?: "Não foi possível ler este arquivo.", style=MaterialTheme.typography.bodyMedium) } }
            }
        }
    }
}

@Composable
private fun PdfReader(file: File, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var pageIndex by remember(file.absolutePath) { mutableIntStateOf(0) }
    var pageCount by remember(file.absolutePath) { mutableIntStateOf(0) }
    var bitmap by remember(file.absolutePath) { mutableStateOf<Bitmap?>(null) }
    var pdfError by remember(file.absolutePath) { mutableStateOf<String?>(null) }
    var readerMode by rememberSaveable(file.absolutePath) { mutableStateOf("Vertical") }
    var filter by rememberSaveable(file.absolutePath) { mutableStateOf("Original") }
    var brightness by rememberSaveable(file.absolutePath) { mutableFloatStateOf(1f) }
    var settingsOpen by rememberSaveable(file.absolutePath) { mutableStateOf(false) }
    var extractedText by remember(file.absolutePath, pageIndex) { mutableStateOf<String?>(null) }
    var textError by remember(file.absolutePath, pageIndex) { mutableStateOf<String?>(null) }
    var textLoading by remember(file.absolutePath, pageIndex) { mutableStateOf(false) }
    var fontSize by rememberSaveable(file.absolutePath) { mutableFloatStateOf(18f) }
    var lineSpacing by rememberSaveable(file.absolutePath) { mutableFloatStateOf(1.45f) }
    var ocrRunning by remember(file.absolutePath) { mutableStateOf(false) }
    LaunchedEffect(file.absolutePath, pageIndex) {
        textLoading = true; textError = null; extractedText = null
        val result = withContext(Dispatchers.IO) {
            runCatching {
                PDFBoxResourceLoader.init(context.applicationContext)
                PDDocument.load(file).use { doc ->
                    if (doc.numberOfPages == 0) "" else PDFTextStripper().apply { startPage = pageIndex + 1; endPage = pageIndex + 1 }.getText(doc).trim()
                }
            }
        }
        result.onSuccess { extractedText = it }.onFailure { textError = it.message ?: "Não foi possível extrair o texto deste PDF." }
        textLoading = false
    }
    LaunchedEffect(file.absolutePath, pageIndex) {
        pdfError = null
        val result = withContext(Dispatchers.IO) {
            runCatching {
                android.os.ParcelFileDescriptor.open(file, android.os.ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
                    android.graphics.pdf.PdfRenderer(pfd).use { renderer ->
                        val count = renderer.pageCount
                        require(count > 0) { "O PDF não contém páginas." }
                        val index = pageIndex.coerceIn(0, count - 1)
                        renderer.openPage(index).use { page ->
                            val widthScale = 1200f / page.width
                            val pixelScale = kotlin.math.sqrt(4_000_000.0 / (page.width.toDouble() * page.height.toDouble())).toFloat()
                            val scale = minOf(widthScale, pixelScale, 1.75f).coerceAtLeast(0.1f)
                            val bmp = Bitmap.createBitmap((page.width * scale).toInt().coerceAtLeast(1), (page.height * scale).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
                            android.graphics.Canvas(bmp).drawColor(android.graphics.Color.WHITE)
                            page.render(bmp, null, null, android.graphics.pdf.PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            Triple(bmp, count, null as String?)
                        }
                    }
                }
            }.getOrElse { Triple(null, 0, it.message ?: "Não foi possível abrir o PDF.") }
        }
        bitmap = result.first; pageCount = result.second; pdfError = result.third
    }
    Column(modifier) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onClick = { settingsOpen = !settingsOpen }) { Text(if (settingsOpen) "Fechar opções" else "Leitura ⚙") }
            Text(if (pageCount > 0) "${pageIndex + 1} / $pageCount" else "PDF", style = MaterialTheme.typography.labelLarge)
            Row {
                TextButton(enabled = pageIndex > 0, onClick = { pageIndex-- }) { Text("‹") }
                TextButton(enabled = pageCount > 0 && pageIndex < pageCount - 1, onClick = { pageIndex++ }) { Text("›") }
            }
        }
        if (settingsOpen) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)) {
                Text("Modo de navegação", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Vertical", "Horizontal", "Livro", "Texto").forEach { mode ->
                        FilterChip(selected = readerMode == mode, onClick = { readerMode = mode }, label = { Text(mode) })
                    }
                }
                Text("Filtro noturno", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Original", "Sépia").forEach { mode ->
                        FilterChip(selected = filter == mode, onClick = { filter = mode }, label = { Text(mode) })
                    }
                }
                Text("Brilho do leitor: ${(brightness * 100).toInt()}%", style = MaterialTheme.typography.labelLarge)
                Slider(value = brightness, onValueChange = { brightness = it }, valueRange = 0.35f..1f)
                if (readerMode == "Texto") {
                    Text("Tamanho da fonte: ${fontSize.toInt()} sp", style = MaterialTheme.typography.labelLarge)
                    Slider(value = fontSize, onValueChange = { fontSize = it }, valueRange = 14f..32f)
                    Text("Espaçamento entre linhas: ${"%.2f".format(lineSpacing)}×", style = MaterialTheme.typography.labelLarge)
                    Slider(value = lineSpacing, onValueChange = { lineSpacing = it }, valueRange = 1f..2.2f)
                }
                Text("Texto selecionável extraído do PDF. Para páginas digitalizadas, use OCR.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
            }
        }
        if (readerMode == "Texto") {
            Column(Modifier.fillMaxSize().background(if (filter == "Sépia") Color(0xFFF2E3C5) else Color(0xFFFFFDF7)).padding(horizontal = 20.dp, vertical = 12.dp)) {
                when {
                    textLoading -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                    !extractedText.isNullOrBlank() -> Text(extractedText!!, modifier = Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState()), style = TextStyle(fontSize = fontSize.sp, lineHeight = (fontSize * lineSpacing).sp, color = Color(0xFF28231D)))
                    else -> Column(Modifier.fillMaxWidth().weight(1f), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (textError != null) "Não foi possível extrair o texto. Este PDF pode estar protegido ou ser uma digitalização." else "Não há texto incorporado nesta página. Parece ser uma página digitalizada.", color = Color(0xFF28231D))
                        Spacer(Modifier.height(12.dp))
                        val scope = rememberCoroutineScope()
                        Button(enabled = !ocrRunning, onClick = {
                            scope.launch {
                                ocrRunning = true
                                val recognized = withContext(Dispatchers.IO) {
                                    runCatching {
                                        val render = android.os.ParcelFileDescriptor.open(file, android.os.ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
                                            android.graphics.pdf.PdfRenderer(pfd).use { renderer ->
                                                renderer.openPage(pageIndex).use { page ->
                                                    val scale = minOf(2.5f, 2200f / page.width)
                                                    val bmp = Bitmap.createBitmap((page.width * scale).toInt().coerceAtLeast(1), (page.height * scale).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
                                                    page.render(bmp, null, null, android.graphics.pdf.PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                                                    bmp
                                                }
                                            }
                                        }
                                        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                                        try { Tasks.await(recognizer.process(InputImage.fromBitmap(render, 0))).text } finally { recognizer.close(); render.recycle() }
                                    }
                                }
                                recognized.onSuccess { extractedText = it.ifBlank { "O OCR não encontrou texto nesta página." }; textError = null }
                                    .onFailure { textError = it.message ?: "Falha ao reconhecer o texto."; extractedText = "" }
                                ocrRunning = false
                            }
                        }) { Text(if (ocrRunning) "Executando OCR…" else "Reconhecer texto (OCR)") }
                    }
                }
            }
        } else Box(Modifier.fillMaxSize().background(Color(0xFF77716A)), contentAlignment = Alignment.Center) {
            when {
                bitmap != null -> {
                    val swipeModifier = Modifier.fillMaxSize().pointerInput(readerMode, pageIndex, pageCount) {
                        if (readerMode == "Horizontal") {
                            var distance = 0f
                            detectHorizontalDragGestures(onHorizontalDrag = { _, drag -> distance += drag }, onDragEnd = { if (distance < -40 && pageIndex < pageCount - 1) pageIndex++ else if (distance > 40 && pageIndex > 0) pageIndex--; distance = 0f })
                        } else {
                            var distance = 0f
                            detectVerticalDragGestures(onVerticalDrag = { _, drag -> distance += drag }, onDragEnd = { if (distance < -40 && pageIndex < pageCount - 1) pageIndex++ else if (distance > 40 && pageIndex > 0) pageIndex--; distance = 0f })
                        }
                    }
                    Box(swipeModifier, contentAlignment = Alignment.Center) {
                        Image(bitmap!!.asImageBitmap(), contentDescription = "Página ${pageIndex + 1}", modifier = Modifier.fillMaxSize().padding(if (readerMode == "Livro") 2.dp else 8.dp), contentScale = ContentScale.Fit)
                        if (filter == "Sépia") Box(Modifier.fillMaxSize().background(Color(0xFFB68A4A).copy(alpha = 0.20f)))
                        if (brightness < 0.99f) Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = (1f - brightness) * 0.65f)))
                    }
                }
                pdfError != null -> Text("Não foi possível abrir este PDF. $pdfError", modifier = Modifier.padding(24.dp), color = MaterialTheme.colorScheme.error)
                else -> CircularProgressIndicator()
            }
        }
    }
}

private fun java.io.BufferedReader.readTextBounded(maxChars: Int): String {
    val out = StringBuilder(minOf(maxChars, 16_384))
    val buffer = CharArray(8192)
    while (out.length < maxChars) {
        val n = read(buffer, 0, minOf(buffer.size, maxChars - out.length))
        if (n <= 0) break
        out.append(buffer, 0, n)
    }
    return out.toString()
}
