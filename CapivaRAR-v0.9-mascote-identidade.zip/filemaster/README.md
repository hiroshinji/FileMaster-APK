# CapivaRAR v0.9.0

Gerenciador de arquivos Android (Kotlin + Jetpack Compose). Acessa o armazenamento com a permissão
"Gerenciar todos os arquivos" e usa `java.io.File` diretamente (sem seletor de pastas do Android).
Requer Android 11 ou superior.

## Telas
- **Início (tela cheia):** cartões grandes de armazenamento (interno e cartão SD, se houver) com uso, espaço livre e %.
  Tocar no cartão abre as pastas. Atalhos em ícones: Downloads, Fotos, Documentos e Lixeira (com contador).
- **Pastas:** lista com ícones por tipo, ordenar (nome/data/tamanho), mostrar ocultos, nova pasta.
  Segure um item para selecionar vários; a barra inferior oferece Copiar, Mover, Excluir, Renomear (1 item) e Extrair (1 arquivo compactado).
  Depois de Copiar/Mover, abra a pasta de destino e toque em **Colar aqui**.
- **Lixeira:** restaurar, apagar definitivamente, esvaziar. Itens ficam 30 dias e são apagados ao abrir o app.

## Novidades da v0.9.0
- Acesso rápido: Downloads, Imagens, Vídeos, Áudios, Documentos, APKs, Compactados, Recentes e Lixeira.
  As categorias usam o índice do sistema (MediaStore), então abrem na hora sem varrer o armazenamento.
  Funcionam como uma lista única: selecionar, copiar, mover, renomear, extrair e excluir também.
- Rolagem mais fluida: texto de tamanho/data, nome e tipo são calculados uma vez fora da tela principal;
  listagem de pastas com uma consulta ao sistema por arquivo (antes eram três); itens da lista marcados como imutáveis.
- O workflow agora gera também o APK **release** (otimizado, não depurável), bem mais fluido que o de teste.

## Novidades da v0.5.0
- Ícones coloridos por tipo: pasta, imagem, vídeo, áudio, APK, PDF, planilha, apresentação, código, texto e compactados.
- Extração com janela de progresso: porcentagem, arquivos, tamanho, tempo restante estimado e botão Cancelar (a pasta parcial é apagada).
  Em RAR a biblioteca não informa o total: a barra fica indeterminada com contagem do que já saiu, e o tempo restante só aparece na fase final.
- Excluir agora apaga definitivamente por padrão; desmarque a caixa "Apagar definitivamente (sem lixeira)" para mandar para a lixeira.

## Detalhes técnicos
- Lixeira por volume em `.CapivaRARTrash/<id>/` (payload + meta.properties). Mover para ela é instantâneo no mesmo volume.
- Nome repetido ao colar/restaurar vira "nome (1).ext".
- Abrir arquivos usa FileProvider (a versão anterior usava `file://`, que o Android bloqueia).
- Extração: .zip, .tar, .tar.gz/.tgz, .tar.bz2, .tar.xz, .gz, .7z, .rar. Caminhos com `..` são recusados, links simbólicos ignorados, limites de 50 mil entradas e 4 GB.
  Senha: 7z e RAR. ZIP com senha e RAR5 não são suportados.
- Android/data e Android/obb de outros apps continuam protegidos pelo sistema.


## Novidades da versão 0.7.0

- Miniaturas de fotos e vídeos na lista de arquivos. As miniaturas são carregadas sob demanda quando os itens entram na área visível/próxima da tela; não há varredura prévia de toda a pasta para gerar imagens.
- Cache LRU de miniaturas limitado a aproximadamente 24 MiB.
- Visualizador interno de imagens com zoom, player de vídeo/áudio com Media3, leitor de PDF página a página e visualizadores simples de HTML/texto.
- Imagens grandes são decodificadas em resolução reduzida para limitar o consumo de memória. Documentos de texto/HTML têm limite de leitura para evitar carregar arquivos enormes inteiros na memória.

Observação: a compilação e os testes em aparelho Android precisam ser executados no GitHub Actions/aparelho antes de considerar esta versão validada.


## Atualização 0.8.0 — correções após testes

- A dica de seleção é salva nas preferências e não volta a aparecer depois de fechar/reabrir o app.
- A abertura de arquivos `.apk` usa o fluxo de instalação do Android e orienta a conceder a permissão de instalação para o CapivaRAR quando necessário. O Android ainda pode bloquear APKs incompatíveis, corrompidos ou não permitidos pelas políticas do dispositivo.
- As miniaturas são limitadas a duas tarefas simultâneas, usam imagens menores e mantêm cache LRU de até 24 MiB. Os itens fora da área composta pela lista não geram miniaturas antecipadamente.
- O leitor PDF limita a renderização a cerca de 4 milhões de pixels e 900 px de largura, reduzindo o pico de memória; erros de leitura passam a ser exibidos em vez de deixar o indicador carregando indefinidamente.

**Validação pendente:** compilar com GitHub Actions e testar no aparelho. Estas alterações não foram compiladas neste ambiente.
