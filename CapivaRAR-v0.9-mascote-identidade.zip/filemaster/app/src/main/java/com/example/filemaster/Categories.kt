package com.example.filemaster

import android.content.ContentResolver
import android.content.Context
import android.media.MediaScannerConnection
import android.os.Bundle
import android.provider.MediaStore
import java.io.File
import java.text.DateFormat

enum class Category(val label: String) {
    RECENT("Recentes"),
    IMAGES("Imagens"),
    VIDEOS("Vídeos"),
    AUDIO("Áudios"),
    DOCS("Documentos"),
    APKS("APKs"),
    ARCHIVES("Compactados")
}

/** Lista arquivos por categoria usando o índice do sistema (MediaStore): instantâneo, sem varrer o armazenamento. */
object Categories {
    private val DOC_EXT = listOf("pdf", "doc", "docx", "txt", "xls", "xlsx", "ppt", "pptx", "odt", "ods", "odp", "csv", "rtf", "md")
    private val APK_EXT = listOf("apk", "xapk", "apks")
    private val ARCHIVE_EXT = listOf("zip", "rar", "7z", "gz", "tgz", "bz2", "xz", "tar", "iso")

    private fun extensionFilter(exts: List<String>): Pair<String, Array<String>> {
        val sel = "(" + exts.joinToString(" OR ") { "${MediaStore.MediaColumns.DATA} LIKE ?" } + ")"
        return sel to exts.map { "%.$it" }.toTypedArray()
    }

    /** Caminhos escondidos, dados de outros apps e a nossa lixeira ficam de fora. */
    private fun excluded(path: String): Boolean =
        path.contains("/.") || path.contains("/Android/data/") || path.contains("/Android/obb/")

    fun query(context: Context, category: Category): List<Entry> {
        val (selection, args) = when (category) {
            Category.IMAGES -> "${MediaStore.Files.FileColumns.MEDIA_TYPE}=?" to arrayOf(MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE.toString())
            Category.VIDEOS -> "${MediaStore.Files.FileColumns.MEDIA_TYPE}=?" to arrayOf(MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO.toString())
            Category.AUDIO -> "${MediaStore.Files.FileColumns.MEDIA_TYPE}=?" to arrayOf(MediaStore.Files.FileColumns.MEDIA_TYPE_AUDIO.toString())
            Category.DOCS -> extensionFilter(DOC_EXT)
            Category.APKS -> extensionFilter(APK_EXT)
            Category.ARCHIVES -> extensionFilter(ARCHIVE_EXT)
            Category.RECENT -> "${MediaStore.MediaColumns.MIME_TYPE} IS NOT NULL AND ${MediaStore.MediaColumns.SIZE}>0" to emptyArray<String>()
        }
        val limit = if (category == Category.RECENT) 600 else 100_000
        val bundle = Bundle().apply {
            putString(ContentResolver.QUERY_ARG_SQL_SELECTION, selection)
            putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, args)
            putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, "${MediaStore.MediaColumns.DATE_MODIFIED} DESC")
            putInt(ContentResolver.QUERY_ARG_LIMIT, limit)
        }
        val projection = arrayOf(MediaStore.MediaColumns.DATA, MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.DATE_MODIFIED)
        val df = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
        val out = ArrayList<Entry>()
        try {
            context.contentResolver.query(MediaStore.Files.getContentUri("external"), projection, bundle, null)?.use { c ->
                val iData = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA)
                val iSize = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
                val iDate = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED)
                while (c.moveToNext()) {
                    val path = c.getString(iData) ?: continue
                    if (excluded(path)) continue
                    val f = File(path)
                    if (!f.isFile) continue // o índice pode ter itens já apagados
                    out.add(buildEntry(f, false, c.getLong(iSize), c.getLong(iDate) * 1000L, df, true))
                    if (category == Category.RECENT && out.size >= 200) break
                }
            }
        } catch (_: Exception) {
            // índice indisponível: devolve o que tiver
        }
        return out
    }
}

/** Avisa o sistema sobre arquivos criados/removidos/renomeados para as categorias refletirem a mudança. */
object MediaScan {
    fun scan(context: Context, paths: Collection<String>) {
        val list = ArrayList<String>()
        for (p in paths) {
            val f = File(p)
            if (f.isDirectory) {
                var n = 0
                for (c in f.walkTopDown()) {
                    if (c.isFile) {
                        list.add(c.absolutePath)
                        n++
                        if (n >= 3000) break
                    }
                }
            } else {
                list.add(p)
            }
        }
        if (list.isNotEmpty()) {
            try {
                MediaScannerConnection.scanFile(context.applicationContext, list.toTypedArray(), null, null)
            } catch (_: Exception) {
            }
        }
    }
}
