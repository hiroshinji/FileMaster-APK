@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.example.filemaster

import android.os.Environment
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties
import java.io.File
import java.nio.file.Files
import java.nio.file.attribute.BasicFileAttributes
import java.text.DateFormat
import java.util.Date
import java.time.LocalTime

enum class Screen { HOME, BROWSER, TRASH, VIEWER }

enum class SortMode(val label: String) {
    NAME("Nome"),
    DATE("Data (mais recentes)"),
    SIZE("Tamanho (maiores)")
}

data class Clipboard(val files: List<File>, val move: Boolean)

enum class FileKind { FOLDER, IMAGE, VIDEO, AUDIO, APK, PDF, SHEET, SLIDE, CODE, DOC, ARCHIVE, OTHER }

private val IMAGE_EXT = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif", "svg")
private val VIDEO_EXT = setOf("mp4", "mkv", "avi", "mov", "webm", "3gp", "flv", "wmv", "m4v", "ts")
private val AUDIO_EXT = setOf("mp3", "wav", "flac", "ogg", "m4a", "aac", "opus", "wma", "amr", "mid")
private val DOC_EXT = setOf("doc", "docx", "txt", "odt", "rtf", "md", "log")
private val SHEET_EXT = setOf("xls", "xlsx", "ods", "csv")
private val SLIDE_EXT = setOf("ppt", "pptx", "odp")
private val CODE_EXT = setOf("html", "htm", "css", "js", "json", "xml", "kt", "java", "py", "c", "cpp", "h", "sh", "yml", "yaml", "kts", "gradle")
private val ARCHIVE_EXT = setOf("zip", "rar", "7z", "gz", "bz2", "xz", "tar", "tgz", "iso")

fun kindOf(name: String, isDir: Boolean): FileKind {
    if (isDir) return FileKind.FOLDER
    val ext = name.substringAfterLast('.', "").lowercase()
    return when {
        ext in IMAGE_EXT -> FileKind.IMAGE
        ext in VIDEO_EXT -> FileKind.VIDEO
        ext in AUDIO_EXT -> FileKind.AUDIO
        ext == "apk" || ext == "xapk" || ext == "apks" -> FileKind.APK
        ext == "pdf" -> FileKind.PDF
        ext in SHEET_EXT -> FileKind.SHEET
        ext in SLIDE_EXT -> FileKind.SLIDE
        ext in CODE_EXT -> FileKind.CODE
        ext in DOC_EXT -> FileKind.DOC
        ext in ARCHIVE_EXT -> FileKind.ARCHIVE
        else -> FileKind.OTHER
    }
}

@Immutable
class Entry(
    val file: File,
    val isDir: Boolean,
    val size: Long,
    val modified: Long,
    val kind: FileKind,
    val subtitle: String
) {
    val name: String = file.name
    val path: String = file.absolutePath
    val sortKey: String = name.lowercase()
}

fun buildEntry(file: File, isDir: Boolean, size: Long, modified: Long, df: DateFormat, showParent: Boolean): Entry {
    val subtitle = (if (isDir) "" else formatSize(size) + " · ") +
        df.format(Date(modified)) +
        (if (showParent) " · " + (file.parentFile?.name ?: "") else "")
    return Entry(file, isDir, size, modified, kindOf(file.name, isDir), subtitle)
}

fun sortEntries(entries: List<Entry>, sort: SortMode): List<Entry> {
    val byName = compareBy<Entry> { it.sortKey }
    return when (sort) {
        SortMode.NAME -> entries.sortedWith(compareByDescending<Entry> { it.isDir }.then(byName))
        SortMode.DATE -> entries.sortedWith(compareByDescending<Entry> { it.isDir }.thenByDescending { it.modified })
        SortMode.SIZE -> entries.sortedWith(compareByDescending<Entry> { it.isDir }.thenByDescending { it.size }.then(byName))
    }
}

fun listDir(dir: File, showHidden: Boolean, sort: SortMode): List<Entry>? {
    val files = dir.listFiles() ?: return null
    val df = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
    val out = ArrayList<Entry>(files.size)
    for (f in files) {
        if (!showHidden && f.name.startsWith(".")) continue
        val attrs = try { Files.readAttributes(f.toPath(), BasicFileAttributes::class.java) } catch (_: Exception) { null }
        val isDir = attrs?.isDirectory ?: f.isDirectory
        val size = if (isDir) 0L else (attrs?.size() ?: f.length())
        val modified = attrs?.lastModifiedTime()?.toMillis() ?: f.lastModified()
        out.add(buildEntry(f, isDir, size, modified, df, false))
    }
    return sortEntries(out, sort)
}

// ───────────────────────────── ECRÃ INICIAL ─────────────────────────────

@Composable
internal fun HomeScreen(
    hasAccess: Boolean,
    volumes: List<Volume>,
    trashCount: Int,
    dark: Boolean,
    snackbar: SnackbarHostState,
    onToggleTheme: () -> Unit,
    onRequestAccess: () -> Unit,
    onOpenVolume: (Volume) -> Unit,
    onOpenShortcut: (File) -> Unit,
    onOpenCategory: (Category) -> Unit,
    onOpenTrash: () -> Unit
) {
    val downloads = remember { Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) }
    val tiles = listOf(
        TileSpec(Icons.Default.Download, "Downloads", C_DOWNLOAD, 0) { onOpenShortcut(downloads) },
        TileSpec(Icons.Default.Image, "Imagens", C_IMAGE, 0) { onOpenCategory(Category.IMAGES) },
        TileSpec(Icons.Default.Movie, "Vídeos", C_VIDEO, 0) { onOpenCategory(Category.VIDEOS) },
        TileSpec(Icons.Default.MusicNote, "Áudios", C_AUDIO, 0) { onOpenCategory(Category.AUDIO) },
        TileSpec(Icons.Default.Description, "Documentos", C_DOC, 0) { onOpenCategory(Category.DOCS) },
        TileSpec(Icons.Default.Android, "APKs", C_APK, 0) { onOpenCategory(Category.APKS) },
        TileSpec(Icons.Default.Archive, "Compactados", C_ARCHIVE, 0) { onOpenCategory(Category.ARCHIVES) },
        TileSpec(Icons.Default.History, "Recentes", C_RECENT, 0) { onOpenCategory(Category.RECENT) },
        TileSpec(Icons.Default.Delete, "Lixeira", C_TRASH, trashCount) { onOpenTrash() }
    )

    Scaffold(snackbarHost = { SnackbarHost(snackbar) }) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp).verticalScroll(rememberScrollState())
        ) {
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("CapivaRAR", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                    Text("Gestor de ficheiros inteligente", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                FilledTonalIconButton(onClick = onToggleTheme) {
                    Icon(if (dark) Icons.Default.LightMode else Icons.Default.DarkMode, contentDescription = "Alternar tema")
                }
            }
            Spacer(Modifier.height(16.dp))
            CapybaraGreeting()
            Spacer(Modifier.height(20.dp))

            if (!hasAccess) {
                PermissionCard(onRequestAccess)
            } else {
                volumes.forEach { v ->
                    StorageCard(v) { onOpenVolume(v) }
                    Spacer(Modifier.height(14.dp))
                }
                Spacer(Modifier.height(8.dp))
                Text("Acesso Rápido", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                tiles.chunked(3).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                        row.forEach { t -> ShortcutTile(t, Modifier.weight(1f)) }
                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                    Spacer(Modifier.height(12.dp))
                }
                Spacer(Modifier.height(20.dp))
            }
        }
    }
}

@Composable
private fun CapybaraGreeting() {
    val hour = LocalTime.now().hour
    val greeting = when (hour) {
        in 5..11 -> "Bom dia!"
        in 12..17 -> "Boa tarde!"
        else -> "Boa noite!"
    }
    val message = when (hour) {
        in 5..11 -> "Vamos organizar os seus ficheiros hoje?"
        in 12..17 -> "A sua capivara está a ajudar a gerir o espaço!"
        else -> "Tudo calmo por aqui. Descanse!"
    }
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
        shape = RoundedCornerShape(24.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Image(
                painter = painterResource(id = R.drawable.capybara_mascot),
                contentDescription = "Mascote CapivaRAR",
                modifier = Modifier.size(96.dp).clip(RoundedCornerShape(20.dp))
            )
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(greeting, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(4.dp))
                Text(message, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun PermissionCard(onRequestAccess: () -> Unit) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
        Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.onErrorContainer)
            Spacer(Modifier.height(12.dp))
            Text("Acesso ao Armazenamento Necessário", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onErrorContainer)
            Spacer(Modifier.height(8.dp))
            Text(
                "Para gerir os seus ficheiros, por favor conceda a permissão de acesso total nas definições do sistema.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onErrorContainer
            )
            Spacer(Modifier.height(16.dp))
            Button(onClick = onRequestAccess) { Text("Permitir Acesso") }
        }
    }
}

@Composable
private fun StorageCard(volume: Volume, onClick: () -> Unit) {
    val (total, free, used) = remember(volume.root) { Storage.usage(volume.root) }
    val fraction = if (total > 0) used.toFloat() / total else 0f
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(48.dp)) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            if (volume.removable) Icons.Default.SdCard else Icons.Default.Storage,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(volume.label, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("${formatSize(free)} livres de ${formatSize(total)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text("${(fraction * 100).toInt()}%", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
            Spacer(Modifier.height(16.dp))
            LinearProgressIndicator(
                progress = { fraction },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))
            )
        }
    }
}

private class TileSpec(val icon: ImageVector, val label: String, val color: Color, val badge: Int, val onClick: () -> Unit)

@Composable
private fun ShortcutTile(tile: TileSpec, modifier: Modifier) {
    Card(onClick = tile.onClick, modifier = modifier, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(Modifier.fillMaxWidth().padding(vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            BadgedBox(badge = { if (tile.badge > 0) Badge { Text("${tile.badge}") } }) {
                Box(
                    Modifier.size(44.dp).clip(CircleShape).background(tile.color.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(tile.icon, contentDescription = tile.label, tint = tile.color, modifier = Modifier.size(24.dp))
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(tile.label, style = MaterialTheme.typography.labelMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

// ───────────────────────────── NAVEGADOR DE FICHEIROS ─────────────────────────────

@Composable
internal fun BrowserScreen(
    title: String,
    path: String,
    entries: List<Entry>,
    loading: Boolean,
    busy: Boolean,
    error: String?,
    selected: List<String>,
    sort: SortMode,
    showHidden: Boolean,
    clipboard: Clipboard?,
    flat: Boolean,
    snackbar: SnackbarHostState,
    onBack: () -> Unit,
    onOpen: (Entry) -> Unit,
    onToggle: (Entry) -> Unit,
    onNewFolder: () -> Unit,
    onToggleHidden: () -> Unit,
    onSort: (SortMode) -> Unit,
    onSelectAll: () -> Unit,
    onClearSelection: () -> Unit,
    onCopy: () -> Unit,
    onCut: () -> Unit,
    onDelete: () -> Unit,
    onRename: () -> Unit,
    onExtract: () -> Unit,
    onPaste: () -> Unit,
    onCancelPaste: () -> Unit,
    onShare: () -> Unit
) {
    val selecting = selected.isNotEmpty()
    var sortMenu by remember { mutableStateOf(false) }
    var gridView by rememberSaveable(flat) { mutableStateOf(false) }
    val single = if (selected.size == 1) entries.firstOrNull { it.path == selected[0] } else null

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = {
                    if (selecting) {
                        Text("${selected.size} selecionado(s)")
                    } else {
                        Column {
                            Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(path, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = if (selecting) onClearSelection else onBack) {
                        Icon(
                            if (selecting) Icons.Default.Close else Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = if (selecting) "Cancelar" else "Voltar"
                        )
                    }
                },
                actions = {
                    if (selecting) {
                        IconButton(onClick = onShare) { Icon(Icons.Default.Share, contentDescription = "Partilhar") }
                        IconButton(onClick = onSelectAll) { Icon(Icons.Default.SelectAll, contentDescription = "Selecionar tudo") }
                    } else {
                        IconButton(onClick = { gridView = !gridView }) { Icon(if (gridView) Icons.Default.ViewList else Icons.Default.GridView, contentDescription = "Mudar visualização") }
                        if (!flat) {
                            IconButton(onClick = onNewFolder) { Icon(Icons.Default.CreateNewFolder, contentDescription = "Nova pasta") }
                            IconButton(onClick = onToggleHidden) {
                                Icon(
                                    if (showHidden) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = "Ficheiros ocultos"
                                )
                            }
                        }
                        Box {
                            IconButton(onClick = { sortMenu = true }) { Icon(Icons.Default.SortByAlpha, contentDescription = "Ordenar") }
                            DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                                SortMode.values().forEach { mode ->
                                    DropdownMenuItem(
                                        text = { Text(mode.label) },
                                        leadingIcon = { if (mode == sort) Icon(Icons.Default.Check, contentDescription = null) },
                                        onClick = { sortMenu = false; onSort(mode) }
                                    )
                                }
                            }
                        }
                    }
                }
            )
        },
        bottomBar = {
            if (selecting) {
                Surface(tonalElevation = 3.dp) {
                    Row(
                        Modifier.fillMaxWidth().navigationBarsPadding().padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        BarAction(Modifier.weight(1f), Icons.Default.ContentCopy, "Copiar", onCopy)
                        BarAction(Modifier.weight(1f), Icons.Default.ContentCut, "Mover", onCut)
                        BarAction(Modifier.weight(1f), Icons.Default.Delete, "Apagar", onDelete)
                        if (single != null) BarAction(Modifier.weight(1f), Icons.Default.DriveFileRenameOutline, "Renomear", onRename)
                        if (single != null && !single.isDir && Extractor.isSupported(single.file.name)) {
                            BarAction(Modifier.weight(1f), Icons.Default.Unarchive, "Extrair", onExtract)
                        }
                    }
                }
            } else if (clipboard != null && !flat) {
                Surface(tonalElevation = 3.dp) {
                    Row(
                        Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        I
