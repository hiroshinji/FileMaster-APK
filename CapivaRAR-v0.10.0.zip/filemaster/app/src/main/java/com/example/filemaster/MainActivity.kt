package com.example.filemaster

import android.app.Activity
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.content.FileProvider
import androidx.core.view.WindowCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CapivaRARLaunch() }
    }
}


@Composable
private fun CapivaRARLaunch() {
    var showSplash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        delay(1000)
        showSplash = false
    }
    if (showSplash) {
        Column(
            modifier = Modifier.fillMaxSize().background(Color(0xFF211516)).padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.capybara_mascot),
                contentDescription = "Capivarinha do CapivaRAR",
                modifier = Modifier.fillMaxWidth(0.82f).weight(1f, fill = false).heightIn(max = 360.dp),
                contentScale = ContentScale.Fit
            )
            Spacer(Modifier.height(20.dp))
            Text("CapivaRAR", color = Color(0xFFFFE6B0), style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(8.dp))
            Text("FOTOS  •  VÍDEOS  •  ARQUIVOS", color = Color(0xFFF2D6D8), style = MaterialTheme.typography.titleSmall)
        }
    } else {
        FileMasterApp()
    }
}

private class ExtractJob(val name: String, val cancel: AtomicBoolean)

private sealed interface UiDialog {
    data object NewFolder : UiDialog
    data class Rename(val file: File) : UiDialog
    data class Delete(val files: List<File>) : UiDialog
    data class Password(val file: File, val retry: Boolean) : UiDialog
    data class DeleteForever(val item: TrashItem) : UiDialog
    data object EmptyTrash : UiDialog
}

@Composable
private fun FileMasterApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("capivarar", Context.MODE_PRIVATE) }
    val systemDark = isSystemInDarkTheme()

    var dark by remember { mutableStateOf(prefs.getBoolean("dark", systemDark)) }
    var themeChoice by remember { mutableIntStateOf(prefs.getInt("theme", 0)) }
    var showHidden by remember { mutableStateOf(false) }
    var sort by remember { mutableStateOf(SortMode.NAME) }
    var hasAccess by remember { mutableStateOf(Environment.isExternalStorageManager()) }
    val volumes = remember(hasAccess) { Storage.volumes(context) }
    val trash = remember(volumes) { TrashStore(volumes.map { it.root }) }

    var screen by remember { mutableStateOf(Screen.HOME) }
    var viewerFile by remember { mutableStateOf<File?>(null) }
    LaunchedEffect(Unit) {
        val activity = context as? Activity
        val incoming = activity?.intent
        val uri = incoming?.data ?: if (incoming?.action == Intent.ACTION_SEND) {
            @Suppress("DEPRECATION")
            incoming.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
        } else null
        if (uri != null && (incoming?.action == Intent.ACTION_VIEW || incoming?.action == Intent.ACTION_SEND)) {
            val displayName = runCatching {
                context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) cursor.getString(0) else null
                }
            }.getOrNull()
            val name = (displayName ?: uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':') ?: "arquivo").ifBlank { "arquivo" }
            val safeName = name.replace(Regex("[^A-Za-z0-9._-]"), "_").take(100).ifBlank { "arquivo" }
            val destination = File(context.cacheDir, "recebido_${System.currentTimeMillis()}_$safeName")
            val copied = withContext(Dispatchers.IO) {
                runCatching { context.contentResolver.openInputStream(uri)?.use { input -> destination.outputStream().use { output -> input.copyTo(output) } }; destination.isFile && destination.length() > 0L }.getOrDefault(false)
            }
            if (copied) { viewerFile = destination; screen = Screen.VIEWER }
            else { viewerFile = null }
        }
    }
    var currentDir by remember { mutableStateOf<File?>(null) }
    var browseRoot by remember { mutableStateOf<File?>(null) }
    val selected = remember { mutableStateListOf<String>() }
    var clipboard by remember { mutableStateOf<Clipboard?>(null) }
    var refresh by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf<UiDialog?>(null) }
    var entries by remember { mutableStateOf(emptyList<Entry>()) }
    var loading by remember { mutableStateOf(false) }
    var listError by remember { mutableStateOf<String?>(null) }
    var trashItems by remember { mutableStateOf(emptyList<TrashItem>()) }
    var hintShown by remember { mutableStateOf(prefs.getBoolean("selection_hint_shown", false)) }
    var category by remember { mutableStateOf<Category?>(null) }
    var flatSort by remember { mutableStateOf(SortMode.DATE) }
    var extractJob by remember { mutableStateOf<ExtractJob?>(null) }
    var extractProgress by remember { mutableStateOf<ExtractProgress?>(null) }
    var cancelling by remember { mutableStateOf(false) }
    val snackbar = remember { SnackbarHostState() }

    fun toast(msg: String) {
        scope.launch {
            snackbar.currentSnackbarData?.dismiss()
            snackbar.showSnackbar(msg)
        }
    }

    // Roda a operação fora da thread principal; o bloco devolve a mensagem a mostrar.
    fun runTask(block: () -> String) {
        scope.launch {
            busy = true
            val message = try {
                withContext(Dispatchers.IO) { block() }
            } catch (e: Exception) {
                "Operação falhou: ${e.message ?: "erro desconhecido"}"
            }
            busy = false
            refresh++
            toast(message)
        }
    }

    fun requestAccess() {
        try {
            context.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${context.packageName}")))
        } catch (_: Exception) {
            try {
                context.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            } catch (_: Exception) {
                toast("Abra Configurações > Aplicativos > CapivaRAR > Permissões.")
            }
        }
    }

    fun openFolder(dir: File, root: File) {
        if (!dir.isDirectory) {
            toast("Pasta não encontrada.")
            return
        }
        category = null
        currentDir = dir
        browseRoot = root
        selected.clear()
        screen = Screen.BROWSER
        if (!hintShown) {
            hintShown = true
            prefs.edit().putBoolean("selection_hint_shown", true).apply()
            toast("Dica da Capivarinha 🦫: segure um item para selecionar vários.")
        }
    }

    fun openCategory(c: Category) {
        category = c
        currentDir = null
        selected.clear()
        entries = emptyList()
        screen = Screen.BROWSER
        if (!hintShown) {
            hintShown = true
            prefs.edit().putBoolean("selection_hint_shown", true).apply()
            toast("Dica da Capivarinha 🦫: segure um item para selecionar vários.")
        }
    }

    fun goBack() {
        when {
            screen == Screen.VIEWER -> { viewerFile = null; screen = Screen.BROWSER }
            selected.isNotEmpty() -> selected.clear()
            screen == Screen.TRASH -> screen = Screen.HOME
            screen == Screen.BROWSER && category != null -> {
                category = null
                screen = Screen.HOME
            }
            screen == Screen.BROWSER -> {
                val d = currentDir
                val r = browseRoot
                val parent = d?.parentFile
                if (d != null && r != null && parent != null && d.absolutePath != r.absolutePath) {
                    currentDir = parent
                } else {
                    screen = Screen.HOME
                }
            }
        }
    }

    fun openFile(file: File) {
        val ext = file.extension.lowercase()
        val isApk = ext == "apk"
        val internal = ext in setOf("jpg","jpeg","png","gif","webp","bmp","heic","heif","mp4","mkv","avi","mov","webm","3gp","flv","wmv","m4v","ts","mp3","wav","flac","ogg","m4a","aac","opus","wma","amr","mid","pdf","html","htm","txt","log","md","json","xml","csv","css","js","kt","java","py","c","cpp","h","sh","yml","yaml","kts","gradle")
        if (internal) { viewerFile = file; screen = Screen.VIEWER; return }
        try {
            if (!file.isFile || !file.canRead()) {
                toast("Não foi possível ler este arquivo.")
                return
            }
            if (isApk && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !context.packageManager.canRequestPackageInstalls()) {
                val settingsIntent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${context.packageName}"))
                settingsIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(settingsIntent)
                toast("Permita instalar apps desconhecidos para o CapivaRAR e toque no APK novamente.")
                return
            }
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val mime = if (isApk) "application/vnd.android.package-archive" else (MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*")
            val intent = Intent(if (isApk) Intent.ACTION_INSTALL_PACKAGE else Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                clipData = ClipData.newRawUri("", uri)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            toast(if (isApk) "Não foi possível iniciar o instalador. Verifique a permissão para instalar apps desconhecidos e se o APK está íntegro." else "Nenhum aplicativo compatível encontrado.")
        }
    }

    fun shareFiles(files: List<File>) {
        val readable = files.filter { it.exists() && it.isFile && it.canRead() }
        if (readable.isEmpty()) { toast("Não há arquivos acessíveis para compartilhar."); return }
        try {
            val uris = ArrayList<Uri>()
            readable.forEach { uris.add(FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", it)) }
            val intent = if (uris.size == 1) Intent(Intent.ACTION_SEND).apply {
                type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(readable.first().extension.lowercase()) ?: "*/*"
                putExtra(Intent.EXTRA_STREAM, uris.first())
            } else Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "*/*"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            }
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            intent.clipData = ClipData.newUri(context.contentResolver, "Arquivos do CapivaRAR", uris.first()).also { clip -> uris.drop(1).forEach { clip.addItem(ClipData.Item(it)) } }
            context.startActivity(Intent.createChooser(intent, "Compartilhar com"))
        } catch (e: Exception) { toast("Não foi possível compartilhar: ${e.message ?: "erro desconhecido"}") }
    }

    fun startExtract(file: File, password: String?) {
        val dir = currentDir ?: file.parentFile ?: return
        selected.clear()
        val cancel = AtomicBoolean(false)
        extractJob = ExtractJob(file.name, cancel)
        extractProgress = null
        cancelling = false
        scope.launch {
            busy = true
            val result = try {
                withContext(Dispatchers.IO) {
                    Extractor.extract(file, dir, password, cancel) { p -> extractProgress = p }
                }
            } catch (_: Exception) {
                ExtractResult.Failed("Falha inesperada na extração.")
            }
            busy = false
            extractJob = null
            extractProgress = null
            refresh++
            when (result) {
                is ExtractResult.Done -> {
                    toast(
                        "Extraído em \"${result.folderName}\": ${result.files} arquivo(s)" +
                            (if (result.skipped > 0) " · ${result.skipped} ignorado(s)" else "")
                    )
                    withContext(Dispatchers.IO) { MediaScan.scan(context, listOf(File(dir, result.folderName).absolutePath)) }
                }
                ExtractResult.NeedPassword -> dialog = UiDialog.Password(file, password != null)
                ExtractResult.Cancelled -> toast("Extração cancelada.")
                is ExtractResult.Failed -> toast(result.reason)
            }
        }
    }

    fun selectedFiles(): List<File> = entries.filter { selected.contains(it.path) }.map { it.file }

    fun paste() {
        val clip = clipboard ?: return
        val dest = currentDir ?: return
        clipboard = null
        selected.clear()
        runTask {
            val r = FileOps.pasteAll(clip.files, dest, clip.move)
            MediaScan.scan(context, r.created.map { it.absolutePath } + (if (clip.move) clip.files.map { it.absolutePath } else emptyList()))
            val verb = if (clip.move) "movido(s)" else "copiado(s)"
            if (r.failed == 0) "${r.ok} item(ns) $verb." else "${r.ok} $verb, ${r.failed} falharam."
        }
    }

    // ── efeitos ──
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) hasAccess = Environment.isExternalStorageManager()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(hasAccess, trash) {
        if (hasAccess) withContext(Dispatchers.IO) { trash.purgeExpired() }
    }

    LaunchedEffect(screen, refresh, hasAccess, trash) {
        if (hasAccess && screen != Screen.BROWSER) {
            trashItems = withContext(Dispatchers.IO) { trash.list() }
        }
    }

    LaunchedEffect(currentDir, category, refresh, showHidden, sort, flatSort, screen) {
        if (screen == Screen.BROWSER) {
            val cat = category
            val dir = currentDir
            if (cat != null) {
                loading = true
                entries = withContext(Dispatchers.IO) { sortEntries(Categories.query(context, cat), flatSort) }
                listError = null
                loading = false
            } else if (dir != null) {
                loading = true
                val result = withContext(Dispatchers.IO) { listDir(dir, showHidden, sort) }
                entries = result ?: emptyList()
                listError = if (result == null) "Sem permissão para ler esta pasta." else null
                loading = false
            }
        }
    }

    BackHandler(enabled = screen != Screen.HOME || selected.isNotEmpty()) { goBack() }

    // Cor dos ícones da barra de status/navegação acompanha o tema escolhido no app.
    val view = LocalView.current
    SideEffect {
        val window = (view.context as? Activity)?.window
        if (window != null) {
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !dark
            controller.isAppearanceLightNavigationBars = !dark
        }
    }

    val colors = remember(dark, themeChoice, context) {
        when (themeChoice) {
            1 -> if (dark) darkColorScheme(primary = Color(0xFF8BC6A5), onPrimary = Color(0xFF062E1C), primaryContainer = Color(0xFF174A32), onPrimaryContainer = Color(0xFFD2F5DE), secondary = Color(0xFFB7D9B9), secondaryContainer = Color(0xFF294B39), background = Color(0xFF101A14), surface = Color(0xFF16221A), surfaceVariant = Color(0xFF26382D), onSurface = Color(0xFFE1EDE4), onSurfaceVariant = Color(0xFFB8C9BC)) else lightColorScheme(primary = Color(0xFF246B4A), onPrimary = Color.White, primaryContainer = Color(0xFFC7EBD4), onPrimaryContainer = Color(0xFF123D29), secondary = Color(0xFF5A8C69), secondaryContainer = Color(0xFFDCEBDD), background = Color(0xFFF3F8F1), surface = Color(0xFFFBFFF9), surfaceVariant = Color(0xFFE0EAE0), onSurface = Color(0xFF17251B), onSurfaceVariant = Color(0xFF405648))
            2 -> if (dark) darkColorScheme(primary = Color(0xFFE0B2FF), onPrimary = Color(0xFF35134D), primaryContainer = Color(0xFF4C2766), onPrimaryContainer = Color(0xFFF2D9FF), secondary = Color(0xFFC7A7E8), secondaryContainer = Color(0xFF422957), background = Color(0xFF1A1420), surface = Color(0xFF241B2C), surfaceVariant = Color(0xFF382A43), onSurface = Color(0xFFF1E7F7), onSurfaceVariant = Color(0xFFD0BEDD)) else lightColorScheme(primary = Color(0xFF7040A0), onPrimary = Color.White, primaryContainer = Color(0xFFEAD6FA), onPrimaryContainer = Color(0xFF3B185A), secondary = Color(0xFF8A63B8), secondaryContainer = Color(0xFFE8DDF3), background = Color(0xFFF8F2FC), surface = Color(0xFFFFFAFF), surfaceVariant = Color(0xFFEDE2F4), onSurface = Color(0xFF271D30), onSurfaceVariant = Color(0xFF594A63))
            3 -> if (dark) darkColorScheme(primary = Color(0xFFFFC078), onPrimary = Color(0xFF4B2100), primaryContainer = Color(0xFF663714), onPrimaryContainer = Color(0xFFFFDCC0), secondary = Color(0xFFFFD6A1), secondaryContainer = Color(0xFF553820), background = Color(0xFF21160F), surface = Color(0xFF2C1D13), surfaceVariant = Color(0xFF463022), onSurface = Color(0xFFF7E7D8), onSurfaceVariant = Color(0xFFD9BFA9)) else lightColorScheme(primary = Color(0xFF9B4D18), onPrimary = Color.White, primaryContainer = Color(0xFFFFDCC0), onPrimaryContainer = Color(0xFF4B2100), secondary = Color(0xFFBA6B32), secondaryContainer = Color(0xFFF5DFC9), background = Color(0xFFFFF5EC), surface = Color(0xFFFFFAF5), surfaceVariant = Color(0xFFF3E1D1), onSurface = Color(0xFF2B1D14), onSurfaceVariant = Color(0xFF654A38))
            else -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) { if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context) } else { if (dark) darkColorScheme() else lightColorScheme() }
        }
    }

    MaterialTheme(colorScheme = colors) {
        Surface(Modifier.fillMaxSize()) {
            when (screen) {
                Screen.HOME -> HomeScreen(
                    hasAccess = hasAccess,
                    volumes = volumes,
                    trashCount = trashItems.size,
                    dark = dark,
                    snackbar = snackbar,
                    onToggleTheme = { if (dark) { dark = false; prefs.edit().putBoolean("dark", false).apply(); toast("Tema claro") } else if (themeChoice < 3) { themeChoice++; prefs.edit().putInt("theme", themeChoice).apply(); toast("Tema ${listOf("Sistema", "Natureza", "Lavanda", "Âmbar")[themeChoice]}") } else { dark = true; themeChoice = 0; prefs.edit().putBoolean("dark", true).putInt("theme", 0).apply(); toast("Tema escuro") } },
                    onRequestAccess = { requestAccess() },
                    onOpenVolume = { v -> openFolder(v.root, v.root) },
                    onOpenShortcut = { f -> openFolder(f, volumes.first().root) },
                    onOpenCategory = { c -> openCategory(c) },
                    onOpenTrash = { screen = Screen.TRASH }
                )

                Screen.BROWSER -> {
                    val dir = currentDir
                    val cat = category
                    if (dir != null || cat != null) {
                        val title = cat?.label
                            ?: dir?.let { d -> volumes.firstOrNull { it.root.absolutePath == d.absolutePath }?.label ?: d.name.ifBlank { "Armazenamento" } }
                            ?: ""
                        val flat = cat != null
                        BrowserScreen(
                            title = title,
                            path = if (flat) "${entries.size} arquivo(s)" else (dir?.absolutePath ?: ""),
                            entries = entries,
                            loading = loading,
                            busy = busy,
                            error = listError,
                            selected = selected,
                            sort = if (flat) flatSort else sort,
                            showHidden = showHidden,
                            clipboard = if (flat) null else clipboard,
                            flat = flat,
                            snackbar = snackbar,
                            onBack = { goBack() },
                            onOpen = { e -> if (e.isDir) { selected.clear(); currentDir = e.file } else openFile(e.file) },
                            onToggle = { e ->
                                val p = e.path
                                if (selected.contains(p)) selected.remove(p) else selected.add(p)
                            },
                            onNewFolder = { dialog = UiDialog.NewFolder },
                            onToggleHidden = { showHidden = !showHidden },
                            onSort = { if (flat) flatSort = it else sort = it },
                            onSelectAll = {
                                selected.clear()
                                selected.addAll(entries.map { it.path })
                            },
                            onClearSelection = { selected.clear() },
                            onCopy = {
                                val files = selectedFiles()
                                clipboard = Clipboard(files, move = false)
                                selected.clear()
                                toast("${files.size} item(ns) copiado(s). Abra a pasta de destino e toque em Colar aqui.")
                            },
                            onCut = {
                                val files = selectedFiles()
                                clipboard = Clipboard(files, move = true)
                                selected.clear()
                                toast("${files.size} item(ns) para mover. Abra a pasta de destino e toque em Colar aqui.")
                            },
                            onDelete = { dialog = UiDialog.Delete(selectedFiles()) },
                            onRename = { selectedFiles().firstOrNull()?.let { dialog = UiDialog.Rename(it) } },
                            onExtract = { selectedFiles().firstOrNull()?.let { startExtract(it, null) } },
                            onPaste = { paste() },
                            onCancelPaste = { clipboard = null },
                            onShare = { shareFiles(selectedFiles()) }
                        )
                    }
                }

                Screen.VIEWER -> viewerFile?.let { file -> MediaViewer(file, onBack = { viewerFile = null; screen = Screen.BROWSER }, onNavigateMedia = { viewerFile = it }) }

                Screen.TRASH -> TrashScreen(
                    items = trashItems,
                    busy = busy,
                    snackbar = snackbar,
                    onBack = { screen = Screen.HOME },
                    onRestore = { item -> runTask { trash.restore(item) ?: "\"${item.name}\" restaurado." } },
                    onDelete = { item -> dialog = UiDialog.DeleteForever(item) },
                    onEmpty = { dialog = UiDialog.EmptyTrash }
                )
            }
        }

        when (val d = dialog) {
            null -> {}
            UiDialog.NewFolder -> NameDialog("Nova pasta", "", "Criar", { dialog = null }) { name ->
                dialog = null
                val dir = currentDir
                if (dir != null) runTask { FileOps.createFolder(dir, name) ?: "Pasta criada." }
            }
            is UiDialog.Rename -> NameDialog("Renomear", d.file.name, "Renomear", { dialog = null }) { name ->
                dialog = null
                selected.clear()
                if (name != d.file.name) runTask {
                    val err = FileOps.rename(d.file, name)
                    if (err == null) MediaScan.scan(context, listOf(d.file.absolutePath, File(d.file.parentFile, name).absolutePath))
                    err ?: "Renomeado."
                }
            }
            is UiDialog.Delete -> DeleteDialog(d.files.size, { dialog = null }) { permanent ->
                dialog = null
                selected.clear()
                runTask {
                    var ok = 0
                    val errors = mutableListOf<String>()
                    for (f in d.files) {
                        if (permanent) {
                            if (FileOps.deleteForever(f)) ok++ else errors.add("não foi possível apagar \"${f.name}\"")
                        } else {
                            val e = trash.moveToTrash(f)
                            if (e == null) ok++ else errors.add(e)
                        }
                    }
                    MediaScan.scan(context, d.files.map { it.absolutePath })
                    val what = if (permanent) "apagado(s)" else "movido(s) para a lixeira"
                    if (errors.isEmpty()) "$ok item(ns) $what." else "$ok $what. Falha: ${errors.first()}"
                }
            }
            is UiDialog.Password -> PasswordDialog(d.retry, { dialog = null }) { pw ->
                dialog = null
                startExtract(d.file, pw)
            }
            is UiDialog.DeleteForever -> ConfirmDialog(
                title = "Apagar definitivamente?",
                text = "\"${d.item.name}\" será apagado e não poderá ser recuperado.",
                confirm = "Apagar",
                onDismiss = { dialog = null }
            ) {
                dialog = null
                runTask { if (trash.deleteForever(d.item)) "Item apagado." else "Não foi possível apagar." }
            }
            UiDialog.EmptyTrash -> ConfirmDialog(
                title = "Esvaziar a lixeira?",
                text = "Todos os itens da lixeira serão apagados definitivamente.",
                confirm = "Esvaziar",
                onDismiss = { dialog = null }
            ) {
                dialog = null
                runTask {
                    val failed = trash.emptyAll()
                    if (failed == 0) "Lixeira esvaziada." else "$failed item(ns) não puderam ser apagados."
                }
            }
        }

        val job = extractJob
        if (job != null) {
            ExtractProgressDialog(job.name, extractProgress, cancelling) {
                cancelling = true
                job.cancel.set(true)
            }
        }
    }
}
