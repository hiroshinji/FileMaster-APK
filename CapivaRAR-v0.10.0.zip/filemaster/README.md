# CapivaRAR v0.9.5 (prévia de recursos)

Gerenciador de arquivos Android (Kotlin + Jetpack Compose). Acessa o armazenamento com a permissão
"Gerenciar todos os arquivos" e usa `java.io.File` diretamente (sem seletor de pastas do Android).
Requer Android 11 ou superior.

## Telas
- **Início (tela cheia):** cartões grandes de armazenamento (interno e cartão SD, se houver) com uso, espaço livre e %.
  Tocar no cartão abre as pastas. Atalhos em ícones: Downloads, Fotos, Documentos e Lixeira (com contador).
- **Pastas:** lista com ícones por tipo, ordenar (nome/data/tamanho), mostrar ocultos, nova pasta.
  Segure um item para selecionar vários; a barra inferior oferece Copiar, Mover, Excluir, Renomear (1 item) e Extrair (1 arquivo compactado).
  Depois de Copiar/Mover, abra a pasta de destino e toque em **Colar aqui**.
- **Lixeira:** restaurar, apagar definitivamente, esvaziar. Itens ficam 30 dias e são apagados ao abrir o app.

## Novidades da v0.9.5
- Leitor de PDF com navegação por gesto vertical/horizontal, modo de página ampliada para leitura, filtro sépia e controle de luminosidade do conteúdo.
- Grade opcional em pastas, com miniaturas carregadas sob demanda e usando o cache limitado já existente; a lista continua disponível.
- Compartilhamento de múltiplos arquivos pelo menu do Android (inclui apps instalados como WhatsApp e Bluetooth quando compatíveis).
- CapivaRAR passa a declarar suporte para receber PDFs, imagens, vídeos, áudios e textos via “Abrir com”. A escolha e o padrão dependem da tela de resolução de aplicativos do Android.
- Mais paletas de cores (natureza, lavanda e âmbar), além dos temas claro/escuro.

**Limitação conhecida:** o modo “Livro” ainda mostra a página original ajustada à tela; ele não extrai/reflui o texto de PDFs como um Kindle. PDF digitalizado exige OCR para virar texto reformatável. A compilação desta versão ainda precisa ser validada no GitHub Actions e no dispositivo Android.

## Novidades da v0.9.0
- Acesso rápido: Downloads, Imagens, Vídeos, Áudios, Documentos, APKs, Compactados, Recentes e Lixeira.
  As categorias usam o índice do sistema (MediaStore), então abrem na hora sem varrer o armazenamento.
  Funcionam como uma lista única: selecionar, copiar, mover, renomear, extrair e excluir também.
- Rolagem mais fluida: texto de tamanho/data, nome e tipo são calculados uma vez fora da tela principal;
  listagem de pastas com uma consulta ao sistema por arquivo (antes eram três); itens da lista marcados como imutáveis.
- O workflow agora gera também o APK **release** (otimizado, não depurável), bem mais fluido que o de teste.

## Novidades da v0.5.0
- Ícones coloridos por tipo: pasta, imagem, vídeo, áudio, APK, PDF, planilha, apresentação, código, texto e compactados.
- Extração com janela de progresso: porcentagem, arquivos, tamanho, tempo restante estimado e botão Cancelar (a pasta parcial é apagada).
  Em RAR a biblioteca não informa o total: a barra fica indeterminada com contagem do que já saiu, e o tempo restante só aparece na fase final.
- Excluir agora apaga definitivamente por padrão; desmarque a caixa "Apagar definitivamente (sem lixeira)" para mandar para a lixeira.

## Detalhes técnicos
- Lixeira por volume em `.CapivaRARTrash/<id>/` (payload + meta.properties). Mover para ela é instantâneo no mesmo volume.
- Nome repetido ao colar/restaurar vira "nome (1).ext".
- Abrir arquivos usa FileProvider (a versão anterior usava `file://`, que o Android bloqueia).
- Extração: .zip, .tar, .tar.gz/.tgz, .tar.bz2, .tar.xz, .gz, .7z, .rar. Caminhos com `..` são recusados, links simbólicos ignorados, limites de 50 mil entradas e 4 GB.
  Senha: 7z e RAR. ZIP com senha e RAR5 não são suportados.
- Android/data e Android/obb de outros apps continuam protegidos pelo sistema.


## Novidades da versão 0.7.0

- Miniaturas de fotos e vídeos na lista de arquivos. As miniaturas são carregadas sob demanda quando os itens entram na área visível/próxima da tela; não há varredura prévia de toda a pasta para gerar imagens.
- Cache LRU de miniaturas limitado a aproximadamente 24 MiB.
- Visualizador interno de imagens com zoom, player de vídeo/áudio com Media3, leitor de PDF página a página e visualizadores simples de HTML/texto.
- Imagens grandes são decodificadas em resolução reduzida para limitar o consumo de memória. Documentos de texto/HTML têm limite de leitura para evitar carregar arquivos enormes inteiros na memória.

Observação: a compilação e os testes em aparelho Android precisam ser executados no GitHub Actions/aparelho antes de considerar esta versão validada.


## Atualização 0.8.0 — correções após testes

- A dica de seleção é salva nas preferências e não volta a aparecer depois de fechar/reabrir o app.
- A abertura de arquivos `.apk` usa o fluxo de instalação do Android e orienta a conceder a permissão de instalação para o CapivaRAR quando necessário. O Android ainda pode bloquear APKs incompatíveis, corrompidos ou não permitidos pelas políticas do dispositivo.
- As miniaturas são limitadas a duas tarefas simultâneas, usam imagens menores e mantêm cache LRU de até 24 MiB. Os itens fora da área composta pela lista não geram miniaturas antecipadamente.
- O leitor PDF limita a renderização a cerca de 4 milhões de pixels e 900 px de largura, reduzindo o pico de memória; erros de leitura passam a ser exibidos em vez de deixar o indicador carregando indefinidamente.

**Validação pendente:** compilar com GitHub Actions e testar no aparelho. Estas alterações não foram compiladas neste ambiente.


## v0.9.6 — leitura refluível e OCR

- Modo **Texto** no leitor de PDF: extrai o texto incorporado por página usando PDFBox-Android.
- Controles de tamanho da fonte e espaçamento entre linhas.
- OCR local com ML Kit para páginas digitalizadas ou sem texto incorporado; o reconhecimento é iniciado manualmente e por página para controlar consumo de memória e bateria.
- O PDF original permanece intacto; OCR apenas apresenta o texto reconhecido na sessão de leitura.
- Dependências adicionadas: PDFBox-Android e ML Kit Text Recognition.

**Limitações conhecidas:** a ordem de leitura pode variar em PDFs com colunas, tabelas, notas ou layout complexo. O OCR é por página, não converte o arquivo PDF nem salva uma camada de texto pesquisável no documento original. É necessário compilar e testar no Android antes de considerar esta versão pronta.
