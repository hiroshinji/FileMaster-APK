package com.example.filemaster

import android.app.Activity
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.webkit.MimeTypeMap
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.content.FileProvider
import androidx.core.view.WindowCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FileMasterApp() }
    }
}

private sealed interface UiDialog {
    data object NewFolder : UiDialog
    data class Rename(val file: File) : UiDialog
    data class Delete(val files: List<File>) : UiDialog
    data class Password(val file: File, val retry: Boolean) : UiDialog
    data class DeleteForever(val item: TrashItem) : UiDialog
    data object EmptyTrash : UiDialog
}

@Composable
private fun FileMasterApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("filemaster", Context.MODE_PRIVATE) }
    val systemDark = isSystemInDarkTheme()

    var dark by remember { mutableStateOf(prefs.getBoolean("dark", systemDark)) }
    var showHidden by remember { mutableStateOf(false) }
    var sort by remember { mutableStateOf(SortMode.NAME) }
    var hasAccess by remember { mutableStateOf(Environment.isExternalStorageManager()) }
    val volumes = remember(hasAccess) { Storage.volumes(context) }
    val trash = remember(volumes) { TrashStore(volumes.map { it.root }) }

    var screen by remember { mutableStateOf(Screen.HOME) }
    var currentDir by remember { mutableStateOf<File?>(null) }
    var browseRoot by remember { mutableStateOf<File?>(null) }
    val selected = remember { mutableStateListOf<String>() }
    var clipboard by remember { mutableStateOf<Clipboard?>(null) }
    var refresh by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf<UiDialog?>(null) }
    var entries by remember { mutableStateOf(emptyList<Entry>()) }
    var loading by remember { mutableStateOf(false) }
    var listError by remember { mutableStateOf<String?>(null) }
    var trashItems by remember { mutableStateOf(emptyList<TrashItem>()) }
    var hintShown by remember { mutableStateOf(false) }
    val snackbar = remember { SnackbarHostState() }

    fun toast(msg: String) {
        scope.launch {
            snackbar.currentSnackbarData?.dismiss()
            snackbar.showSnackbar(msg)
        }
    }

    // Roda a operação fora da thread principal; o bloco devolve a mensagem a mostrar.
    fun runTask(block: () -> String) {
        scope.launch {
            busy = true
            val message = try {
                withContext(Dispatchers.IO) { block() }
            } catch (e: Exception) {
                "Operação falhou: ${e.message ?: "erro desconhecido"}"
            }
            busy = false
            refresh++
            toast(message)
        }
    }

    fun requestAccess() {
        try {
            context.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${context.packageName}")))
        } catch (_: Exception) {
            try {
                context.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            } catch (_: Exception) {
                toast("Abra Configurações > Aplicativos > FileMaster > Permissões.")
            }
        }
    }

    fun openFolder(dir: File, root: File) {
        if (!dir.isDirectory) {
            toast("Pasta não encontrada.")
            return
        }
        currentDir = dir
        browseRoot = root
        selected.clear()
        screen = Screen.BROWSER
        if (!hintShown) {
            hintShown = true
            toast("Dica: segure um item para selecionar vários.")
        }
    }

    fun goBack() {
        when {
            selected.isNotEmpty() -> selected.clear()
            screen == Screen.TRASH -> screen = Screen.HOME
            screen == Screen.BROWSER -> {
                val d = currentDir
                val r = browseRoot
                val parent = d?.parentFile
                if (d != null && r != null && parent != null && d.absolutePath != r.absolutePath) {
                    currentDir = parent
                } else {
                    screen = Screen.HOME
                }
            }
        }
    }

    fun openFile(file: File) {
        try {
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.extension.lowercase()) ?: "*/*"
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                clipData = ClipData.newRawUri("", uri)
            }
            context.startActivity(Intent.createChooser(intent, "Abrir com"))
        } catch (_: Exception) {
            toast("Nenhum aplicativo compatível encontrado.")
        }
    }

    fun startExtract(file: File, password: String?) {
        val dir = currentDir ?: return
        selected.clear()
        scope.launch {
            busy = true
            val result = try {
                withContext(Dispatchers.IO) { Extractor.extract(file, dir, password) }
            } catch (_: Exception) {
                ExtractResult.Failed("Falha inesperada na extração.")
            }
            busy = false
            refresh++
            when (result) {
                is ExtractResult.Done -> toast(
                    "Extraído em \"${result.folderName}\": ${result.files} arquivo(s)" +
                        (if (result.skipped > 0) " · ${result.skipped} ignorado(s)" else "")
                )
                ExtractResult.NeedPassword -> dialog = UiDialog.Password(file, password != null)
                is ExtractResult.Failed -> toast(result.reason)
            }
        }
    }

    fun selectedFiles(): List<File> = entries.filter { selected.contains(it.file.absolutePath) }.map { it.file }

    fun paste() {
        val clip = clipboard ?: return
        val dest = currentDir ?: return
        clipboard = null
        selected.clear()
        runTask {
            val r = FileOps.pasteAll(clip.files, dest, clip.move)
            val verb = if (clip.move) "movido(s)" else "copiado(s)"
            if (r.failed == 0) "${r.ok} item(ns) $verb." else "${r.ok} $verb, ${r.failed} falharam."
        }
    }

    // ── efeitos ──
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) hasAccess = Environment.isExternalStorageManager()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(hasAccess, trash) {
        if (hasAccess) withContext(Dispatchers.IO) { trash.purgeExpired() }
    }

    LaunchedEffect(screen, refresh, hasAccess, trash) {
        if (hasAccess && screen != Screen.BROWSER) {
            trashItems = withContext(Dispatchers.IO) { trash.list() }
        }
    }

    LaunchedEffect(currentDir, refresh, showHidden, sort, screen) {
        val dir = currentDir
        if (screen == Screen.BROWSER && dir != null) {
            loading = true
            val result = withContext(Dispatchers.IO) { listDir(dir, showHidden, sort) }
            entries = result ?: emptyList()
            listError = if (result == null) "Sem permissão para ler esta pasta." else null
            loading = false
        }
    }

    BackHandler(enabled = screen != Screen.HOME || selected.isNotEmpty()) { goBack() }

    // Cor dos ícones da barra de status/navegação acompanha o tema escolhido no app.
    val view = LocalView.current
    SideEffect {
        val window = (view.context as? Activity)?.window
        if (window != null) {
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !dark
            controller.isAppearanceLightNavigationBars = !dark
        }
    }

    val colors = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    } else {
        if (dark) darkColorScheme() else lightColorScheme()
    }

    MaterialTheme(colorScheme = colors) {
        Surface(Modifier.fillMaxSize()) {
            when (screen) {
                Screen.HOME -> HomeScreen(
                    hasAccess = hasAccess,
                    volumes = volumes,
                    trashCount = trashItems.size,
                    dark = dark,
                    snackbar = snackbar,
                    onToggleTheme = { dark = !dark; prefs.edit().putBoolean("dark", dark).apply() },
                    onRequestAccess = { requestAccess() },
                    onOpenVolume = { v -> openFolder(v.root, v.root) },
                    onOpenShortcut = { f -> openFolder(f, volumes.first().root) },
                    onOpenTrash = { screen = Screen.TRASH }
                )

                Screen.BROWSER -> {
                    val dir = currentDir
                    if (dir != null) {
                        val title = volumes.firstOrNull { it.root.absolutePath == dir.absolutePath }?.label
                            ?: dir.name.ifBlank { "Armazenamento" }
                        BrowserScreen(
                            title = title,
                            path = dir.absolutePath,
                            entries = entries,
                            loading = loading,
                            busy = busy,
                            error = listError,
                            selected = selected,
                            sort = sort,
                            showHidden = showHidden,
                            clipboard = clipboard,
                            snackbar = snackbar,
                            onBack = { goBack() },
                            onOpen = { e -> if (e.isDir) { selected.clear(); currentDir = e.file } else openFile(e.file) },
                            onToggle = { e ->
                                val p = e.file.absolutePath
                                if (selected.contains(p)) selected.remove(p) else selected.add(p)
                            },
                            onNewFolder = { dialog = UiDialog.NewFolder },
                            onToggleHidden = { showHidden = !showHidden },
                            onSort = { sort = it },
                            onSelectAll = {
                                selected.clear()
                                selected.addAll(entries.map { it.file.absolutePath })
                            },
                            onClearSelection = { selected.clear() },
                            onCopy = {
                                val files = selectedFiles()
                                clipboard = Clipboard(files, move = false)
                                selected.clear()
                                toast("${files.size} item(ns) copiado(s). Abra a pasta de destino e toque em Colar aqui.")
                            },
                            onCut = {
                                val files = selectedFiles()
                                clipboard = Clipboard(files, move = true)
                                selected.clear()
                                toast("${files.size} item(ns) para mover. Abra a pasta de destino e toque em Colar aqui.")
                            },
                            onDelete = { dialog = UiDialog.Delete(selectedFiles()) },
                            onRename = { selectedFiles().firstOrNull()?.let { dialog = UiDialog.Rename(it) } },
                            onExtract = { selectedFiles().firstOrNull()?.let { startExtract(it, null) } },
                            onPaste = { paste() },
                            onCancelPaste = { clipboard = null }
                        )
                    }
                }

                Screen.TRASH -> TrashScreen(
                    items = trashItems,
                    busy = busy,
                    snackbar = snackbar,
                    onBack = { screen = Screen.HOME },
                    onRestore = { item -> runTask { trash.restore(item) ?: "\"${item.name}\" restaurado." } },
                    onDelete = { item -> dialog = UiDialog.DeleteForever(item) },
                    onEmpty = { dialog = UiDialog.EmptyTrash }
                )
            }
        }

        when (val d = dialog) {
            null -> {}
            UiDialog.NewFolder -> NameDialog("Nova pasta", "", "Criar", { dialog = null }) { name ->
                dialog = null
                val dir = currentDir
                if (dir != null) runTask { FileOps.createFolder(dir, name) ?: "Pasta criada." }
            }
            is UiDialog.Rename -> NameDialog("Renomear", d.file.name, "Renomear", { dialog = null }) { name ->
                dialog = null
                selected.clear()
                if (name != d.file.name) runTask { FileOps.rename(d.file, name) ?: "Renomeado." }
            }
            is UiDialog.Delete -> ConfirmDialog(
                title = "Mover para a lixeira?",
                text = "${d.files.size} item(ns) ficam na lixeira por ${TrashStore.RETENTION_DAYS} dias e podem ser restaurados.",
                confirm = "Mover",
                onDismiss = { dialog = null }
            ) {
                dialog = null
                selected.clear()
                runTask {
                    var ok = 0
                    val errors = mutableListOf<String>()
                    for (f in d.files) {
                        val e = trash.moveToTrash(f)
                        if (e == null) ok++ else errors.add(e)
                    }
                    if (errors.isEmpty()) "$ok item(ns) movido(s) para a lixeira." else "$ok movido(s). Falha: ${errors.first()}"
                }
            }
            is UiDialog.Password -> PasswordDialog(d.retry, { dialog = null }) { pw ->
                dialog = null
                startExtract(d.file, pw)
            }
            is UiDialog.DeleteForever -> ConfirmDialog(
                title = "Apagar definitivamente?",
                text = "\"${d.item.name}\" será apagado e não poderá ser recuperado.",
                confirm = "Apagar",
                onDismiss = { dialog = null }
            ) {
                dialog = null
                runTask { if (trash.deleteForever(d.item)) "Item apagado." else "Não foi possível apagar." }
            }
            UiDialog.EmptyTrash -> ConfirmDialog(
                title = "Esvaziar a lixeira?",
                text = "Todos os itens da lixeira serão apagados definitivamente.",
                confirm = "Esvaziar",
                onDismiss = { dialog = null }
            ) {
                dialog = null
                runTask {
                    val failed = trash.emptyAll()
                    if (failed == 0) "Lixeira esvaziada." else "$failed item(ns) não puderam ser apagados."
                }
            }
        }
    }
}
