package com.example.filemaster

import com.github.junrar.Junrar
import org.apache.commons.compress.PasswordRequiredException
import org.apache.commons.compress.archivers.ArchiveInputStream
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry
import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import java.io.BufferedInputStream
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.nio.file.Files

sealed interface ExtractResult {
    data class Done(val files: Int, val skipped: Int, val folderName: String) : ExtractResult
    data object NeedPassword : ExtractResult
    data class Failed(val reason: String) : ExtractResult
}

private class ExtractError(message: String) : Exception(message)

private const val MAX_ENTRIES = 50_000
private const val MAX_BYTES = 4L * 1024 * 1024 * 1024 // 4 GB: proteção contra "zip bomb"

private enum class Kind { ZIP, TAR, TAR_GZ, TAR_BZ2, TAR_XZ, GZ, SEVEN_Z, RAR }

private val SUFFIXES = listOf(
    ".tar.gz" to Kind.TAR_GZ, ".tgz" to Kind.TAR_GZ,
    ".tar.bz2" to Kind.TAR_BZ2, ".tbz2" to Kind.TAR_BZ2,
    ".tar.xz" to Kind.TAR_XZ, ".txz" to Kind.TAR_XZ,
    ".tar" to Kind.TAR, ".zip" to Kind.ZIP, ".7z" to Kind.SEVEN_Z, ".rar" to Kind.RAR, ".gz" to Kind.GZ
)

/** Valida o caminho de uma entrada. Retorna os segmentos ou null se for perigoso (".." ou caminho absoluto). */
private fun cleanPath(raw: String): List<String>? {
    if (raw.startsWith("/") || raw.startsWith("\\") || Regex("^[A-Za-z]:").containsMatchIn(raw)) return null
    val parts = raw.replace('\\', '/').split('/').filter { it.isNotEmpty() && it != "." }
    if (parts.isEmpty()) return null
    if (parts.any { it == ".." || it.contains('\u0000') }) return null
    return parts
}

/** Grava as entradas dentro de [root], recusando qualquer caminho que escape dela. */
private class Sink(private val root: File) {
    var files = 0
    var skipped = 0
    private var bytes = 0L
    private val rootCanon = root.canonicalPath

    private fun resolve(parts: List<String>): File? {
        val f = File(root, parts.joinToString(File.separator))
        val c = f.canonicalPath
        return if (c.startsWith(rootCanon + File.separator)) f else null
    }

    fun checkCount() {
        if (files + skipped >= MAX_ENTRIES) throw ExtractError("Arquivo com entradas demais (limite de segurança).")
    }

    fun dir(parts: List<String>): Boolean {
        val f = resolve(parts) ?: return false
        return f.isDirectory || f.mkdirs()
    }

    fun writeFile(parts: List<String>, input: InputStream): Boolean {
        val target = resolve(parts) ?: return false
        val parent = target.parentFile ?: return false
        if (!parent.isDirectory && !parent.mkdirs()) return false
        val dest = if (target.exists()) FileOps.uniqueFile(parent, target.name) else target
        val out = try { FileOutputStream(dest) } catch (_: IOException) { return false } // nome inválido neste sistema de arquivos
        out.use { copyLimited(input, it) }
        files++
        return true
    }

    private fun copyLimited(input: InputStream, out: OutputStream) {
        val buf = ByteArray(64 * 1024)
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            bytes += n
            if (bytes > MAX_BYTES) throw ExtractError("O conteúdo excede o limite de segurança de 4 GB (possível arquivo malicioso).")
            out.write(buf, 0, n)
        }
    }
}

object Extractor {

    fun isSupported(name: String): Boolean = match(name) != null

    private fun match(name: String) = SUFFIXES.firstOrNull { name.lowercase().endsWith(it.first) }

    /** Extrai [archive] para uma pasta nova dentro de [parentDir]. Em qualquer falha, a pasta parcial é apagada. */
    fun extract(archive: File, parentDir: File, password: String?): ExtractResult {
        val m = match(archive.name) ?: return ExtractResult.Failed("Formato não suportado.")
        val kind = m.second
        val base = archive.name.dropLast(m.first.length).ifBlank { "extraido" }
        val outDir = FileOps.uniqueFile(parentDir, base)
        if (!outDir.mkdirs()) return ExtractResult.Failed("Não foi possível criar a pasta de destino.")
        val sink = Sink(outDir)
        return try {
            when (kind) {
                Kind.ZIP, Kind.TAR, Kind.TAR_GZ, Kind.TAR_BZ2, Kind.TAR_XZ -> extractStream(archive, kind, sink)
                Kind.GZ -> extractGz(archive, base, sink)
                Kind.SEVEN_Z -> extractSevenZ(archive, password, sink)
                Kind.RAR -> extractRar(archive, password, parentDir, sink)
            }
            ExtractResult.Done(sink.files, sink.skipped, outDir.name)
        } catch (_: PasswordRequiredException) {
            outDir.deleteRecursively()
            ExtractResult.NeedPassword
        } catch (e: ExtractError) {
            outDir.deleteRecursively()
            ExtractResult.Failed(e.message ?: "Falha na extração.")
        } catch (e: Exception) {
            outDir.deleteRecursively()
            val type = e.javaClass.simpleName
            val msg = (e.message ?: "").lowercase()
            when {
                kind == Kind.RAR && type.contains("V5") ->
                    ExtractResult.Failed("RAR5 ainda não é suportado pela biblioteca (só RAR 1.5 a 4).")
                (kind == Kind.RAR || kind == Kind.SEVEN_Z) && msg.contains("password") -> ExtractResult.NeedPassword
                (kind == Kind.RAR || kind == Kind.SEVEN_Z) && password != null && e is IOException ->
                    ExtractResult.Failed("Senha incorreta ou arquivo danificado.")
                else -> ExtractResult.Failed("Não foi possível extrair ($type): ${e.message ?: "erro desconhecido"}")
            }
        }
    }

    private fun extractStream(archive: File, kind: Kind, sink: Sink) {
        BufferedInputStream(FileInputStream(archive)).use { buffered ->
            val ais: ArchiveInputStream<*> = when (kind) {
                Kind.ZIP -> ZipArchiveInputStream(buffered)
                Kind.TAR -> TarArchiveInputStream(buffered)
                Kind.TAR_GZ -> TarArchiveInputStream(GzipCompressorInputStream(buffered))
                Kind.TAR_BZ2 -> TarArchiveInputStream(BZip2CompressorInputStream(buffered))
                else -> TarArchiveInputStream(XZCompressorInputStream(buffered))
            }
            ais.use { stream -> readEntries(stream, sink) }
        }
    }

    private fun readEntries(ais: ArchiveInputStream<*>, sink: Sink) {
        while (true) {
            val e = ais.nextEntry ?: break
            sink.checkCount()
            if (e is ZipArchiveEntry && e.generalPurposeBit.usesEncryption()) {
                throw ExtractError("ZIP protegido por senha ainda não é suportado.")
            }
            val parts = cleanPath(e.name)
            val special = (e is TarArchiveEntry && !e.isFile && !e.isDirectory) || (e is ZipArchiveEntry && e.isUnixSymlink)
            if (parts == null || special || !ais.canReadEntryData(e)) { sink.skipped++; continue }
            if (e.isDirectory) {
                if (!sink.dir(parts)) sink.skipped++
                continue
            }
            if (!sink.writeFile(parts, ais)) sink.skipped++
        }
    }

    private fun extractGz(archive: File, base: String, sink: Sink) {
        BufferedInputStream(FileInputStream(archive)).use { buffered ->
            GzipCompressorInputStream(buffered).use { gz ->
                if (!sink.writeFile(listOf(base), gz)) sink.skipped++
            }
        }
    }

    private fun extractSevenZ(archive: File, password: String?, sink: Sink) {
        val builder = SevenZFile.builder().setFile(archive)
        if (password != null) builder.setPassword(password.toCharArray())
        builder.get().use { sz ->
            while (true) {
                val e = sz.nextEntry ?: break
                sink.checkCount()
                val parts = cleanPath(e.name)
                if (parts == null || e.isAntiItem) { sink.skipped++; continue }
                if (e.isDirectory) {
                    if (!sink.dir(parts)) sink.skipped++
                    continue
                }
                val stream: InputStream = if (e.hasStream()) sz.getInputStream(e) else ByteArrayInputStream(ByteArray(0))
                if (!sink.writeFile(parts, stream)) sink.skipped++
            }
        }
    }

    private fun extractRar(archive: File, password: String?, tmpParent: File, sink: Sink) {
        val tmp = File(tmpParent, ".fm_tmp_${System.nanoTime()}")
        try {
            tmp.mkdirs()
            if (password != null) Junrar.extract(archive, tmp, password) else Junrar.extract(archive, tmp)
            for (f in tmp.walkTopDown()) {
                if (f == tmp) continue
                sink.checkCount()
                val parts = cleanPath(f.relativeTo(tmp).path)
                val symlink = try { Files.isSymbolicLink(f.toPath()) } catch (_: Exception) { true }
                if (parts == null || symlink) { sink.skipped++; continue }
                if (f.isDirectory) {
                    if (!sink.dir(parts)) sink.skipped++
                } else if (f.isFile) {
                    FileInputStream(f).use { input -> if (!sink.writeFile(parts, input)) sink.skipped++ }
                }
            }
        } finally {
            tmp.deleteRecursively()
        }
    }
}
