@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.example.filemaster

import android.os.Environment
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import java.io.File
import java.text.DateFormat
import java.util.Date

enum class Screen { HOME, BROWSER, TRASH }

enum class SortMode(val label: String) {
    NAME("Nome"),
    DATE("Data (mais recentes)"),
    SIZE("Tamanho (maiores)")
}

data class Entry(val file: File, val isDir: Boolean, val size: Long, val modified: Long)

data class Clipboard(val files: List<File>, val move: Boolean)

/** Lista a pasta (rodar fora da thread principal). Retorna null se não houver permissão de leitura. */
fun listDir(dir: File, showHidden: Boolean, sort: SortMode): List<Entry>? {
    val files = dir.listFiles() ?: return null
    val entries = files
        .filter { showHidden || !it.name.startsWith(".") }
        .map { Entry(it, it.isDirectory, if (it.isDirectory) 0L else it.length(), it.lastModified()) }
    val byName = compareBy<Entry> { it.file.name.lowercase() }
    return when (sort) {
        SortMode.NAME -> entries.sortedWith(compareByDescending<Entry> { it.isDir }.then(byName))
        SortMode.DATE -> entries.sortedWith(compareByDescending<Entry> { it.isDir }.thenByDescending { it.modified })
        SortMode.SIZE -> entries.sortedWith(compareByDescending<Entry> { it.isDir }.thenByDescending { it.size }.then(byName))
    }
}

// ───────────────────────────── TELA INICIAL ─────────────────────────────

@Composable
internal fun HomeScreen(
    hasAccess: Boolean,
    volumes: List<Volume>,
    trashCount: Int,
    dark: Boolean,
    snackbar: SnackbarHostState,
    onToggleTheme: () -> Unit,
    onRequestAccess: () -> Unit,
    onOpenVolume: (Volume) -> Unit,
    onOpenShortcut: (File) -> Unit,
    onOpenTrash: () -> Unit
) {
    val downloads = remember { Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) }
    val photos = remember { Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM) }
    val documents = remember { Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS) }

    Scaffold(snackbarHost = { SnackbarHost(snackbar) }) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp).verticalScroll(rememberScrollState())
        ) {
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("FileMaster", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                    Text("Seus arquivos", style = MaterialTheme.typography.bodyMedium)
                }
                IconButton(onClick = onToggleTheme) {
                    Icon(if (dark) Icons.Default.LightMode else Icons.Default.DarkMode, contentDescription = "Alternar tema")
                }
            }
            Spacer(Modifier.height(20.dp))

            if (!hasAccess) {
                PermissionCard(onRequestAccess)
            } else {
                volumes.forEach { v ->
                    StorageCard(v) { onOpenVolume(v) }
                    Spacer(Modifier.height(14.dp))
                }
                Spacer(Modifier.height(6.dp))
                Text("Acesso rápido", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    ShortcutTile(Icons.Default.Download, "Downloads", Modifier.weight(1f)) { onOpenShortcut(downloads) }
                    ShortcutTile(Icons.Default.Image, "Fotos", Modifier.weight(1f)) { onOpenShortcut(photos) }
                    ShortcutTile(Icons.Default.Description, "Documentos", Modifier.weight(1f)) { onOpenShortcut(documents) }
                    ShortcutTile(Icons.Default.Delete, "Lixeira", Modifier.weight(1f), badge = trashCount) { onOpenTrash() }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun PermissionCard(onRequestAccess: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(12.dp))
            Text("Permitir acesso aos arquivos", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Text(
                "Para mostrar o armazenamento e gerenciar seus arquivos, ative ‘Permitir gerenciamento de todos os arquivos’ nas Configurações e volte ao FileMaster. Pastas protegidas pelo Android (como Android/data) continuam inacessíveis.",
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(16.dp))
            Button(onClick = onRequestAccess, modifier = Modifier.fillMaxWidth()) { Text("Permitir acesso") }
        }
    }
}

@Composable
private fun StorageCard(volume: Volume, onClick: () -> Unit) {
    val (total, free, used) = remember(volume.root) { Storage.usage(volume.root) }
    val fraction = if (total > 0) used.toFloat() / total else 0f
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(52.dp)) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            if (volume.removable) Icons.Default.SdCard else Icons.Default.Storage,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(volume.label, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    Text("${formatSize(free)} livres de ${formatSize(total)}", style = MaterialTheme.typography.bodyMedium)
                }
                Text("${(fraction * 100).toInt()}%", style = MaterialTheme.typography.headlineSmall)
            }
            Spacer(Modifier.height(18.dp))
            LinearProgressIndicator(
                progress = { fraction },
                modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp))
            )
            Spacer(Modifier.height(8.dp))
            Text("${formatSize(used)} usados · toque para abrir", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun ShortcutTile(icon: ImageVector, label: String, modifier: Modifier, badge: Int = 0, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = modifier) {
        Column(Modifier.fillMaxWidth().padding(vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            BadgedBox(badge = { if (badge > 0) Badge { Text("$badge") } }) {
                Icon(icon, contentDescription = label, modifier = Modifier.size(30.dp))
            }
            Spacer(Modifier.height(6.dp))
            Text(label, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

// ───────────────────────────── NAVEGADOR DE PASTAS ─────────────────────────────

@Composable
internal fun BrowserScreen(
    title: String,
    path: String,
    entries: List<Entry>,
    loading: Boolean,
    busy: Boolean,
    error: String?,
    selected: List<String>,
    sort: SortMode,
    showHidden: Boolean,
    clipboard: Clipboard?,
    snackbar: SnackbarHostState,
    onBack: () -> Unit,
    onOpen: (Entry) -> Unit,
    onToggle: (Entry) -> Unit,
    onNewFolder: () -> Unit,
    onToggleHidden: () -> Unit,
    onSort: (SortMode) -> Unit,
    onSelectAll: () -> Unit,
    onClearSelection: () -> Unit,
    onCopy: () -> Unit,
    onCut: () -> Unit,
    onDelete: () -> Unit,
    onRename: () -> Unit,
    onExtract: () -> Unit,
    onPaste: () -> Unit,
    onCancelPaste: () -> Unit
) {
    val selecting = selected.isNotEmpty()
    val dateFormat = remember { DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT) }
    var sortMenu by remember { mutableStateOf(false) }
    val single = if (selected.size == 1) entries.firstOrNull { it.file.absolutePath == selected[0] } else null

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = {
                    if (selecting) {
                        Text("${selected.size} selecionado(s)")
                    } else {
                        Column {
                            Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(path, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = if (selecting) onClearSelection else onBack) {
                        Icon(
                            if (selecting) Icons.Default.Close else Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = if (selecting) "Cancelar seleção" else "Voltar"
                        )
                    }
                },
                actions = {
                    if (selecting) {
                        IconButton(onClick = onSelectAll) { Icon(Icons.Default.SelectAll, contentDescription = "Selecionar tudo") }
                    } else {
                        IconButton(onClick = onNewFolder) { Icon(Icons.Default.CreateNewFolder, contentDescription = "Nova pasta") }
                        IconButton(onClick = onToggleHidden) {
                            Icon(
                                if (showHidden) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                contentDescription = "Mostrar ou ocultar arquivos ocultos"
                            )
                        }
                        Box {
                            IconButton(onClick = { sortMenu = true }) { Icon(Icons.Default.SortByAlpha, contentDescription = "Ordenar") }
                            DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                                SortMode.values().forEach { mode ->
                                    DropdownMenuItem(
                                        text = { Text(mode.label) },
                                        leadingIcon = { if (mode == sort) Icon(Icons.Default.Check, contentDescription = null) },
                                        onClick = { sortMenu = false; onSort(mode) }
                                    )
                                }
                            }
                        }
                    }
                }
            )
        },
        bottomBar = {
            if (selecting) {
                Surface(tonalElevation = 3.dp) {
                    Row(
                        Modifier.fillMaxWidth().navigationBarsPadding().padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        BarAction(Modifier.weight(1f), Icons.Default.ContentCopy, "Copiar", onCopy)
                        BarAction(Modifier.weight(1f), Icons.Default.ContentCut, "Mover", onCut)
                        BarAction(Modifier.weight(1f), Icons.Default.Delete, "Excluir", onDelete)
                        if (single != null) BarAction(Modifier.weight(1f), Icons.Default.DriveFileRenameOutline, "Renomear", onRename)
                        if (single != null && !single.isDir && Extractor.isSupported(single.file.name)) {
                            BarAction(Modifier.weight(1f), Icons.Default.Unarchive, "Extrair", onExtract)
                        }
                    }
                }
            } else if (clipboard != null) {
                Surface(tonalElevation = 3.dp) {
                    Row(
                        Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.ContentPaste, contentDescription = null)
                        Spacer(Modifier.width(10.dp))
                        Text(
                            "${clipboard.files.size} item(ns) para ${if (clipboard.move) "mover" else "copiar"}",
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = onCancelPaste) { Text("Cancelar") }
                        Button(onClick = onPaste) { Text("Colar aqui") }
                    }
                }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            if (busy || loading) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            when {
                error != null -> Text(error, modifier = Modifier.padding(24.dp))
                entries.isEmpty() && !loading -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(56.dp), tint = MaterialTheme.colorScheme.outline)
                            Spacer(Modifier.height(8.dp))
                            Text("Esta pasta está vazia.", color = MaterialTheme.colorScheme.outline)
                        }
                    }
                }
                else -> LazyColumn(Modifier.fillMaxSize()) {
                    items(entries, key = { it.file.absolutePath }) { entry ->
                        EntryRow(
                            entry = entry,
                            selecting = selecting,
                            isSelected = selected.contains(entry.file.absolutePath),
                            dateFormat = dateFormat,
                            onClick = { if (selecting) onToggle(entry) else onOpen(entry) },
                            onLongClick = { onToggle(entry) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BarAction(modifier: Modifier, icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(
        modifier.clickable(onClick = onClick).padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = label)
        Text(label, style = MaterialTheme.typography.labelSmall, maxLines = 1)
    }
}

@Composable
private fun EntryRow(
    entry: Entry,
    selecting: Boolean,
    isSelected: Boolean,
    dateFormat: DateFormat,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val subtitle = (if (entry.isDir) "" else formatSize(entry.size) + " · ") + dateFormat.format(Date(entry.modified))
    Row(
        Modifier
            .fillMaxWidth()
            .background(if (isSelected) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (selecting) {
            Checkbox(checked = isSelected, onCheckedChange = null)
            Spacer(Modifier.width(8.dp))
        }
        Icon(iconFor(entry), contentDescription = null, modifier = Modifier.size(36.dp), tint = tintFor(entry))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(entry.file.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private val IMAGE_EXT = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif", "svg")
private val VIDEO_EXT = setOf("mp4", "mkv", "avi", "mov", "webm", "3gp", "flv", "wmv")
private val AUDIO_EXT = setOf("mp3", "wav", "flac", "ogg", "m4a", "aac", "opus", "wma")
private val DOC_EXT = setOf("pdf", "doc", "docx", "txt", "xls", "xlsx", "ppt", "pptx", "odt", "csv", "md", "rtf")

private fun iconFor(e: Entry): ImageVector {
    if (e.isDir) return Icons.Default.Folder
    val ext = e.file.extension.lowercase()
    return when {
        ext in IMAGE_EXT -> Icons.Default.Image
        ext in VIDEO_EXT -> Icons.Default.Movie
        ext in AUDIO_EXT -> Icons.Default.MusicNote
        ext == "apk" -> Icons.Default.Android
        ext in DOC_EXT -> Icons.Default.Description
        Extractor.isSupported(e.file.name) -> Icons.Default.Archive
        else -> Icons.Default.InsertDriveFile
    }
}

@Composable
private fun tintFor(e: Entry): Color =
    if (e.isDir) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant

// ───────────────────────────── LIXEIRA ─────────────────────────────

@Composable
internal fun TrashScreen(
    items: List<TrashItem>,
    busy: Boolean,
    snackbar: SnackbarHostState,
    onBack: () -> Unit,
    onRestore: (TrashItem) -> Unit,
    onDelete: (TrashItem) -> Unit,
    onEmpty: () -> Unit
) {
    val dateFormat = remember { DateFormat.getDateInstance(DateFormat.SHORT) }
    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text("Lixeira") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar") } },
                actions = {
                    IconButton(onClick = onEmpty, enabled = items.isNotEmpty()) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = "Esvaziar lixeira")
                    }
                }
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            if (busy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            Text(
                "Os itens ficam aqui por ${TrashStore.RETENTION_DAYS} dias e depois são apagados definitivamente.",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
            if (items.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(56.dp), tint = MaterialTheme.colorScheme.outline)
                        Spacer(Modifier.height(8.dp))
                        Text("A lixeira está vazia.", color = MaterialTheme.colorScheme.outline)
                    }
                }
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(items, key = { it.id }) { item ->
                        val passed = (System.currentTimeMillis() - item.deletedAt) / (24L * 60L * 60L * 1000L)
                        val left = (TrashStore.RETENTION_DAYS - passed).coerceAtLeast(0)
                        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                if (item.isDir) Icons.Default.Folder else Icons.Default.InsertDriveFile,
                                contentDescription = null,
                                modifier = Modifier.size(36.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(item.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge)
                                Text(
                                    "Excluído em ${dateFormat.format(Date(item.deletedAt))} · restam $left dia(s)",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Text(
                                    item.originalPath,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.outline,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            IconButton(onClick = { onRestore(item) }) { Icon(Icons.Default.Restore, contentDescription = "Restaurar") }
                            IconButton(onClick = { onDelete(item) }) { Icon(Icons.Default.DeleteForever, contentDescription = "Apagar definitivamente") }
                        }
                        HorizontalDivider()
                    }
                }
            }
        }
    }
}

// ───────────────────────────── DIÁLOGOS ─────────────────────────────

@Composable
internal fun NameDialog(title: String, initial: String, confirm: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    val valid = text.isNotBlank() && !text.contains('/')
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true) },
        confirmButton = { TextButton(enabled = valid, onClick = { onConfirm(text.trim()) }) { Text(confirm) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
internal fun ConfirmDialog(title: String, text: String, confirm: String, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirm) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
internal fun PasswordDialog(retry: Boolean, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Senha do arquivo") },
        text = {
            Column {
                if (retry) Text("Senha incorreta ou arquivo danificado. Tente novamente.", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true, visualTransformation = PasswordVisualTransformation())
            }
        },
        confirmButton = { TextButton(enabled = text.isNotEmpty(), onClick = { onConfirm(text) }) { Text("Extrair") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
