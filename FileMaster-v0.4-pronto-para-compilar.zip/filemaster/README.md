# FileMaster v0.4.0

Gerenciador de arquivos Android (Kotlin + Jetpack Compose). Acessa o armazenamento com a permissão
"Gerenciar todos os arquivos" e usa `java.io.File` diretamente (sem seletor de pastas do Android).
Requer Android 11 ou superior.

## Telas
- **Início (tela cheia):** cartões grandes de armazenamento (interno e cartão SD, se houver) com uso, espaço livre e %.
  Tocar no cartão abre as pastas. Atalhos em ícones: Downloads, Fotos, Documentos e Lixeira (com contador).
- **Pastas:** lista com ícones por tipo, ordenar (nome/data/tamanho), mostrar ocultos, nova pasta.
  Segure um item para selecionar vários; a barra inferior oferece Copiar, Mover, Excluir, Renomear (1 item) e Extrair (1 arquivo compactado).
  Depois de Copiar/Mover, abra a pasta de destino e toque em **Colar aqui**.
- **Lixeira:** restaurar, apagar definitivamente, esvaziar. Itens ficam 30 dias e são apagados ao abrir o app.

## Detalhes técnicos
- Lixeira por volume em `.FileMasterTrash/<id>/` (payload + meta.properties). Mover para ela é instantâneo no mesmo volume.
- Nome repetido ao colar/restaurar vira "nome (1).ext".
- Abrir arquivos usa FileProvider (a versão anterior usava `file://`, que o Android bloqueia).
- Extração: .zip, .tar, .tar.gz/.tgz, .tar.bz2, .tar.xz, .gz, .7z, .rar. Caminhos com `..` são recusados, links simbólicos ignorados, limites de 50 mil entradas e 4 GB.
  Senha: 7z e RAR. ZIP com senha e RAR5 não são suportados.
- Android/data e Android/obb de outros apps continuam protegidos pelo sistema.
